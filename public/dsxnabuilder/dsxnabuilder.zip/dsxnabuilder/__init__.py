"""dsXNAbuilder: double-stranded DNA, RNA and DNA:RNA hybrid builder from the
3DNA fiber models, with modXNA sugar, backbone and base modifications on
either strand. Writes a self-describing PDB file and, optionally, an
Amber/modXNA topology package. Pure Python + numpy, so the same package runs
in CPython (CLI) and in the browser (Pyodide)."""

__version__ = "0.2.0-dev"

__all__ = ["__version__"]
