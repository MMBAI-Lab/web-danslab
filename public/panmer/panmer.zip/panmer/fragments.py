"""
Multi-segment designs: reach the independent bound ceil(N/sigma), optionally under hard
sequence constraints and the replica (positional orthogonality) condition.

The RC-complete master covers every class but repeats some windows (L* > N for even k).
Cutting it at the repeated windows gives segments that contain every class exactly once.
A segment of t windows needs ceil(t/sigma) cores, so what matters is t mod sigma. Two
segments that share a (k-1)-mer node can exchange tails: their lengths change, the set of
windows does not. Reverse-complementing a segment covers the same classes from the other
strand. Simulated annealing over these moves minimises

    cost = n_oligos + W_C * constraint_violations + W_R * replica_collisions

Cores start every sigma windows; the last core of a segment is its final p nucleotides
(overlapping the previous core), so leftover windows become redundancy, not filler.
"""
import math
import random
from dataclasses import dataclass

from .analyze import max_homopolymer, max_selfcomp
from .kmers import canonical_class

W_C = 4.0   # one violated core costs more than one extra oligo
W_R = 4.0   # same for a k-mer window that repeats a reference positional class


@dataclass
class Constraints:
    gc_min: float = None          # GC base pairs in the core, fraction 0..1
    gc_max: float = None
    max_homopolymer: int = None   # longest run allowed in the oligo (clamps included)
    max_selfcomp: int = None      # longest self-complementary stretch allowed in the oligo

    def active(self):
        return any(v is not None for v in (self.gc_min, self.gc_max,
                                           self.max_homopolymer, self.max_selfcomp))


def segments_from_master(alpha, master, k):
    """Split the master at repeated windows."""
    seen, segs, cur = set(), [], None
    for i in range(len(master) - k + 1):
        w = master[i:i + k]
        c = canonical_class(alpha, w)
        if c in seen:
            if cur is not None:
                segs.append(tuple(cur))
            cur = None
            continue
        seen.add(c)
        if cur is None:
            cur = list(w)
        else:
            cur.append(w[-1])
    if cur is not None:
        segs.append(tuple(cur))
    return segs


def positional_d(j, sigma):
    """Strand-invariant positional class of a window at offset j (twice |j - centre|)."""
    return abs(2 * j - (sigma - 1))


class Scorer:
    def __init__(self, alpha, k, p, clamp, cons=None, ref_d=None):
        self.a, self.k, self.p, self.sigma = alpha, k, p, p - k + 1
        self.clamp, self.rclamp = clamp, alpha.rc(clamp)
        self.cons = cons or Constraints()
        self.ref_d = ref_d                 # {class: set(d)} of the reference library
        self.gc = [alpha.base[x] in ('G', 'C') or alpha.base[alpha.comp[x]] in ('G', 'C')
                   for x in range(len(alpha))]
        self.cache = {}

    def cores(self, seg):
        p, k, sigma = self.p, self.k, self.sigma
        t = len(seg) - k + 1
        if t <= 0:
            return []
        if len(seg) < p:                    # shorter than one core: wrap it
            s = seg
            step = seg[k - 1:] or seg
            while len(s) < p:
                s = s + step
            return [s[:p]]
        n = -(-t // sigma)
        starts = [sigma * w for w in range(n - 1)] + [len(seg) - p]
        return [seg[s:s + p] for s in starts]

    def core_violations(self, core):
        c, v = self.cons, 0
        if c.gc_min is not None or c.gc_max is not None:
            g = sum(self.gc[x] for x in core) / len(core)
            v += (c.gc_min is not None and g < c.gc_min - 1e-9)
            v += (c.gc_max is not None and g > c.gc_max + 1e-9)
        if c.max_homopolymer is not None or c.max_selfcomp is not None:
            oli = self.clamp + core + self.rclamp
            if c.max_homopolymer is not None:
                v += max_homopolymer(oli) > c.max_homopolymer
            if c.max_selfcomp is not None:
                v += max_selfcomp(self.a, oli) > c.max_selfcomp
        return v

    def core_collisions(self, core):
        if not self.ref_d:
            return 0
        n, k, sigma = 0, self.k, self.sigma
        for j in range(sigma):
            c = canonical_class(self.a, core[j:j + k])
            if positional_d(j, sigma) in self.ref_d.get(c, ()):
                n += 1
        return n

    def score(self, seg):
        """(n_cores, violations, collisions) for one segment, cached by content."""
        r = self.cache.get(seg)
        if r is None:
            cs = self.cores(seg)
            if self.cons.active() or self.ref_d:
                v = sum(self.core_violations(c) for c in cs)
                col = sum(self.core_collisions(c) for c in cs)
            else:
                v = col = 0
            r = (len(cs), v, col)
            if len(self.cache) > 200_000:
                self.cache.clear()
            self.cache[seg] = r
        return r

    @staticmethod
    def cost(s):
        return s[0] + W_C * s[1] + W_R * s[2]


def optimise_restarts(alpha, segs, scorer, k, restarts=4, seed=0, **kw):
    """Independent annealing runs; keeps the best. The landscape is rugged enough that
    restarts beat a single longer run."""
    best, best_cost = None, math.inf
    for r in range(restarts):
        out = optimise(alpha, segs, scorer, k, seed=seed + 1000 * r, **kw)
        s = [scorer.score(x) for x in out]
        c = sum(x[0] for x in s) + W_C * sum(x[1] for x in s) + W_R * sum(x[2] for x in s)
        if c < best_cost:
            best, best_cost = out, c
        if kw.get('bound') is not None and c <= kw['bound']:
            break
    return best


def _waste(seg, scorer, k):
    """Unused windows in the last core of a segment, plus its violations/collisions."""
    n, v, col = scorer.score(seg)
    return n * scorer.sigma - max(0, len(seg) - k + 1) + W_C * v + W_R * col


def optimise(alpha, segs, scorer, k, iters=None, seed=0, bound=None, time_limit=None):
    """Simulated annealing over tail exchanges, reverse complements and splits."""
    import time
    rnd = random.Random(seed)
    segs = [s for s in segs if len(s) > k - 1]
    sc = [scorer.score(s) for s in segs]
    nodes = {}                                   # node -> set of segment ids

    def index(i, add):
        s = segs[i]
        for a in range(len(s) - k + 2):
            v = s[a:a + k - 1]
            if add:
                nodes.setdefault(v, set()).add(i)
            else:
                d = nodes.get(v)
                if d:
                    d.discard(i)

    for i in range(len(segs)):
        index(i, True)
    total = [sum(x[j] for x in sc) for j in range(3)]
    cost = Scorer.cost(total)
    best = (cost, list(segs))
    iters = iters or max(20_000, 60 * sum(len(s) for s in segs))
    t0, T0, T1 = time.time(), 1.5, 0.02
    stalled = 0
    for it in range(iters):
        if time_limit and it % 256 == 0 and time.time() - t0 > time_limit:
            break
        if bound is not None and total[1] == 0 and total[2] == 0 and total[0] <= bound:
            break
        T = T0 * (T1 / T0) ** (it / iters)
        # bias towards segments that waste windows (and towards violations/collisions),
        # which is where the cost can actually come down
        i = rnd.randrange(len(segs))
        if rnd.random() < 0.7:
            for _ in range(3):
                j = rnd.randrange(len(segs))
                if _waste(segs[j], scorer, k) > _waste(segs[i], scorer, k):
                    i = j
        A = segs[i]
        if len(A) <= k - 1:
            continue
        r = rnd.random()
        if r < 0.35:                              # merge: A's tail node = B's head node
            v = A[len(A) - k + 1:]
            cand_j = [j for j in nodes.get(v, ()) if j != i and segs[j][:k - 1] == v]
            if not cand_j:
                # try the other orientation, so merging does not depend on strand
                w = alpha.rc(v)
                cand_j = [j for j in nodes.get(w, ()) if j != i and segs[j][len(segs[j]) - k + 1:] == w]
                if not cand_j:
                    continue
                j = rnd.choice(cand_j)
                new = {i: A + alpha.rc(segs[j])[k - 1:], j: ()}
            else:
                j = rnd.choice(cand_j)
                new = {i: A + segs[j][k - 1:], j: ()}
        elif r < 0.43:                            # reverse complement
            new = {i: alpha.rc(A)}
        elif r < 0.47:                            # split
            a = rnd.randrange(1, len(A) - k + 1) if len(A) - k + 1 > 1 else None
            if a is None:
                continue
            new = {i: A[:a + k - 1], -1: A[a:]}
        else:                                     # tail exchange at a shared node
            a = rnd.randrange(len(A) - k + 2)
            v = A[a:a + k - 1]
            others = [j for j in nodes.get(v, ()) if j != i]
            if not others:
                continue
            j = rnd.choice(others)
            B = segs[j]
            bs = [b for b in range(len(B) - k + 2) if B[b:b + k - 1] == v]
            b = rnd.choice(bs)
            new = {i: A[:a] + B[b:], j: B[:b] + A[a:]}
        old_s = [sc[x] for x in new if x >= 0]
        new_s = {x: scorer.score(s) if len(s) > k - 1 else (0, 0, 0) for x, s in new.items()}
        cand = [total[q] - sum(o[q] for o in old_s) + sum(n[q] for n in new_s.values())
                for q in range(3)]
        delta = Scorer.cost(cand) - cost
        if delta <= 0 or rnd.random() < math.exp(-delta / T):
            for x in new:
                if x >= 0:
                    index(x, False)
            for x, s in new.items():
                if x < 0:
                    segs.append(s)
                    sc.append(new_s[x])
                    x = len(segs) - 1
                else:
                    segs[x] = s
                    sc[x] = new_s[x]
                index(x, True)
            total, cost = cand, Scorer.cost(cand)
            if cost < best[0] - 1e-9:
                best = (cost, [s for s in segs if len(s) > k - 1])
                stalled = 0
        stalled += 1
    return [s for s in best[1] if len(s) > k - 1]


def reference_positions(alpha, ref_cores, k):
    """{class: set(d)} of a reference library given as cores."""
    out = {}
    for c in ref_cores:
        sigma = len(c) - k + 1
        for j in range(sigma):
            out.setdefault(canonical_class(alpha, c[j:j + k]), set()).add(positional_d(j, sigma))
    return out
