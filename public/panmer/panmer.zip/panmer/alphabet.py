"""
Alphabets with a complementarity involution.

A symbol is an *oriented base pair* seen from the Watson strand. The complement map
``comp`` is an involution (comp[comp[i]] == i) and may have fixed points.

Modified bases (modXNA) are always placed opposite their canonical partner, so each
modification X contributes two symbols:

    [X]  -> X on this strand, canonical partner on the other
    {X}  -> canonical partner on this strand, X on the other

and the reverse complement swaps [X] <-> {X}.
"""
import json
import os
import re
from dataclasses import dataclass

CANONICAL_COMP = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C', 'U': 'A'}
_TOKEN = re.compile(r'\[([^\]\s]+)\]|\{([^}\s]+)\}|([A-Za-z])')


@dataclass(frozen=True)
class Alphabet:
    name: str
    symbols: tuple      # display names, e.g. 'A', '[M6A]', '{M6A}'
    comp: tuple         # index of the complementary symbol
    modified: tuple     # True if the base pair carries a modification
    base: tuple         # residue on this strand ('A', 'M6A', ...)
    nucleic: str = 'DNA'

    def __post_init__(self):
        assert all(self.comp[self.comp[i]] == i for i in range(len(self.symbols))), \
            'comp is not an involution'
        object.__setattr__(self, '_index', {s: i for i, s in enumerate(self.symbols)})

    def __len__(self):
        return len(self.symbols)

    @property
    def canonical(self):
        return tuple(i for i, m in enumerate(self.modified) if not m)

    @property
    def mods(self):
        return tuple(i for i, m in enumerate(self.modified) if m)

    @property
    def fixed_points(self):
        return tuple(i for i, c in enumerate(self.comp) if c == i)

    def rc(self, seq):
        c = self.comp
        return tuple(c[x] for x in reversed(seq))

    def encode(self, text):
        """Parse '[X]' / '{X}' / single-letter notation into a tuple of indices."""
        out, pos = [], 0
        text = re.sub(r'\s+', '', text)
        for m in _TOKEN.finditer(text):
            if m.start() != pos:
                raise ValueError(f'cannot parse {text[pos:m.start()]!r}')
            pos = m.end()
            tok = (f'[{m.group(1)}]' if m.group(1) else
                   f'{{{m.group(2)}}}' if m.group(2) else m.group(3).upper())
            if tok not in self._index:
                raise ValueError(f'symbol {tok} is not in alphabet {self.name}')
            out.append(self._index[tok])
        if pos != len(text):
            raise ValueError(f'cannot parse {text[pos:]!r}')
        return tuple(out)

    def decode(self, seq):
        return ''.join(self.symbols[x] for x in seq)


def custom(name, pairs, modified=(), nucleic='DNA'):
    """Alphabet from single-letter pairs, e.g. {'A':'T', ..., 'X':'X'} (fixed point)."""
    syms = tuple(sorted(pairs))
    idx = {s: i for i, s in enumerate(syms)}
    return Alphabet(name, syms, tuple(idx[pairs[s]] for s in syms),
                    tuple(s in modified for s in syms), syms, nucleic)


def canonical(nucleic='DNA'):
    t = 'T' if nucleic == 'DNA' else 'U'
    return custom(nucleic, {'A': t, t: 'A', 'C': 'G', 'G': 'C'}, nucleic=nucleic)


DNA = canonical('DNA')
RNA = canonical('RNA')


def partner(parent, nucleic):
    """Canonical base placed opposite a modification of `parent`."""
    if parent == 'A':
        return 'T' if nucleic == 'DNA' else 'U'
    return CANONICAL_COMP[parent]


def with_mods(nucleic, mods, name=None):
    """Canonical alphabet plus modified bases.

    mods: iterable of (code, parent) with parent in A/C/G/T/U.
    """
    base = canonical(nucleic)
    syms, comp, modified, res = (list(base.symbols), list(base.comp),
                                 list(base.modified), list(base.base))
    seen = set()
    for code, parent in mods:
        if code in seen:
            continue
        seen.add(code)
        i = len(syms)
        syms += [f'[{code}]', f'{{{code}}}']
        comp += [i + 1, i]
        modified += [True, True]
        res += [code, partner(parent, nucleic)]
    return Alphabet(name or f'{nucleic}+{len(seen)}mod', tuple(syms), tuple(comp),
                    tuple(modified), tuple(res), nucleic)


_CATALOG = None


def modxna_catalog():
    """List of dicts {code, parent, name, notes} for modXNA base modifications."""
    global _CATALOG
    if _CATALOG is None:
        path = os.path.join(os.path.dirname(__file__), 'data', 'modxna_bases.json')
        with open(path, encoding='utf-8') as f:
            _CATALOG = json.load(f)
    return _CATALOG['bases']


def modxna(nucleic='DNA', codes=None, parents=None, include_protected=False,
           include_duplicates=False):
    """Alphabet with modXNA base modifications.

    codes: explicit list of fragment codes; or parents: e.g. 'ACGT' for whole families.
    Family selection skips protected phosphoramidites and duplicate entries unless asked.
    """
    cat = {b['code']: b for b in modxna_catalog()}
    if codes is None:
        parents = parents or ('ACGT' if nucleic == 'DNA' else 'ACGU')
        codes = [c for c, b in cat.items() if b['parent'] in parents
                 and (include_protected or not b['protected'])
                 and (include_duplicates or not b['duplicate_of'])]
    unknown = [c for c in codes if c not in cat]
    if unknown:
        raise ValueError(f'unknown modXNA codes: {unknown}')
    return with_mods(nucleic, [(c, cat[c]['parent']) for c in codes],
                     name=f'{nucleic}+modXNA({len(codes)})')


PRESETS = {'DNA': lambda: DNA, 'RNA': lambda: RNA,
           'DNA+5mC': lambda: modxna('DNA', ['M5C'])}
