"""
Library design: RC-complete master sequence (Orenstein & Shamir 2013, generalised to an
alphabet with a complementarity involution) and its tiling into equal-length cores.
"""
import collections
import random
from dataclasses import dataclass, field

from .kmers import counts, enumerate_kmers


def augmented_edges(alpha, k, max_mods=None):
    """de Bruijn edge multiset (k-mer -> multiplicity) augmented with the rotation cycle
    of every palindrome, restricted to k-mers with at most `max_mods` modifications."""
    mult = collections.Counter(enumerate_kmers(alpha, k, max_mods))
    seen = set()
    for w in [x for x in mult if x == alpha.rc(x)]:
        if w in seen:
            continue
        orbit, x = [], w
        for _ in range(k):
            if x not in orbit:
                orbit.append(x)
            x = x[1:] + x[:1]
        seen.update(orbit)
        for e in orbit:
            mult[e] += 1
    return mult


def check_graph(alpha, mult):
    """The three conditions of O&S Theorem 4: balanced, RC-matched, connected."""
    outd, ind = collections.Counter(), collections.Counter()
    adj = collections.defaultdict(set)
    for w, c in mult.items():
        outd[w[:-1]] += c
        ind[w[1:]] += c
        adj[w[:-1]].add(w[1:])
    nodes = set(outd) | set(ind)
    balanced = all(outd[v] == ind[v] for v in nodes)
    rc_matched = all(mult[w] == mult.get(alpha.rc(w), 0) for w in mult)
    root = next(iter(nodes))
    seen, stack = {root}, [root]
    while stack:
        for x in adj[stack.pop()]:
            if x not in seen:
                seen.add(x)
                stack.append(x)
    return balanced, rc_matched, len(seen) == len(nodes)


def paired_euler(alpha, mult, seed=0):
    """O&S Algorithm 1: Hierholzer consuming an edge and its RC together.
    Returns the master sequence as a tuple of symbol indices."""
    rnd = random.Random(seed)
    out = collections.defaultdict(list)
    for w in sorted(mult):
        out[w[:-1]].append(w)
    for v in sorted(out):
        rnd.shuffle(out[v])
    rem = dict(mult)
    start = min(out)
    stack, path = [start], []
    ptr = collections.defaultdict(int)
    while stack:
        v = stack[-1]
        edges, nxt = out.get(v, ()), None
        while ptr[v] < len(edges):
            w = edges[ptr[v]]
            r = alpha.rc(w)
            # a palindrome is its own RC: consuming the pair takes two copies
            if (rem[w] >= 2) if r == w else (rem[w] > 0 and rem.get(r, 0) > 0):
                nxt, nr = w, r
                break
            ptr[v] += 1     # edges never come back, so skipping them is final
        if nxt is None:
            path.append(stack.pop())
        else:
            rem[nxt] -= 1
            rem[nr] -= 1
            stack.append(nxt[1:])
    path.reverse()
    return path[0] + tuple(v[-1] for v in path[1:])


def tile(master, p, k):
    """Cut the master into m cores of length p overlapping by k-1 (stride sigma=p-k+1).
    Enforces L = p (mod sigma) by wrapping the master cyclically."""
    sigma = p - k + 1
    m = -(-(len(master) - k + 1) // sigma)
    L = p + (m - 1) * sigma
    s = master + master[:L - len(master)] if L > len(master) else master[:L]
    return [s[sigma * w: sigma * w + p] for w in range(m)]


@dataclass
class Library:
    alphabet: object
    k: int
    core: int
    clamp: tuple
    max_mods: object
    seed: int
    master: tuple
    cores: list
    n_kmers: int
    n_palindromes: int
    n_classes: int
    stats: dict = field(default_factory=dict)
    segments: list = field(default_factory=list)

    @property
    def sigma(self):
        return self.core - self.k + 1

    @property
    def oligos(self):
        rc = self.alphabet.rc
        return [self.clamp + c + rc(self.clamp) for c in self.cores]


def bounds(n_classes, master_kmers, sigma):
    """The two lower bounds on the number of oligos."""
    return dict(independent=-(-n_classes // sigma), tiled=-(-master_kmers // sigma))


def design(alpha, k, core, clamp='GC', max_mods=None, seed=0, segmented=False,
           constraints=None, replica_of=None, effort=1.0):
    """Design a library.

    segmented   -- cut the master into segments and recombine them (reaches the
                   independent bound ceil(N/sigma); the tiled master cannot).
    constraints -- fragments.Constraints: GC range, homopolymer run, self-complementarity.
                   Implies segmented, since a single master cannot be re-cut.
    replica_of  -- oligos (or cores) of a reference library: the result avoids placing any
                   k-mer in a positional class it occupies there.
    effort      -- scales the annealing budget.
    """
    from .fragments import (Constraints, Scorer, optimise_restarts, reference_positions,
                            segments_from_master)
    if core < k:
        raise ValueError('core must be at least k')
    clamp_t = alpha.encode(clamp) if isinstance(clamp, str) else tuple(clamp)
    mult = augmented_edges(alpha, k, max_mods)
    ok = check_graph(alpha, mult)
    if not all(ok):
        raise RuntimeError(f'augmented graph is not valid (balanced, rc, connected) = {ok}')
    master = paired_euler(alpha, mult, seed)
    n_k, n_pal, n_cls = counts(alpha, k, max_mods)
    sigma = core - k + 1
    master_kmers = len(master) - k + 1
    bnd = bounds(n_cls, master_kmers, sigma)

    cons = constraints or Constraints()
    ref_d = None
    if replica_of is not None:
        from .analyze import split_clamp
        ref = [alpha.encode(o) if isinstance(o, str) else tuple(o) for o in replica_of]
        ref = [o if len(o) == core else split_clamp(alpha, o, clamp_t) for o in ref]
        ref_d = reference_positions(alpha, ref, k)
    use_segments = segmented or cons.active() or ref_d is not None

    segs = []
    if use_segments:
        scorer = Scorer(alpha, k, core, clamp_t, cons, ref_d)
        segs = segments_from_master(alpha, master, k)
        iters = int(max(60_000, 400 * master_kmers) * effort)
        segs = optimise_restarts(alpha, segs, scorer, k, restarts=max(1, int(4 * effort)),
                                 seed=seed, iters=iters, bound=bnd['independent'],
                                 time_limit=60 * effort)
        cores = [c for s in segs for c in scorer.cores(s)]
    else:
        cores = tile(master, core, k)

    lib = Library(alpha, k, core, clamp_t, max_mods, seed, master, cores, n_k, n_pal, n_cls,
                  segments=[alpha.decode(s) for s in segs])
    lib.stats = dict(master_nt=len(master), master_kmers=master_kmers,
                     n_oligos=len(cores), windows=len(cores) * sigma,
                     redundancy=len(cores) * sigma - n_cls, bounds=bnd,
                     mode='segments' if use_segments else 'tiled',
                     n_segments=len(segs) or None)
    if use_segments and (cons.active() or ref_d is not None):
        sc = [scorer.score(s) for s in segs]
        if cons.active():
            lib.stats['violations'] = sum(x[1] for x in sc)
        if ref_d is not None:
            lib.stats['replica_collisions'] = sum(x[2] for x in sc)
    return lib
