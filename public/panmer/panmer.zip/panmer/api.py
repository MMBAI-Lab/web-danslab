"""JSON-in / JSON-out entry points used by the web front end (Pyodide) and the CLI."""
import json

from . import __version__
from .alphabet import PRESETS, modxna, modxna_catalog
from .analyze import analyze
from .design import design
from .export import oligo_rows, to_csv, to_fasta, to_modxna
from .kmers import counts

MAX_KMERS = 2_000_000       # keeps a browser tab responsive


def make_alphabet(spec):
    """spec: {'preset': 'DNA'} or {'nucleic': 'DNA', 'mods': ['M6A', ...]}"""
    if spec.get('mods'):
        return modxna(spec.get('nucleic', 'DNA'), list(spec['mods']))
    return PRESETS[spec.get('preset') or spec.get('nucleic', 'DNA')]()


def _max_mods(p):
    v = p.get('max_mods')
    return None if v in (None, '', 'all') else int(v)


def estimate(p):
    a = make_alphabet(p['alphabet'])
    k, core, m = int(p['k']), int(p['core']), _max_mods(p)
    n_k, n_pal, n_cls = counts(a, k, m)
    sigma = core - k + 1
    return dict(n_symbols=len(a), n_mod_symbols=len(a.mods), n_kmers=n_k,
                n_palindromes=n_pal, n_classes=n_cls, sigma=sigma,
                min_oligos=-(-n_cls // sigma) if sigma > 0 else None,
                feasible=n_k <= MAX_KMERS and sigma > 0)


def run_design(p):
    est = estimate(p)
    if not est['feasible']:
        raise ValueError(f'{est["n_kmers"]:,} k-mers exceed the browser limit '
                         f'({MAX_KMERS:,}); lower k, the number of modifications or max_mods.')
    a = make_alphabet(p['alphabet'])
    lib = design(a, int(p['k']), int(p['core']), p.get('clamp', 'GC'),
                 _max_mods(p), int(p.get('seed', 0)))
    return dict(version=__version__, params=p, estimate=est, stats=lib.stats,
                master=a.decode(lib.master), oligos=oligo_rows(lib),
                fasta=to_fasta(lib), csv=to_csv(lib),
                modxna=to_modxna(lib) if a.mods else None)


def run_analyze(p):
    a = make_alphabet(p['alphabet'])
    seqs = [s.strip() for s in p['oligos'] if s.strip() and not s.startswith('>')]
    r = analyze(a, seqs, int(p['k']), p.get('clamp', 'GC'), _max_mods(p))
    r.pop('occurrences')
    r['version'] = __version__
    return r


def catalog():
    return modxna_catalog()


def call(name, payload_json):
    """Single dispatch point for the web worker: returns a JSON string."""
    fn = dict(estimate=estimate, design=run_design, analyze=run_analyze,
              catalog=lambda _: catalog())[name]
    try:
        return json.dumps(dict(ok=True, result=fn(json.loads(payload_json))))
    except Exception as e:      # surfaced to the user verbatim
        return json.dumps(dict(ok=False, error=f'{type(e).__name__}: {e}'))
