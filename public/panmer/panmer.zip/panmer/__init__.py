"""Panmer: equal-length oligonucleotide libraries that cover every k-mer."""
__version__ = '0.1.0'

from .alphabet import DNA, RNA, Alphabet, custom, modxna, with_mods  # noqa: E402,F401
from .analyze import analyze  # noqa: E402,F401
from .design import design  # noqa: E402,F401
from .kmers import counts  # noqa: E402,F401
