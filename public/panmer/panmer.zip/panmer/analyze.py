"""
Analysis of an existing library: k-mer coverage, redundancy, positional classes and
sequence-quality metrics.

Positional class: inside a core with sigma windows, a k-mer at offset j on Watson is its
reverse complement at offset sigma-1-j on Crick. The strand-invariant descriptor is
d = |2j - (sigma-1)| (twice the distance to the centre, so it is always an integer;
for miniABC, sigma=11 and d/2 = |j-5|).
"""
import collections

from .kmers import canonical_class, counts


def split_clamp(alpha, oligo, clamp):
    """Strip clamp ... rc(clamp) if present; returns the core."""
    c = len(clamp)
    if c and oligo[:c] == clamp and oligo[-c:] == alpha.rc(clamp):
        return oligo[c:-c]
    raise ValueError(f'oligo {alpha.decode(oligo)} does not carry the clamp '
                     f'{alpha.decode(clamp)}...{alpha.decode(alpha.rc(clamp))}')


def max_selfcomp(alpha, seq, min_len=2):
    """Length of the longest self-complementary (palindromic) stretch."""
    best, n = 0, len(seq)
    for i in range(n):
        for j in range(i + min_len, n + 1):
            s = seq[i:j]
            if j - i > best and s == alpha.rc(s):
                best = j - i
    return best


def max_homopolymer(seq):
    best = run = 0
    prev = None
    for x in seq:
        run = run + 1 if x == prev else 1
        prev = x
        best = max(best, run)
    return best


def gc_fraction(alpha, seq):
    gc = sum(alpha.base[x] in ('G', 'C') or alpha.base[alpha.comp[x]] in ('G', 'C')
             for x in seq)
    return gc / len(seq) if seq else 0.0


def windows(alpha, cores, k):
    """[(class, oligo_index, offset_j)] for every k-mer window of every core."""
    out = []
    for o, c in enumerate(cores):
        for j in range(len(c) - k + 1):
            out.append((canonical_class(alpha, c[j:j + k]), o, j))
    return out


def analyze(alpha, oligos, k, clamp='GC', max_mods=None):
    clamp_t = alpha.encode(clamp) if isinstance(clamp, str) else tuple(clamp)
    olis = [alpha.encode(o) if isinstance(o, str) else tuple(o) for o in oligos]
    cores = [split_clamp(alpha, o, clamp_t) for o in olis]
    n_k, n_pal, n_cls = counts(alpha, k, max_mods)
    win = windows(alpha, cores, k)
    occ = collections.defaultdict(list)
    for cls, o, j in win:
        sigma = len(cores[o]) - k + 1
        occ[cls].append((o, j, abs(2 * j - (sigma - 1))))
    rep = {cls: v for cls, v in occ.items() if len(v) > 1}
    lens = sorted({len(c) for c in cores})
    sigma = lens[0] - k + 1 if len(lens) == 1 else None
    in_scope = [c for c in occ
                if max_mods is None or sum(alpha.modified[x] for x in c) <= max_mods]
    res = dict(
        n_oligos=len(olis), core_lengths=lens, windows=len(win),
        n_classes=n_cls, covered=len(in_scope), missing=n_cls - len(in_scope),
        out_of_scope=len(occ) - len(in_scope),
        redundancy=len(win) - len(occ), repeated={alpha.decode(c): len(v) for c, v in rep.items()},
        occurrences={alpha.decode(c): v for c, v in occ.items()},
        per_oligo=[dict(oligo=alpha.decode(o), gc=round(gc_fraction(alpha, c), 4),
                        max_homopolymer=max_homopolymer(o), max_selfcomp=max_selfcomp(alpha, o))
                   for o, c in zip(olis, cores)],
    )
    if sigma:
        res['sigma'] = sigma
        res['bound_independent'] = -(-n_cls // sigma)
    return res


def missing_classes(alpha, k, covered, max_mods=None, limit=None):
    """Enumerate classes not covered (only sensible for small alphabets / k)."""
    from .kmers import enumerate_kmers
    out, seen = [], set(covered)
    for w in enumerate_kmers(alpha, k, max_mods):
        c = canonical_class(alpha, w)
        if c not in seen:
            seen.add(c)
            out.append(alpha.decode(c))
            if limit and len(out) >= limit:
                break
    return out


def positional_overlap(alpha, lib_a, lib_b, k, clamp='GC'):
    """Number of k-mer classes that occupy the same positional class d in both libraries
    (the replica condition asks for zero)."""
    def dsets(oligos):
        r = analyze(alpha, oligos, k, clamp)
        return {c: {d for _, _, d in v} for c, v in r['occurrences'].items()}
    a, b = dsets(lib_a), dsets(lib_b)
    return sum(1 for c in a if c in b and a[c] & b[c])
