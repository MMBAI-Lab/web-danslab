"""Command-line interface: panmer design | analyze | estimate."""
import argparse
import json
import sys

from . import __version__
from .api import estimate, run_analyze, run_design


def _alphabet(args):
    if args.mods:
        return dict(nucleic=args.nucleic, mods=args.mods.split(','))
    return dict(preset=args.alphabet or args.nucleic)


def _common(p):
    p.add_argument('-k', type=int, required=True)
    p.add_argument('--nucleic', choices=['DNA', 'RNA'], default='DNA')
    p.add_argument('--alphabet', help='preset: DNA, RNA, DNA+5mC')
    p.add_argument('--mods', help='comma-separated modXNA base codes, e.g. M6A,M5C')
    p.add_argument('--max-mods', help='max modified positions per k-mer (default: no limit)')
    p.add_argument('--clamp', default='GC')


def main(argv=None):
    ap = argparse.ArgumentParser(prog='panmer', description=__doc__)
    ap.add_argument('--version', action='version', version=__version__)
    sub = ap.add_subparsers(dest='cmd', required=True)
    d = sub.add_parser('design', help='design a library')
    _common(d)
    d.add_argument('--core', type=int, required=True)
    d.add_argument('--seed', type=int, default=0)
    d.add_argument('--segments', action='store_true',
                   help='recombine segments to reach the independent bound')
    d.add_argument('--gc-min', type=float, help='minimum GC %% of the core')
    d.add_argument('--gc-max', type=float, help='maximum GC %% of the core')
    d.add_argument('--max-run', type=int, help='maximum homopolymer run')
    d.add_argument('--max-selfcomp', type=int, help='maximum self-complementary stretch')
    d.add_argument('--replica-of', metavar='FILE',
                   help='reference library: put every k-mer in a different helical position')
    d.add_argument('--effort', type=float, default=1.0, help='annealing budget (default 1.0)')
    d.add_argument('--format', choices=['fasta', 'csv', 'json', 'modxna'], default='fasta')
    e = sub.add_parser('estimate', help='count classes and oligos without designing')
    _common(e)
    e.add_argument('--core', type=int, required=True)
    a = sub.add_parser('analyze', help='analyse an existing library (FASTA or one per line)')
    _common(a)
    a.add_argument('file')
    args = ap.parse_args(argv)

    p = dict(alphabet=_alphabet(args), k=args.k, max_mods=args.max_mods, clamp=args.clamp)
    if args.cmd == 'estimate':
        p['core'] = args.core
        print(json.dumps(estimate(p), indent=1))
    elif args.cmd == 'design':
        p.update(core=args.core, seed=args.seed, segmented=args.segments,
                 effort=args.effort,
                 constraints=dict(gc_min=args.gc_min, gc_max=args.gc_max,
                                  max_homopolymer=args.max_run,
                                  max_selfcomp=args.max_selfcomp))
        if args.replica_of:
            with open(args.replica_of) as f:
                p['replica_of'] = f.read().splitlines()
        r = run_design(p)
        if args.format == 'json':
            print(json.dumps(r, indent=1))
        elif args.format == 'modxna':
            sys.stdout.write(r['modxna'] or '# no modified bases\n')
        else:
            sys.stdout.write(r[args.format])
        print(json.dumps(r['stats']), file=sys.stderr)
    else:
        with open(args.file) as f:
            p['oligos'] = f.read().splitlines()
        print(json.dumps(run_analyze(p), indent=1))


if __name__ == '__main__':
    main()
