"""k-mer enumeration and exact class counts, optionally with at most m modified positions."""
import itertools
import math


def enumerate_kmers(alpha, k, max_mods=None):
    """All k-mers (tuples of symbol indices) with at most `max_mods` modified positions."""
    can, mod = alpha.canonical, alpha.mods
    if max_mods is None or max_mods >= k or not mod:
        yield from itertools.product(range(len(alpha)), repeat=k)
        return
    for j in range(max_mods + 1):
        for pos in itertools.combinations(range(k), j):
            pools = [mod if i in pos else can for i in range(k)]
            yield from itertools.product(*pools)


def counts(alpha, k, max_mods=None):
    """(n_kmers, n_palindromes, n_classes) for the k-mers allowed by `max_mods`.

    Closed form; validated against brute force in tests. A palindrome is fixed by its
    left half (plus the middle symbol, which must be a fixed point of comp, if k is odd);
    modifications in the left half are mirrored, so they count twice.
    """
    c = len(alpha.canonical)
    L = len(alpha.mods)
    m = k if max_mods is None else min(max_mods, k)
    total = sum(math.comb(k, j) * c ** (k - j) * L ** j for j in range(m + 1))
    h = k // 2
    if k % 2 == 0:
        mids = [(0, 1)]
    else:
        fc = sum(1 for i in alpha.fixed_points if not alpha.modified[i])
        fm = sum(1 for i in alpha.fixed_points if alpha.modified[i])
        mids = [(0, fc), (1, fm)]
    pal = 0
    for extra, nmid in mids:
        if nmid == 0:
            continue
        for j in range(h + 1):
            if 2 * j + extra <= m:
                pal += nmid * math.comb(h, j) * c ** (h - j) * L ** j
    return total, pal, (total + pal) // 2


def n_mods(alpha, kmer):
    return sum(alpha.modified[x] for x in kmer)


def canonical_class(alpha, kmer):
    r = alpha.rc(kmer)
    return min(kmer, r)
