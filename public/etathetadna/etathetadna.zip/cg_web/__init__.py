"""cg_web: the ηθDNA web app's Python side (runs in the browser through Pyodide).

It wraps the same code as the command line tools -- cg_dna.convert_dna and
cg_dna.g4 for the mapping, cg_backmap.reconstruct for the backmapping -- and
needs only numpy: no ParmEd, AmberTools or SIRAH. What needs AmberTools (the
CG topology, the hydrogens and minimization of a backmapped frame) is handed
over as a ready-to-run package.

    service.py   what the app does (tested under CPython)
    webapi.py    JSON dispatcher for the browser worker
    topology.py  CG topologies without ParmEd (CG PDB, prmtop)
    netcdf.py    AMBER NetCDF trajectories, read frame by frame
"""
__version__ = "1.0.0"
