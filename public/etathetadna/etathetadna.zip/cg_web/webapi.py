"""JSON dispatcher for the browser worker (web/worker.js).

``call(name, payload_json) -> result_json``; ``name`` is one of CALLS.
Errors come back as {"ok": false, "error": ...}, never as an exception, so
the worker keeps running. Binary data (zips, trajectory frames) travels
base64-encoded.
"""
import json
import traceback

from . import service

CALLS = {
    "info": lambda p: service.info(),
    "map": service.map_structure,
    "pdb_info": service.pdb_info,
    "prmtop_info": service.prmtop_info,
    "nc_header": service.nc_header,
    "backmap": service.backmap,
    "backmap_package": service.backmap_package,
}


def call(name, payload_json):
    try:
        if name not in CALLS:
            raise ValueError(f"unknown call {name!r}")
        result = CALLS[name](json.loads(payload_json or "{}"))
        return json.dumps({"ok": True, "result": result})
    except Exception as exc:  # report, never crash the worker
        return json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}",
                           "trace": traceback.format_exc(limit=4)})
