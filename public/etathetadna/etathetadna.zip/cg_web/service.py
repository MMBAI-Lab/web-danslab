"""What the ηθDNA web app does, in plain Python.

Every function takes and returns JSON-ready dicts (webapi.py serializes
them for the browser worker). Files are handled in memory or in a temporary
directory, which Pyodide keeps in its in-memory file system.

  info()            model, bead tables, templates, examples
  map_structure()   atomistic PDB -> ηθDNA CG PDB (+ G4 channel cations),
                    and the package that builds the CG topology with tleap
  prmtop_info()     atoms and solute of a CG prmtop
  nc_header()       frames of an AMBER NetCDF trajectory
  backmap()         CG frames -> all-atom heavy-atom PDB (one MODEL per frame)
  backmap_package() hydrogens + minimization of those frames, for AmberTools
"""
import base64
import contextlib
import io
import os
import re
import tempfile
import zipfile
from collections import Counter

import numpy as np

from cg_backmap import hydrogenate, paths as bpaths, recipe, reconstruct, resolvate
from cg_dna import convert_dna, g4, model
from cg_dna import paths as cpaths

from . import __version__, netcdf, topology

AMINO = {"ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "HID", "HIE", "HIP", "ILE",
         "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL", "CYX", "ASH", "GLH", "LYN"}
WATER = {"HOH", "WAT", "TIP3", "TIP", "SOL", "DOD"}
RNA = {"A", "C", "G", "U", "RA", "RC", "RG", "RU"}
BASE_OF = {cg: base for base in "ACGT"
           for cg in (f"D{base}X", f"{base}X5", f"{base}X3", f"D{base}1")}
MAX_FRAMES = 100
CODE = {"B": "B", "A": "A", "syn": "s", "Z": "Z"}     # template of each residue, one letter per residue

TEMPLATES = [
    {"label": "B", "conformation": "anti, C2′-endo", "source": "1BNA, B-DNA (default)"},
    {"label": "A", "conformation": "anti, C3′-endo", "source": "116D, A-DNA"},
    {"label": "syn", "conformation": "syn G, C2′-endo (anti → syn step of a G-tract)", "source": "1JPQ, G-quadruplex"},
    {"label": "Z", "conformation": "syn purine C3′-endo / anti pyrimidine, Z backbone", "source": "181D, Z-DNA"},
]


def _name(s, default="system"):
    s = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(s or "").strip()).strip("._")
    s = re.sub(r"\.(pdb|ent|cif)$", "", s, flags=re.I)
    return s[:40] or default


def _zip(files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for path, text in files.items():
            info = zipfile.ZipInfo(path, date_time=(2026, 1, 1, 0, 0, 0))
            info.external_attr = (0o755 if path.endswith(".sh") else 0o644) << 16
            z.writestr(info, text)
    return base64.b64encode(buf.getvalue()).decode()


# ---------------------------------------------------------------- CG library
_UNITS = None


def units():
    """{unit: {"atoms": [(name, type, charge)], "bonds": [(i, j)] 0-based}}
    from params/dna_vf.lib, repeat.lib and cationes_g4.lib (AMBER OFF)."""
    global _UNITS
    if _UNITS is None:
        _UNITS = {}
        for path in (cpaths.DNA_VF_LIB, cpaths.REPEAT_LIB, cpaths.CATIONS_G4_LIB):
            unit, table = None, None
            for line in open(path):
                if line.startswith("!"):
                    m = re.match(r"!entry\.([^.]+)\.unit\.(\w+)", line)
                    unit, table = (m.group(1), m.group(2)) if m else (None, None)
                    if unit and unit not in _UNITS:
                        _UNITS[unit] = {"atoms": [], "bonds": []}
                    continue
                if table == "atoms":
                    m = re.match(r'\s*"([^"]*)"\s+"([^"]*)"(?:\s+\S+){5}\s+(\S+)', line)
                    if m:
                        _UNITS[unit]["atoms"].append((m.group(1), m.group(2), float(m.group(3))))
                elif table == "connectivity":
                    i, j = line.split()[:2]
                    _UNITS[unit]["bonds"].append((int(i) - 1, int(j) - 1))
    return _UNITS


def view_pdb(top, xyz):
    """A CG PDB for the 3D viewer: atoms renumbered 1..N, with CONECT
    records for the bead bonds (the unit's own bonds plus the links between
    residues found in ``top``), since a viewer cannot guess them."""
    lib = units()
    lines, conect = [], {}
    for r in top.residues:
        for a in r.atoms:
            x = xyz[a.idx]
            lines.append(f"ATOM  {a.idx + 1:5d} {a.name:<4s} {r.name:>3s} {r.chain or 'A'}{r.number % 10000:4d}    "
                         f"{x[0]:8.3f}{x[1]:8.3f}{x[2]:8.3f}  1.00  0.00")
            for b in a.bond_partners:
                conect.setdefault(a.idx + 1, set()).add(b.idx + 1)
        unit = lib.get(r.name)
        if unit:
            by_name = {a.name: a for a in r.atoms}
            for i, j in unit["bonds"]:
                a, b = by_name.get(unit["atoms"][i][0]), by_name.get(unit["atoms"][j][0])
                if a and b:
                    conect.setdefault(a.idx + 1, set()).add(b.idx + 1)
                    conect.setdefault(b.idx + 1, set()).add(a.idx + 1)
    for i in sorted(conect):
        js = sorted(conect[i])
        for k in range(0, len(js), 4):
            lines.append(f"CONECT{i:5d}" + "".join(f"{j:5d}" for j in js[k:k + 4]))
    return "\n".join(lines) + "\nEND\n"


# ---------------------------------------------------------------- info
def info():
    lib = units()
    beads = []
    for base in "GATC":
        unit = f"D{base}X"
        inv = {v: k for k, v in convert_dna.ATOM_NAME_MAP[f"D{base}"].items()}
        beads.append({"base": base, "unit": unit,
                      "beads": [{"name": n, "type": t, "charge": q, "atom": inv.get(n, "")}
                                for n, t, q in lib[unit]["atoms"]],
                      "charge": round(sum(q for _, _, q in lib[unit]["atoms"]), 3)})
    table = recipe.load_recipes(bpaths.BACKMAP_DNA_JSON)
    chi = {base: {k: round(v) for k, v in table[f"D{base}X"]["fit"]["chi"].items()} for base in "GATC"}
    return {"version": __version__, "model": "ηθDNA 1.0", "beads": beads, "templates": TEMPLATES, "chi": chi,
            "channel_ions": {"KW4": "K+", "NW4": "Na+"}, "default_salt": model.DEFAULT_SALT_M,
            "max_frames": MAX_FRAMES}


# ---------------------------------------------------------------- mapping
def _residues_of(text):
    """{(record, resname, chain, resid)} of the input PDB, first model only."""
    seen = []
    keys = set()
    for line in text.splitlines():
        if line.startswith("ENDMDL"):
            break
        if line.startswith(("ATOM  ", "HETATM")):
            k = (line[:6].strip(), line[17:20].strip(), line[21], line[22:27].strip())
            if k not in keys:
                keys.add(k)
                seen.append(k)
    return seen


def _strands(cg_lines):
    out, cur = [], None
    for line in cg_lines:
        if line.startswith("ATOM"):
            res, chain, num = line[17:20].strip(), line[21], int(line[22:26])
            if cur is None:
                cur = {"chain": chain.strip() or "-", "first": num, "residues": []}
            if not cur["residues"] or cur["residues"][-1][1] != num:
                cur["residues"].append((res, num))
        elif line.startswith("TER") and cur:
            if not all(r in BASE_OF for r, _ in cur["residues"]):    # channel cation
                cur = None
                continue
            cur["last"] = cur["residues"][-1][1]
            cur["n"] = len(cur["residues"])
            cur["sequence"] = "".join(BASE_OF.get(r, "?") for r, _ in cur["residues"])
            cur["repeat"] = sum(r in convert_dna.REPEAT_RESNAMES for r, _ in cur["residues"])
            del cur["residues"]
            out.append(cur)
            cur = None
    return out


def map_structure(payload):
    """Atomistic PDB -> ηθDNA CG PDB, as build_dna.py does before tleap.

    payload: {"pdb": text, "name": str,
              "g4": {"place": true, "ion": "KW4"|"NW4", "site": "between"|"plane", "tips": false},
              "build": {"salt": 0.15, "cation": "NaW"|"KW", "ztype": true, "end_restraint": true}}
    """
    text = payload.get("pdb") or ""
    if not text.strip():
        raise ValueError("no PDB given")
    name = _name(payload.get("name"))
    g4o = {"place": True, "ion": "KW4", "site": "between", "tips": False, **(payload.get("g4") or {})}
    if g4o["ion"] not in ("KW4", "NW4") or g4o["site"] not in ("between", "plane"):
        raise ValueError("G4 cation must be KW4 or NW4 and the site 'between' or 'plane'")
    issues = []
    with tempfile.TemporaryDirectory() as tmp:
        src = os.path.join(tmp, "input.pdb")
        with open(src, "w") as fh:
            fh.write(text)
        atoms = convert_dna.load_pdb(src)
        cg_lines = convert_dna.convert_to_cg(atoms)
        if not any(l.startswith("ATOM") for l in cg_lines):
            raise ValueError("no DNA found: the converter reads DA/DC/DG/DT residues in ATOM records")

        # what the input holds besides the mapped DNA
        res = _residues_of(text)
        kinds = Counter()
        het = Counter()
        for rec, rn, _, _ in res:
            if rn in convert_dna.CG_ATOMS and rec == "ATOM":
                kinds["DNA"] += 1
            elif rn in AMINO:
                kinds["protein"] += 1
            elif rn in WATER:
                kinds["water"] += 1
            elif rn in RNA and rec == "ATOM":
                kinds["RNA"] += 1
            else:
                het[rn] += 1
        if kinds["protein"]:
            issues.append({"level": "warning", "code": "PROTEIN",
                           "message": f"{kinds['protein']} protein residues are not mapped: the web app works on DNA only. "
                                      "Protein–DNA complexes are built with build_dna_protein.py (SIRAH protein) and "
                                      "backmapped with backmap_dna.py, in a terminal (Command line tab)."})
        n_models = sum(1 for l in text.splitlines() if l.startswith("MODEL"))
        if n_models > 1:
            issues.append({"level": "info", "code": "NMR_MODEL_1",
                           "message": f"{n_models} models in the PDB (an NMR ensemble): model 1 is mapped."})
        if kinds["RNA"]:
            issues.append({"level": "warning", "code": "RNA",
                           "message": f"{kinds['RNA']} RNA residues are not mapped: ηθDNA is a DNA model."})
        ions_in = {k: v for k, v in het.items() if k.upper() in g4.K_NAMES | g4.NA_NAMES}
        others = {k: v for k, v in het.items() if k not in ions_in}
        if others:
            listed = ", ".join(f"{k} ×{v}" for k, v in sorted(others.items()))
            issues.append({"level": "warning", "code": "NOT_MAPPED",
                           "message": f"Not mapped: {listed}. Modified nucleotides (e.g. 5-bromo-dU, BRU) break the "
                                      "strand: rename them to the parent base (BRU → DT) and keep its standard atoms."})

        # missing beads
        grouped = convert_dna.group_by_residue(atoms)
        missing = []
        for (rn, resid, chain, _), group in grouped.items():
            if rn not in convert_dna.CG_ATOMS:
                continue
            names = {a["name"] for a in group}
            lack = [x for x in convert_dna.CG_ATOMS[rn] if x != "P" and x not in names]
            if lack:
                missing.append(f"{rn}{resid}{(':' + chain) if chain else ''} ({', '.join(lack)})")
        if missing:
            issues.append({"level": "warning", "code": "MISSING_ATOMS",
                           "message": f"{len(missing)} nucleotide(s) lack atoms that become beads: "
                                      + "; ".join(missing[:8]) + (" …" if len(missing) > 8 else "")
                                      + ". tleap will stop on them: complete the structure first."})

        # G4 channel cations
        cg_path = os.path.join(tmp, "cg.pdb")
        convert_dna.write_pdb(cg_lines, cg_path)
        ions, report = g4.channel_cations(cg_lines, text.splitlines(True), g4o["ion"], g4o["site"], bool(g4o["tips"]))
        placed = []
        if report and g4o["place"]:
            g4.append_ions(cg_path, ions)
            placed = [{"ion": r, "label": lab} for r, _, lab in ions]
        elif report:
            issues.append({"level": "error", "code": "G4_EMPTY_CHANNEL",
                           "message": "G-quadruplex tetrads found and channel cations off: the build stops "
                                      "(a G4 must not be simulated with an empty channel)."})
        cg_text = open(cg_path).read()

    strands = _strands(cg_text.splitlines())
    top, frames = topology.from_pdb(cg_text)
    xyz = frames[0]
    lib = units()
    charge = sum(sum(q for _, _, q in lib[r.name]["atoms"]) for r in top.residues if r.name in lib)
    n_nt = sum(s["n"] for s in strands)
    issues += [{"level": "warning", "code": "GAP", "message": n} for n in top.notes]
    stats = {"nucleotides": n_nt, "strands": len(strands), "beads": len(top.atoms),
             "channel_ions": len(placed), "charge": round(charge, 2),
             "repeat": sum(s["repeat"] for s in strands), "input": dict(kinds), "input_other": dict(het)}

    b = {"salt": model.DEFAULT_SALT_M, "cation": "NaW", "ztype": True, "end_restraint": True, **(payload.get("build") or {})}
    args = f"{name}/{name}_cg.pdb --cg-input -o {name}/{name}"
    if float(b["salt"]) != model.DEFAULT_SALT_M:
        args += f" --salt {float(b['salt']):g}"
    if b["cation"] == "KW":
        args += " --cation KW"
    if not b["ztype"]:
        args += " --no-ztype"
    if not b["end_restraint"]:
        args += " --no-end-restraint"
    cmd = f"python build_dna.py {args}"
    run = f"bash {name}/run_md.sh {name}"
    package = _zip({f"{name}/{name}_cg.pdb": cg_text,
                    f"{name}/build.sh": _BUILD_SH.format(args=args, run=run, name=name, version=__version__),
                    f"{name}/README.txt": _BUILD_README.format(name=name, cmd=cmd, run=run, version=__version__)})
    return {"name": name, "cg_pdb": cg_text, "view_pdb": view_pdb(top, xyz), "strands": strands, "stats": stats,
            "g4": {"report": report, "placed": placed}, "issues": issues, "command": cmd, "run": run,
            "zip_b64": package}


_BUILD_SH = """#!/bin/bash
# ηθDNA: build the CG topology of {name} (made by the ηθDNA web app {version}).
# Needs AmberTools (tleap), SIRAH (SIRAH_HOME) and the ηθDNA tools: set ETATHETA to
# the folder that holds build_dna.py (and PYTHON to a Python with NumPy and ParmEd, if it is
# not python3).
set -euo pipefail
cd "$(dirname "$0")/.."
: "${{ETATHETA:?set ETATHETA to the folder of the ηθDNA tools (build_dna.py)}}"
: "${{SIRAH_HOME:?set SIRAH_HOME to your SIRAH installation}}"
"${{PYTHON:-python3}}" "$ETATHETA/build_dna.py" {args}
echo "Then run the simulation with: {run}"
"""


_BUILD_README = """{name}: ηθDNA coarse-grained input, made by the ηθDNA web app {version}.

{name}_cg.pdb   the CG structure (ηθDNA beads, plus the G4 channel cations if any)
build.sh        builds the topology with tleap and SIRAH

To build it (AmberTools, SIRAH and the ηθDNA tools on your computer), from the
folder that holds {name}/:

    export ETATHETA=/path/to/the/ηθDNA/tools SIRAH_HOME=/path/to/sirah
    bash {name}/build.sh          # PYTHON=... to use a Python other than python3

which runs

    {cmd}

and writes {name}/{name}.prmtop, .inpcrd, the AMBER decks and run_md.sh. Then:

    {run}
"""


# ---------------------------------------------------------------- backmapping
_PRMTOP = {}


def _prmtop(text):
    key = (len(text), hash(text))
    if key not in _PRMTOP:
        _PRMTOP.clear()
        _PRMTOP[key] = topology.from_prmtop(text)
    return _PRMTOP[key]


_CGPDB = {}


def _cg_pdb(text):
    key = (len(text), hash(text))
    if key not in _CGPDB:
        _CGPDB.clear()
        _CGPDB[key] = topology.from_pdb(text)
    return _CGPDB[key]


def _composition(top, n_atoms=None):
    n = len(top.atoms) if n_atoms is None else n_atoms
    solute = [r for r in top.residues if r.atoms and r.atoms[0].idx < n]
    return dict(Counter("DNA" if r.name in BASE_OF else "channel ion" if r.name in model.CHANNEL_IONS
                        else "protein" if any(a.name == "GN" for a in r.atoms)
                        else "solvent" if r.name in ("WT4", "NaW", "ClW", "KW", "WAT", "HOH") else "other"
                        for r in solute))


def pdb_info(payload):
    """Frames and content of a CG PDB (for the backmap form)."""
    top, coords = _cg_pdb(payload.get("cg_pdb") or "")
    return {"frames": len(coords), "atoms": len(top.atoms), "residues": len(top.residues),
            "content": _composition(top), "notes": top.notes}


def prmtop_info(payload):
    top = _prmtop(payload.get("prmtop") or "")
    n_solute = topology.solute_atoms(top)
    return {"natom": len(top.atoms), "n_solute": n_solute, "residues": len(top.residues),
            "solute": _composition(top, n_solute)}


def nc_header(payload):
    """payload: {"head_b64": first bytes of the file, "file_size": int}.
    Returns the frame layout, or {"need_bytes": n} if the header is longer."""
    head = base64.b64decode(payload["head_b64"])
    try:
        h = netcdf.header(head, payload.get("file_size"))
    except netcdf.NeedMoreBytes:
        return {"need_bytes": 4 * len(head)}
    if "natom" not in h:
        raise ValueError("this NetCDF file has no 'coordinates': not an AMBER trajectory")
    c = h["vars"]["coordinates"]
    return {"natom": h["natom"], "nframes": h["nframes"], "begin": c["begin"], "recsize": h["recsize"],
            "program": h["program"], "conventions": h["conventions"]}


def _frames(payload):
    """(topology, coords (n, natom', 3), frame labels, source text)."""
    if payload.get("cg_pdb"):
        top, coords = _cg_pdb(payload["cg_pdb"])
        return top, coords, list(range(1, len(coords) + 1)), "CG PDB"
    if not payload.get("prmtop"):
        raise ValueError("give a CG PDB, or a prmtop with coordinates")
    top = _prmtop(payload["prmtop"])
    natom = len(top.atoms)
    if payload.get("frames_b64"):
        n = int(payload["n_atoms"])
        coords = np.array([netcdf.coordinates(base64.b64decode(b), n) for b in payload["frames_b64"]])
        labels = payload.get("frame_ids") or list(range(1, len(coords) + 1))
        return top, coords, labels, "trajectory"
    c = payload.get("coords") or {}
    if c.get("format") == "rst7":
        return top, topology.read_restart(c["text"], natom), [1], "restart"
    if c.get("format") == "pdb":
        n_solute = topology.solute_atoms(top)
        try:
            coords = topology.read_pdb_frames(c["text"], natom)
        except ValueError:
            coords = topology.read_pdb_frames(c["text"], n_solute)    # solvent stripped
        return top, coords, list(range(1, len(coords) + 1)), "PDB"
    raise ValueError("no coordinates given for the prmtop")


def backmap(payload):
    """CG frames -> all-atom heavy atoms (cg_backmap.reconstruct), one MODEL
    per frame: the DNA and the G4 channel cations. The web app works on DNA
    only, so SIRAH protein residues are counted and skipped (backmap_dna.py
    rebuilds them, in a terminal).

    payload: {"cg_pdb": text} or {"prmtop": text, "coords": {"format": "rst7"|"pdb", "text"}}
             or {"prmtop": text, "frames_b64": [...], "n_atoms": n, "frame_ids": [...]};
             "frames": [0-based indices] to keep only some; "conformers": true;
             "first_model": number of the first MODEL written (the app sends the frames in batches).
    """
    top, coords, labels, source = _frames(payload)
    pick = payload.get("frames")
    if pick is not None:
        pick = [int(i) for i in pick if 0 <= int(i) < len(coords)]
        coords, labels = coords[pick], [labels[i] for i in pick]
    if len(coords) > MAX_FRAMES:
        raise ValueError(f"{len(coords)} frames: the web app backmaps up to {MAX_FRAMES} at a time "
                         "(backmap_dna.py has no limit)")
    conformers = bool(payload.get("conformers", True))
    _check_beads(top)
    recipes = recipe.load_recipes(bpaths.BACKMAP_DNA_JSON, bpaths.BACKMAP_SIRAH_JSON)
    natom_given = coords.shape[1]
    targets = reconstruct.find_dna_chains(top) + reconstruct.find_channel_ions(top)
    n_protein = sum(len(c) for c in reconstruct.find_protein_chains(top))
    models, totals, rows, flags_all, warnings, codes = [], Counter(), [], [False, False, False], [], []
    first_summary = None
    with tempfile.TemporaryDirectory() as tmp:
        for k, (xyz, label) in enumerate(zip(coords, labels)):
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                full = _pad(xyz, len(top.atoms), natom_given)
                chains = [reconstruct.reconstruct_chain(c, top, full, recipes, allow_unmapped=True, conformers=conformers)
                          for c in targets]
            warnings += [w for w in out.getvalue().splitlines() if w and w not in warnings]
            chains = [c for c in chains if c]
            if not chains:
                raise ValueError("no ηθDNA nucleotide found to backmap" + (
                    f" (only {n_protein} SIRAH protein residues: backmap them with backmap_dna.py in a terminal)"
                    if n_protein else ": is this an ηθDNA CG structure?"))
            path = os.path.join(tmp, "heavy.pdb")
            flags = reconstruct.write_heavy_pdb(chains, path)
            flags_all = [x or y for x, y in zip(flags_all, flags)]
            body = [l for l in open(path).read().splitlines() if l and not l.startswith("END")]
            models.append(f"MODEL     {k + int(payload.get('first_model', 1)):4d}\n" + "\n".join(body) + "\nENDMDL")
            templ = Counter(r["conformer"] for c in chains for r in c if "conformer" in r)
            totals += templ
            codes.append("".join(CODE.get(r.get("conformer"), "-") for c in chains for r in c))
            if k == 0:
                for ci, c in enumerate(chains):
                    cid = chr(ord("A") + ci % 26)
                    for ri, r in enumerate(c, 1):
                        rows.append({"chain": cid, "resid": ri, "resname": r["output_resname"],
                                     "template": r.get("conformer", "")})
                first_summary = {
                    "dna_chains": sum(1 for c in chains if c[0]["output_resname"] in reconstruct.DNA_OUTPUT_RESNAMES),
                    "nucleotides": sum(1 for c in chains for r in c if r["output_resname"] in reconstruct.DNA_OUTPUT_RESNAMES),
                    "protein_skipped": n_protein,
                    "channel_ions": sum(1 for c in chains for r in c if r["output_resname"] in reconstruct.ION_OUTPUT_RESNAMES),
                    "heavy_atoms": sum(len(r["atoms"]) for c in chains for r in c),
                }
    issues = [{"level": "warning", "code": "UNMAPPED", "message": w.replace("Warning: ", "")} for w in warnings]
    issues += [{"level": "warning", "code": "GAP", "message": n} for n in getattr(top, "notes", [])]
    if n_protein:
        issues.append({"level": "warning", "code": "PROTEIN_SKIPPED",
                       "message": f"{n_protein} SIRAH protein residues were not rebuilt: the web app works on DNA only. "
                                  "Backmap protein–DNA complexes with backmap_dna.py, in a terminal (Command line tab)."})
    pdb = "\n".join(models) + "\nEND\n"
    return {"pdb": pdb, "frames": len(models), "frame_ids": labels, "source": source, "summary": first_summary,
            "templates": dict(totals), "residues": rows, "codes": codes, "conformers": conformers,
            "has": {"protein": flags_all[0], "dna": flags_all[1], "ions": flags_all[2]}, "issues": issues}


def _check_beads(top):
    """Every nucleotide must have all the beads of its unit, or the
    reconstruction stops on it: say which ones lack what."""
    lib = units()
    bad = []
    for r in top.residues:
        if r.name in BASE_OF and r.name in lib:
            have = {a.name for a in r.atoms}
            lack = [n for n, _, _ in lib[r.name]["atoms"] if n not in have]
            if lack:
                bad.append(f"{r.name} {r.number}{(' ' + r.chain.strip()) if r.chain.strip() else ''} ({', '.join(lack)})")
    if bad:
        raise ValueError(f"{len(bad)} nucleotide(s) lack beads: " + "; ".join(bad[:6]) + (" …" if len(bad) > 6 else ""))


def _pad(xyz, natom, n_given):
    """Trajectory frames hold only the solute (the first n atoms): the
    solvent atoms after them are never read by the reconstruction, but the
    array must cover every atom index of the topology."""
    if n_given == natom:
        return xyz
    full = np.zeros((natom, 3))
    full[:n_given] = xyz
    return full


def _split_models(pdb):
    models, cur = [], []
    for line in pdb.splitlines():
        if line.startswith("MODEL"):
            cur = []
        elif line.startswith("ENDMDL"):
            models.append("\n".join(cur) + "\nEND\n")
            cur = []
        elif line.startswith(("ATOM", "HETATM", "TER")):
            cur.append(line)
    if cur:
        models.append("\n".join(cur) + "\nEND\n")
    return models


def backmap_package(payload):
    """The second half of backmap_dna.py, to run with AmberTools: hydrogens
    and the short vacuum minimization of every frame (tleap + sander, same
    protocol and defaults as cg_backmap/hydrogenate.py), one trajectory, and
    optionally frame 1 re-solvated (cg_backmap/resolvate.py).

    payload: {"pdb": the multi-model PDB of backmap(), "has": {...}, "name", "resolvate": bool}
    """
    name = _name(payload.get("name"), "backmapped")
    frames = _split_models(payload.get("pdb") or "")
    if not frames:
        raise ValueError("no backmapped frames")
    has = payload.get("has") or {}
    sources = hydrogenate.force_field_sources(bool(has.get("protein")), bool(has.get("dna", True)),
                                              bool(has.get("ions")))
    files = {}
    for k, text in enumerate(frames, 1):
        f = f"frame_{k:04d}"
        files[f"{name}/frames/{f}.pdb"] = text
        files[f"{name}/leap/{f}.in"] = hydrogenate._LEAP_TEMPLATE.format(
            source_lines=sources, heavy_pdb=f"frames/{f}.pdb", prmtop=f"work/{f}.prmtop", rst7=f"work/{f}.rst7")
    files[f"{name}/min.in"] = hydrogenate._MIN_IN_TEMPLATE.format(maxcyc=150, ncyc=100, cutoff=12.0)
    solv = bool(payload.get("resolvate"))
    if solv:
        files[f"{name}/resolvate.in"] = resolvate._TLEAP_TEMPLATE.format(
            source_lines=hydrogenate.force_field_sources(bool(has.get("protein")), bool(has.get("dna", True)), True),
            solute_pdb="work/solute.pdb", box_pad=10.0, prmtop=f"{name}_solvated.prmtop",
            inpcrd=f"{name}_solvated.inpcrd")
    files[f"{name}/run.sh"] = _RUN_SH.format(name=name, version=__version__, n=len(frames),
                                             resolvate=_RESOLVATE_SH.format(name=name) if solv else "")
    files[f"{name}/README.txt"] = _RUN_README.format(name=name, version=__version__, n=len(frames),
                                                     solv=f"\n{name}_solvated.prmtop/.inpcrd   frame 1 in a TIP3P box (--resolvate)" if solv else "")
    return {"zip_b64": _zip(files), "files": len(files)}


_RUN_SH = """#!/bin/bash
# ηθDNA backmap of {name}, second step (made by the ηθDNA web app {version}): hydrogens and a
# short vacuum minimization of each of the {n} frame(s), as backmap_dna.py does, then one
# trajectory. Needs AmberTools (tleap, sander, cpptraj).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p work
for f in frames/frame_*.pdb; do
  n=$(basename "$f" .pdb)
  echo "== $n"
  tleap -f "leap/$n.in" > "work/$n.tleap.log" || {{ echo "tleap failed: work/$n.tleap.log"; exit 1; }}
  sander -O -i min.in -p "work/$n.prmtop" -c "work/$n.rst7" -o "work/$n.min.out" -r "work/$n.min.rst7"
done
{{ echo "parm work/frame_0001.prmtop"
  for r in work/frame_*.min.rst7; do echo "trajin $r"; done
  echo "trajout {name}.nc netcdf"
  echo "trajout {name}.pdb pdb model"
  echo "run"; }} | cpptraj > work/cpptraj.log
cp work/frame_0001.prmtop {name}.prmtop
{resolvate}echo "Done: {name}.prmtop + {name}.nc (and {name}.pdb)"
"""

_RESOLVATE_SH = """echo -e "parm work/frame_0001.prmtop\\ntrajin work/frame_0001.min.rst7\\ntrajout work/solute.pdb pdb\\nrun" | cpptraj > work/cpptraj_solute.log
tleap -f resolvate.in > work/resolvate.log
"""

_RUN_README = """{name}: ηθDNA backmap made by the ηθDNA web app {version}.

frames/frame_NNNN.pdb   the {n} reconstructed frame(s), heavy atoms only
leap/, min.in           tleap and sander inputs (hydrogens + 150-step vacuum minimization)
run.sh                  runs them all (AmberTools: tleap, sander, cpptraj)

    bash {name}/run.sh

writes {name}.prmtop and {name}.nc (all frames, with hydrogens) and {name}.pdb.{solv}
"""
