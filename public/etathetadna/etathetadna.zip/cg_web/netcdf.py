"""Read AMBER NetCDF trajectories (md.nc, ...) without the netCDF library.

AMBER writes NetCDF 3 ("classic" or "64-bit offset"): a header that lists
dimensions, attributes and variables with their byte offsets, then the data.
``header()`` parses the header (from the first bytes of the file only) and
``frame_span()`` gives where the coordinates of one frame are, so the web app
slices just those bytes from the file the user picked: a trajectory of
gigabytes never has to be loaded whole. ``coordinates()`` decodes them.

Reference: the NetCDF classic format specification
(https://docs.unidata.ucar.edu/netcdf-c/current/file_format_specifications.html).
"""
import struct

import numpy as np

NC_DIMENSION, NC_VARIABLE, NC_ATTRIBUTE = 0x0A, 0x0B, 0x0C
TYPES = {1: ("b", 1), 2: ("c", 1), 3: (">i2", 2), 4: (">i4", 4), 5: (">f4", 4), 6: (">f8", 8)}
STREAMING = 0xFFFFFFFF


class NeedMoreBytes(ValueError):
    """The header goes on past the bytes given: call again with more."""


class _Reader:
    def __init__(self, data):
        self.data, self.pos = data, 0

    def take(self, n):
        if self.pos + n > len(self.data):
            raise NeedMoreBytes(f"header longer than {len(self.data)} bytes")
        out = self.data[self.pos:self.pos + n]
        self.pos += n
        return out

    def int32(self):
        return struct.unpack(">i", self.take(4))[0]

    def uint32(self):
        return struct.unpack(">I", self.take(4))[0]

    def int64(self):
        return struct.unpack(">q", self.take(8))[0]

    def name(self):
        n = self.int32()
        s = self.take(n).decode("utf-8", "replace")
        self.take((4 - n % 4) % 4)
        return s

    def values(self, nc_type, n):
        code, size = TYPES[nc_type]
        raw = self.take(n * size)
        self.take((4 - (n * size) % 4) % 4)
        if nc_type == 2:
            return raw.decode("utf-8", "replace").rstrip("\x00")
        return np.frombuffer(raw, dtype=code).tolist()

    def attributes(self):
        tag, n = self.uint32(), self.uint32()
        if tag not in (0, NC_ATTRIBUTE):
            raise ValueError("bad NetCDF attribute list")
        out = {}
        for _ in range(n):
            name = self.name()
            nc_type, count = self.uint32(), self.uint32()
            out[name] = self.values(nc_type, count)
        return out


def header(data, file_size=None):
    """Parse the header of a NetCDF 3 file from its first bytes.

    Returns {"version", "dims": {name: length}, "record_dim", "numrecs",
    "attrs", "vars": {name: {dims, type, vsize, begin, record}}, "recsize"}.
    For an AMBER trajectory also {"natom", "nframes", "program"}. Raises
    NeedMoreBytes if ``data`` stops inside the header.
    """
    r = _Reader(bytes(data))
    magic = r.take(4)
    if magic[:3] != b"CDF" or magic[3] not in (1, 2):
        raise ValueError("not a NetCDF 3 file (an AMBER .nc trajectory)")
    version = magic[3]
    numrecs = r.uint32()
    tag, n = r.uint32(), r.uint32()
    if tag not in (0, NC_DIMENSION):
        raise ValueError("bad NetCDF dimension list")
    dims, dim_names, record_dim = {}, [], None
    for _ in range(n):
        name, length = r.name(), r.uint32()
        dims[name] = length
        dim_names.append(name)
        if length == 0:
            record_dim = name
    attrs = r.attributes()
    tag, n = r.uint32(), r.uint32()
    if tag not in (0, NC_VARIABLE):
        raise ValueError("bad NetCDF variable list")
    variables = {}
    for _ in range(n):
        name = r.name()
        ids = [r.uint32() for _ in range(r.uint32())]
        vattrs = r.attributes()
        nc_type, vsize = r.uint32(), r.uint32()
        begin = r.int32() if version == 1 else r.int64()
        vdims = [dim_names[i] for i in ids]
        variables[name] = dict(dims=vdims, type=nc_type, vsize=vsize, begin=begin,
                               record=bool(vdims) and vdims[0] == record_dim, attrs=vattrs)
    rec_vars = [v for v in variables.values() if v["record"]]
    if len(rec_vars) == 1:          # a lone record variable is not padded (spec)
        code, size = TYPES[rec_vars[0]["type"]]
        n_el = 1
        for d in rec_vars[0]["dims"][1:]:
            n_el *= dims[d]
        recsize = n_el * size
    else:
        recsize = sum(v["vsize"] for v in rec_vars)
    if numrecs == STREAMING:
        if file_size is None or not rec_vars:
            raise ValueError("streaming NetCDF file: its size is needed to count the frames")
        first = min(v["begin"] for v in rec_vars)
        numrecs = (file_size - first) // recsize if recsize else 0
    out = dict(version=version, dims=dims, record_dim=record_dim, numrecs=numrecs, attrs=attrs,
               vars=variables, recsize=recsize, header_bytes=r.pos)
    if "coordinates" in variables:
        c = variables["coordinates"]
        if c["dims"][1:] != ["atom", "spatial"] or c["type"] != 5:
            raise ValueError("unexpected layout of the 'coordinates' variable")
        out.update(natom=dims["atom"], nframes=numrecs,
                   program=f"{attrs.get('program', '')} {attrs.get('programVersion', '')}".strip(),
                   conventions=attrs.get("Conventions", ""))
    return out


def frame_span(hdr, frame, n_atoms=None):
    """(offset, length) in the file of the coordinates of one frame (0-based),
    for its first n_atoms atoms (all when None): AMBER stores the atoms of a
    frame contiguously, so the solute is a prefix of it."""
    if "natom" not in hdr:
        raise ValueError("no 'coordinates' variable: not an AMBER trajectory")
    if not 0 <= frame < hdr["nframes"]:
        raise ValueError(f"frame {frame + 1} out of 1-{hdr['nframes']}")
    n = hdr["natom"] if n_atoms is None else n_atoms
    c = hdr["vars"]["coordinates"]
    return c["begin"] + frame * hdr["recsize"], n * 12


def coordinates(raw, n_atoms):
    """(n_atoms, 3) float coordinates from the bytes of frame_span()."""
    if len(raw) != n_atoms * 12:
        raise ValueError(f"{len(raw)} bytes for {n_atoms} atoms")
    return np.frombuffer(bytes(raw), dtype=">f4").astype(float).reshape(n_atoms, 3)
