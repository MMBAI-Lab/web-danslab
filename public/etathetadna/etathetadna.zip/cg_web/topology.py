"""CG topologies without ParmEd, for the web app (Pyodide has no ParmEd).

cg_backmap.reconstruct walks residues, atoms and bond partners. The classes
here offer those attributes (``residues``, ``atoms``, ``Atom.bond_partners``,
``Atom.residue``, ``Residue.idx``...), built from

  - a CG PDB (from convert_dna.py, the web app's Map tab, or a cpptraj frame):
    the bonds between residues are inferred, see ``from_pdb``;
  - an AMBER prmtop (text): names, residues and bonds as written by tleap.

Coordinates come from a PDB (one frame per MODEL), an ASCII restart
(rst7/inpcrd) or, for trajectories, cg_web.netcdf.
"""
import re

import numpy as np

from cg_dna.model import KNAMES, PNAMES

# inter-residue bonds inferred from a PDB: C4'(i)-P(i+1) is 3.9 A in the
# ηθDNA topology, GO(i-1)-GN(i) 2.25 A in SIRAH's protein backbone
DNA_LINK_MAX = 6.0
PROTEIN_LINK_MAX = 4.0


class Atom:
    __slots__ = ("name", "idx", "residue", "bond_partners")

    def __init__(self, name, idx, residue):
        self.name, self.idx, self.residue = name, idx, residue
        self.bond_partners = []


class Residue:
    __slots__ = ("name", "idx", "atoms", "chain", "number", "segment")

    def __init__(self, name, idx, chain="", number=0, segment=0):
        self.name, self.idx, self.chain, self.number, self.segment = name, idx, chain, number, segment
        self.atoms = []

    def atom(self, names):
        return next((a for a in self.atoms if a.name in names), None)


class Topology:
    """Residues and atoms in file order, with explicit bonds."""

    def __init__(self):
        self.residues, self.atoms = [], []
        self.notes = []

    def add_residue(self, name, chain="", number=0, segment=0):
        r = Residue(name, len(self.residues), chain, number, segment)
        self.residues.append(r)
        return r

    def add_atom(self, residue, name):
        a = Atom(name, len(self.atoms), residue)
        residue.atoms.append(a)
        self.atoms.append(a)
        return a

    @staticmethod
    def bond(a, b):
        if b not in a.bond_partners:
            a.bond_partners.append(b)
            b.bond_partners.append(a)


# ---------------------------------------------------------------- PDB
def _pdb_atoms(text):
    """[(frame, record fields)] of ATOM/HETATM lines; frame counts MODEL
    records (0 when there are none); 'segment' counts TER records within a
    frame."""
    out, frame, segment, seen_model = [], 0, 0, False
    for line in text.splitlines():
        rec = line[:6]
        if rec.startswith("MODEL"):
            if seen_model:
                frame += 1
            seen_model, segment = True, 0
        elif rec.startswith("TER"):
            segment += 1
        elif rec in ("ATOM  ", "HETATM"):
            try:
                xyz = (float(line[30:38]), float(line[38:46]), float(line[46:54]))
                number = int(line[22:26])
            except ValueError as e:
                raise ValueError(f"bad PDB record: {line.rstrip()!r}") from e
            out.append((frame, dict(name=line[12:16].strip(), resname=line[17:21].strip(), chain=line[21],
                                    number=number, icode=line[26], segment=segment, xyz=xyz)))
    if not out:
        raise ValueError("no ATOM/HETATM records in the PDB")
    return out


def from_pdb(text):
    """(Topology, coords) from a CG PDB. coords: (n_frames, natom, 3); every
    MODEL must hold the same atoms in the same order as the first.

    Bonds between residues are inferred as tleap makes them (_infer_links):
    within a TER segment, the C4' bead of a residue to the P bead of the
    next one (a 5' end has no P bead, so strands break there by
    themselves) and GO of a SIRAH protein residue to GN of the next one."""
    records = _pdb_atoms(text)
    first = [r for f, r in records if f == 0]
    top = Topology()
    res, key = None, None
    for r in first:
        k = (r["segment"], r["chain"], r["number"], r["icode"], r["resname"])
        if k != key:
            res, key = top.add_residue(r["resname"], r["chain"], r["number"], r["segment"]), k
        top.add_atom(res, r["name"])
    n = len(first)
    frames = {}
    for f, r in records:
        frames.setdefault(f, []).append(r["xyz"])
    bad = [f + 1 for f, xyz in frames.items() if len(xyz) != n]
    if bad:
        raise ValueError(f"model(s) {bad[:5]} do not have the {n} atoms of the first model")
    coords = np.array([frames[f] for f in sorted(frames)], dtype=float)
    _infer_links(top, coords[0])
    return top, coords


def _infer_links(top, xyz):
    """Join consecutive residues of a TER segment the way tleap does (C4'
    bead to the next P bead; GO to the next GN), and close a ring when the
    last C4' bead of a segment is next to its first P bead. A link longer
    than DNA_LINK_MAX / PROTEIN_LINK_MAX is kept, as tleap would, and noted
    in top.notes (a gap in the structure)."""
    def dist(a, b):
        return float(np.linalg.norm(xyz[a.idx] - xyz[b.idx]))

    segments = {}
    for r in top.residues:
        segments.setdefault(r.segment, []).append(r)
    for rs in segments.values():
        for prev, cur in zip(rs, rs[1:]):
            for a, b, cut in ((prev.atom(KNAMES), cur.atom(PNAMES), DNA_LINK_MAX),
                              (prev.atom(("GO",)), cur.atom(("GN",)), PROTEIN_LINK_MAX)):
                if a is None or b is None:
                    continue
                top.bond(a, b)
                d = dist(a, b)
                if d > cut:
                    top.notes.append(f"{prev.name} {prev.number} and {cur.name} {cur.number} ({cur.chain.strip() or '-'}) are "
                                     f"joined across {d:.1f} A, as tleap would: there is a gap in the strand")
        if len(rs) > 2:
            k, p = rs[-1].atom(KNAMES), rs[0].atom(PNAMES)
            if k is not None and p is not None and dist(k, p) < DNA_LINK_MAX:
                top.bond(k, p)


# ---------------------------------------------------------------- prmtop
def _prmtop_sections(text):
    """{FLAG: (fortran format, [data lines])}"""
    sections, flag, fmt = {}, None, None
    for line in text.splitlines():
        if line.startswith("%FLAG"):
            flag = line.split()[1]
            sections[flag] = [None, []]
        elif line.startswith("%FORMAT") and flag:
            sections[flag][0] = line[line.index("(") + 1:line.rindex(")")]
        elif line.startswith("%") or flag is None:
            continue
        else:
            sections[flag][1].append(line)
    return sections


def _fortran_values(fmt, lines, kind):
    m = re.fullmatch(r"(\d+)([aIE])(\d+)(?:\.\d+)?", fmt.strip())
    if not m:
        raise ValueError(f"unsupported prmtop format {fmt!r}")
    width = int(m.group(3))
    out = []
    for line in lines:
        line = line.rstrip("\n")
        for i in range(0, len(line), width):
            field = line[i:i + width]
            if not field.strip() and kind != str:
                continue
            out.append(field.strip() if kind == str else kind(field))
    return out


def from_prmtop(text):
    """Topology from an AMBER prmtop (text). Only names, residues and bonds
    are read."""
    if "%FLAG POINTERS" not in text:
        raise ValueError("not an AMBER prmtop (no %FLAG POINTERS)")
    s = _prmtop_sections(text)

    def get(flag, kind):
        if flag not in s:
            raise ValueError(f"prmtop has no %FLAG {flag}")
        fmt, lines = s[flag]
        return _fortran_values(fmt, lines, kind)

    natom = get("POINTERS", int)[0]
    names = get("ATOM_NAME", str)[:natom]
    labels = get("RESIDUE_LABEL", str)
    pointers = get("RESIDUE_POINTER", int)
    labels = labels[:len(pointers)]
    top = Topology()
    starts = [p - 1 for p in pointers] + [natom]
    for i, label in enumerate(labels):
        r = top.add_residue(label, number=i + 1)
        for j in range(starts[i], starts[i + 1]):
            top.add_atom(r, names[j])
    for flag in ("BONDS_INC_HYDROGEN", "BONDS_WITHOUT_HYDROGEN"):
        v = get(flag, int) if flag in s else []
        for i in range(0, len(v) - 2, 3):
            top.bond(top.atoms[v[i] // 3], top.atoms[v[i + 1] // 3])
    return top


# ---------------------------------------------------------------- coordinates
def read_restart(text, natom):
    """(1, natom, 3) coordinates from an ASCII AMBER restart (rst7/inpcrd)."""
    lines = text.splitlines()
    if len(lines) < 3:
        raise ValueError("restart file too short")
    try:
        n = int(lines[1].split()[0])
    except (IndexError, ValueError) as e:
        raise ValueError("second line of the restart does not start with the atom count") from e
    if n != natom:
        raise ValueError(f"restart has {n} atoms, the topology {natom}")
    vals = []
    for line in lines[2:]:
        for i in range(0, len(line.rstrip()), 12):
            vals.append(float(line[i:i + 12]))
            if len(vals) == 3 * natom:
                return np.array(vals, dtype=float).reshape(1, natom, 3)
    raise ValueError(f"restart ends before the {natom} coordinates")


def read_pdb_frames(text, natom):
    """(n_frames, natom, 3) from a PDB whose atoms follow the topology order
    (e.g. written by cpptraj from the same prmtop)."""
    records = _pdb_atoms(text)
    frames = {}
    for f, r in records:
        frames.setdefault(f, []).append(r["xyz"])
    bad = [(f + 1, len(x)) for f, x in frames.items() if len(x) != natom]
    if bad:
        raise ValueError(f"the PDB has {bad[0][1]} atoms in model {bad[0][0]}, the topology {natom}: "
                         "write the frames from the same (unstripped) topology")
    return np.array([frames[f] for f in sorted(frames)], dtype=float)


def solute_atoms(top, solvent=("WT4", "NaW", "ClW", "KW", "WAT", "Na+", "Cl-", "K+")):
    """Atoms before the first solvent/bulk-ion residue: everything the
    backmap needs (tleap puts the solute first). Lets the web app read only
    that part of every trajectory frame."""
    for r in top.residues:
        if r.name in solvent:
            return r.atoms[0].idx
    return len(top.atoms)
