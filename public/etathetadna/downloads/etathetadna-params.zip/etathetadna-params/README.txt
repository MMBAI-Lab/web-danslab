ηθDNA 1.0 parameters (ηθDNA tools 1.0.0.gb5a3b95; v18 in the development history).

Residue libraries (tleap loadoff):
  dna_vf.lib        CG nucleotides: internal (DGX...), 5' (GX5...), 3' (GX3...), modified C
  repeat.lib        'repeat' variants DA1/DC1/DG1/DT1 (runs of identical internal bases)
  cationes_g4.lib   G-quadruplex channel cations KW4 (K+) and NW4 (Na+)

frcmod/, loaded in this order after SIRAH's own files (cg_dna/paths.py, FRCMOD_FILES):
  1. umbrella_v16.dat                       base force field (PG vdW fix, eta/theta and cousins at 0)
  2. repeat_AT_v15.dat                      A/T "repeat"-variant bonded terms
  3. repeat_GC_v15.dat                      G/C "repeat"-variant bonded terms
  4. v16_zero_pk_torsions.frcmod            zeroes the 1D P-K torsions (replaced by the CMAP)
  5. LJoff_eta-theta.frcmod                 off-diagonal LJ: WC/Hoogsteen/sugar-edge pairing strengths
  6. cationes_g4.frcmod                     G4 channel cations KW4/NW4 (bare-ion radii towards the channel beads)
  7. zero_cousin_dihedrals_fixed.frcmod     zeroes the cross-residue "cousin" torsions
  8. soft_junction_angles_k10.frcmod        junction angles K-N-base, N-K-P, K-P-K (k reset to 20 after tleap)

cmap/ (injected after tleap by cg_dna/cmap.py; 24 x 24 grids):
  etatheta_{A,C,G,T}.dat   CMAP eta/theta per base
  etatheta_{GZ,CZ}.dat     the same for Z-typed G and C
  chi_{A,C,G,T}.dat        CMAP phi/chi per base

run_md.sh             resume-safe runner of the ηθDNA 1.0 protocol (copied next to every build)
backmap_dna.json      backmapping recipe of the ηθDNA beads (B, A, syn and Z templates, channel cations)
backmap_sirah.json    SIRAH's protein/water backmapping recipe

The topology is not just tleap + these files: the build applies the junction angles, kn5,
the C4' improper, the Z typing and the 3pB torsions to the prmtop (cg_dna/topology.py).
Build systems with build_dna.py / build_dna_protein.py (etathetadna-tools.zip).
