#!/bin/bash
# ηθDNA 1.0: runs one replica of a system built by build_dna.py / build_dna_protein.py, up to TARGET_NS of production.
# Resume-safe: re-launch it and it continues from the last finished stage.
#
#   bash run_md.sh <name> [TARGET_NS=1000]       (run from anywhere; works in the directory of this script)
#
# DNA (decks em/eq/md/md2): EM on CPU with the solute restrained -> [compaction if dens_WT4.in exists, high salt;
#   a warning in run_md.log if the volume has not settled after 40 x 50 ps]
#   -> EQ 750 ps NPT with a 0->100->298 K ramp -> production in 100 ns chunks (md, md2, md3, ...).
# DNA-protein (decks em1/em2/eq1/eq2/md/md2): em1 (backbone restrained) and em2 (whole solute) on CPU
#   -> eq1 5 ns (ramp to 300 K, solute restrained) -> eq2 25 ns (backbone, wt 0.24) -> production in 100 ns chunks.
# The EM runs on CPU (pmemd; sander if pmemd fails): on pmemd.cuda an ion placed next to a base can overflow the
# energy accumulator (-8.59e9) and leave the minimizer in a false minimum.
#
# Environment: AMBER on PATH (or AMBERHOME, or /opt/amber24, /opt/amber22).
#   WAIT_GPU=1 (default) waits until no other compute process uses the GPU before each GPU stage, so two runs never
#   share it. Set WAIT_GPU=0 on a cluster that assigns GPUs for you.
command -v pmemd.cuda >/dev/null 2>&1 || for a in "$AMBERHOME" /opt/amber24 /opt/amber22; do
  [ -n "$a" ] && [ -f "$a/amber.sh" ] && { source "$a/amber.sh"; break; }
done
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; SYS=$1; TARGET_NS=${2:-1000}; WAIT_GPU=${WAIT_GPU:-1}
[ -n "$SYS" ] || { echo "usage: run_md.sh <name> [TARGET_NS]"; exit 1; }
QLOG=$D/run_md.log; prm=$D/$SYS.prmtop; crd=$D/$SYS.inpcrd
cd "$D" || exit 1
[ -f "$prm" ] && [ -f "$crd" ] || { echo "missing $prm or $crd"; exit 1; }
tag="[$SYS $(hostname -s)]"
log () { echo "$tag $(date '+%F %T') $*" | tee -a "$QLOG"; }

check_nonan () { ! grep -v "begin time read from input coords" "$1" | grep -qE "NaN|\*\*\*\*\*\*\*\*"; }  # that header overflows past 1e6 ps
check_done () { [ -f "$1" ] && grep -q "Final Performance Info" "$1"; }
last_time_ps () { [ -f "$1" ] || { echo 0; return; }; grep "TIME(PS)" "$1" | tail -1 | awk '{for(i=1;i<=NF;i++) if($i=="TIME(PS)") print $(i+2)}'; }
wait_gpu () {
  [ "$WAIT_GPU" = 1 ] || return 0
  while nvidia-smi --query-compute-apps=pid --format=csv,noheader 2>/dev/null | grep -q '[0-9]'; do sleep 60; done
}
check_em () {  # final EM energy finite, reasonable and not above the initial one
  local e e0
  e=$(awk '/FINAL RESULTS/{f=1} f&&/NSTEP/{getline; print $2; exit}' "$1" 2>/dev/null)
  e0=$(awk '/NSTEP/{getline; print $2; exit}' "$1" 2>/dev/null)
  awk -v e="$e" -v e0="$e0" 'BEGIN{exit !(e!="" && e+0>-1e7 && e+0<1e7 && (e0=="" || e+0 <= e0+0))}'
}
em_cpu () {  # em_cpu <deck> <coords> <ref> <prefix>
  [ -f "$4.rst" ] && check_em "$4.out" && return 0
  log "=== $4 (EM on CPU, $1) ==="
  if ! pmemd -O -i "$1" -p "$prm" -c "$2" -r "$4.rst" -o "$4.out" -ref "$3" || ! check_em "$4.out"; then
    log "pmemd (CPU) failed in $4 -> sander"
    sander -O -i "$1" -p "$prm" -c "$2" -r "$4.rst" -o "$4.out" -ref "$3" || { log "$4 FAILED"; return 1; }
  fi
  check_em "$4.out" || { log "$4: abnormal final energy $(awk '/FINAL RESULTS/{f=1} f&&/NSTEP/{getline; print $2; exit}' "$4.out")"; return 1; }
  log "$4 ok: final E $(awk '/FINAL RESULTS/{f=1} f&&/NSTEP/{getline; print $2; exit}' "$4.out")"
}
md_gpu () {  # md_gpu <deck> <coords> <ref> <prefix>
  check_done "$4.out" && check_nonan "$4.out" && return 0
  log "=== $4 ($1) ==="
  wait_gpu
  pmemd.cuda -O -i "$1" -p "$prm" -c "$2" -r "$4.rst" -x "$4.nc" -o "$4.out" -ref "$3"
  check_done "$4.out" && check_nonan "$4.out" || { log "$4 FAILED/NaN"; return 1; }
  log "$4 ok: $(grep 'ns/day' "$4.out" | tail -1 | awk '{print $4}') ns/day"
}

if [ -f em1_WT4.in ]; then   # DNA-protein (SIRAH multi-stage protocol)
  em_cpu em1_WT4.in "$crd" "$crd" em1 || exit 1
  em_cpu em2_WT4.in em1.rst em1.rst em2 || exit 1
  md_gpu eq1_WT4.in em2.rst em2.rst eq1 || exit 1
  md_gpu eq2_WT4.in eq1.rst eq1.rst eq2 || exit 1
  EQ=eq2
else                          # DNA
  em_cpu em_WT4.in "$crd" "$crd" em || exit 1
  EQIN=em.rst
  if [ -f dens_WT4.in ]; then  # high salt: 50 ps chunks until the volume changes < 0.5% within a chunk, at most 40
    if [ ! -f dens.rst ]; then
      log "=== compaction (dens_WT4.in) ==="
      wait_gpu; prev=em.rst; settled=0
      for k in $(seq 1 40); do
        pmemd.cuda -O -i dens_WT4.in -p "$prm" -c $prev -r dens$k.rst -o dens$k.out -ref $prev
        [ -f dens$k.rst ] && check_nonan dens$k.out || { log "dens$k FAILED/NaN"; exit 1; }
        prev=dens$k.rst
        dv=$(LC_ALL=C awk '/A V E R A G E S/{exit} /VOLUME/{v[++n]=$NF} END{if (n>1) printf "%.4f", (v[1]-v[n])/v[1]; else print 1}' dens$k.out)
        log "dens$k: dV/V = $dv"
        check_done dens$k.out && LC_ALL=C awk -v d="$dv" 'BEGIN{exit !(d < 0.005 && d > -0.005)}' && { settled=1; break; }
      done
      if [ $settled = 1 ]; then
        log "compaction settled in dens$k"
      else
        log "WARNING: volume not settled after 40 compaction chunks (last dV/V = $dv); going on to the EQ from $prev"
      fi
      cp $prev dens.rst
    fi
    EQIN=dens.rst
  fi
  md_gpu eq_WT4.in $EQIN $EQIN eq || exit 1
  EQ=eq
fi
EQ_PS=$(last_time_ps $EQ.out)   # production is counted from the end of the EQ

md_gpu md_WT4.in $EQ.rst $EQ.rst md || exit 1
while :; do
  lastfile=md.out; m=2
  while [ -f "md${m}.out" ]; do lastfile="md${m}.out"; m=$((m+1)); done
  check_done $lastfile || { m=$((m-1)); [ $m -lt 2 ] && m=2; lastfile=md$((m-1)).out; [ $m -eq 2 ] && lastfile=md.out; }  # cut chunk: redo it
  ns_done=$(awk -v t="$(last_time_ps $lastfile)" -v e="$EQ_PS" 'BEGIN{printf "%.0f", (t-e)/1000}')
  [ "$ns_done" -ge "$TARGET_NS" ] && break
  n=$m; prevrst="md$((n-1)).rst"; [ $n -eq 2 ] && prevrst="md.rst"
  md_gpu md2_WT4.in $prevrst $prevrst md$n || exit 1
done
log "=== DONE (${TARGET_NS} ns) ==="
