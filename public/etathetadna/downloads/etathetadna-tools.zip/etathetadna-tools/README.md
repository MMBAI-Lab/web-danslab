# ηθDNA tools

Build-input generator and CG→all-atom backmapper for **ηθDNA 1.0**, the
[ηθDNA](https://github.com/MMBAI-Lab/eta-theta-DNA) coarse-grained (CG) DNA
force field. Version 1.0 is the model developed as v18 (v18T29 + 3pB + KW4/NW4).

- **Build.** Give it an all-atom PDB and you get an AMBER-ready system:
  the `prmtop`/`inpcrd`, the input decks of the published protocol, the
  restraints on the terminal base pairs and a resume-safe run script.
- **Backmap.** When the CG run has finished, give it the trajectory and
  you get an all-atom trajectory.

No prior CG modeling experience is needed in either direction.

**Web app: <https://danslab.xyz/etathetadna/>** (also under Apps on
[danslab.xyz](https://danslab.xyz/apps/etathetadna/)). It runs the mapping and the backmapping in
the browser, with nothing sent to a server. It also has the downloads (these tools, and the
ηθDNA 1.0 parameters alone) and the reference of every command-line option.

## Versions

| Tag | What it is |
|---|---|
| `v1.0.0` (2026-11-20) | ηθDNA 1.0 and these tools, with the web app published at danslab.xyz |
| `v17` | the previous pipeline, for the v17 development model |

The version is `cg_web.__version__`: the web app shows it in its footer, and both downloads carry it in a
`VERSION` file (with the commit it was built from).

## What it does

| | `build_dna.py` | `build_dna_protein.py` |
|---|---|---|
| Input | all-atom PDB, DNA only (or `--cg-input`: a CG PDB) | all-atom PDB of a DNA-protein complex (or `--cg-input`) |
| DNA → CG | this model's mapping (`cg_dna/convert_dna.py`) | same |
| Protein → CG | — | [SIRAH](http://www.sirahff.com)'s protein mapping: `pdb2pqr` (protonation) + SIRAH's `cgconv.pl` |
| Solvent | SIRAH WT4 water, neutralized, NaCl 0.15 M by default | same, neutralized with NaW and ClW |
| Protocol | `em`, `eq`, `md`, `md2` decks (+ `dens` at high salt) | SIRAH multi-stage decks: `em1`, `em2`, `eq1`, `eq2`, `md`, `md2` |

### The ηθDNA 1.0 topology

After `tleap`, the topology gets the terms of the final model, in this
order (`cg_dna/cmap.py`, `cg_dna/topology.py`, constants in
`cg_dna/model.py`):

1. **Two CMAPs per nucleotide.** η/θ is defined over C4′(i−1)–P–C4′–P(i+1)–C4′(i+1), and φ/χ over C4′(i−1)–P–C4′–N–base. Every 1D torsion on the P–C4′ and C4′–N bonds is set to 0.
2. **Junction angles.** K–N–base, N–K–P and K–P–K keep their θ0, with k = 20.
3. **kn5 (guanine only).** P–K–N and N–K–P(i+1) get θ0 89.0 and 86.8 at k 10. C4′–N9–N3 and C4′–N9–N7 get k 5.
4. **C4′ chirality improper.** P(i)–N–K–P(i+1), with k 4, periodicity 1 and phase 60.
5. **Z typing from the input geometry.** It applies to guanines that have a *syn* base and a Z backbone, and to the cytosines next to them.
   - Their junction angles take the Z θ0 values.
   - Their η/θ CMAP is replaced by the GZ or CZ grid, where basin Ia (G) or IV (C) is deepened.
   - A *syn* G with a B backbone, as in G-quadruplex tetrads, is not typed.
   - `--no-ztype` turns this step off.
6. **3pB.** Adds base(i)–N(i)–C4′(i)–P(i+1) torsions (k 10, periodicity 2), except on Z-typed nucleotides.

CMAP terms and impropers are placed by bond connectivity, not residue
numbering. Circular strands work if the ring is closed with
`--ring-bond`, e.g. `--ring-bond 182.C4G:1.PA` for each strand.

### G-quadruplexes

A G4 is never simulated with an empty channel: without cations the
tetrads open during the minimization. SIRAH's K⁺/Na⁺ are hydrated-size ions
that do not fit between tetrads, so the channel gets its own ion types,
**KW4** (K⁺) and **NW4** (Na⁺). Towards the guanine and thymine beads and
towards each other they have bare-ion radii; towards everything else they
behave as SIRAH's KW/NaW.

When the structure has G-tetrads (`cg_dna/g4.py`), cations are handled in one of two ways:

- **Cations in the input.** If the input PDB already has K⁺/Na⁺ in the channel (a crystal), each one becomes a KW4/NW4 at the same position.
- **No cations in the input.** One cation is placed per site:
  - by default, KW4 between consecutive tetrads;
  - `--g4-cation NW4 --g4-site plane` places Na⁺ in the tetrad planes;
  - `--g4-tips` adds the sites outside the outer tetrads.

On 1JPQ the placed sites fall 0.05–0.25 Å from the crystal K⁺. Bulk salt
always uses NaW/ClW, or KW/ClW with `--cation KW`. KW4/NW4 are never used
as salt.

### End restraints and protocol

- **End restraint.** Each terminal base pair with a Watson–Crick partner in the input gets a flat-bottom distance restraint on its WC H-bonds, written to `disang.rst`: harmonic at 3.0 Å, linear outside 2–5 Å. G-quadruplex tetrads, single-stranded tails and circular strands have no such pairs and run without it.
- **Decks.** They are those of the model's benchmark campaign, run during its development as v18:
  - EM on the CPU with the solute restrained;
  - EQ of 750 ps NPT with a 0→100→298 K ramp, solute restrained;
  - production in 100 ns chunks at dt = 20 fs;
  - Monte Carlo barostat and Langevin thermostat in every NPT stage.
- **High salt (≥ 1 M).** A compaction stage (`dens_WT4.in`) runs before the EQ, in 50 ps chunks until the volume changes by less than 0.5% within one, at most 40 (2 ns). If the volume has not settled by then, `run_md.sh` writes a warning to `run_md.log` and goes on to the EQ.

## Quick start

```bash
pip install -r requirements.txt
export SIRAH_HOME=/path/to/sirah_x2.3_24-07.amber   # or pass --sirah-dir each time

# DNA only, e.g. the Drew-Dickerson dodecamer (one system per directory)
python build_dna.py examples/1bna.pdb -o out/1bna/1bna
bash out/1bna/run_md.sh 1bna            # EM -> EQ -> 10 x 100 ns (resume-safe: just re-launch it)

# Z-DNA at high salt, from a CG PDB
python build_dna.py examples/4ocb_CG.pdb --cg-input --salt 3.0 -o out/4ocb/4ocb

# DNA + protein complex
python build_dna_protein.py your_complex.pdb -o out/complex/complex

# then back to all-atom:
python backmap_dna.py out/1bna/1bna.prmtop out/1bna -o out/1bna_aa/1bna --n-frames 50
```

`out/<name>/` receives:
- `<name>.prmtop`, `<name>.inpcrd`;
- the decks;
- `disang.rst` (if the system has restrainable ends);
- `run_md.sh`;
- `build_summary.json`, which records what was typed, placed and added;
- `repeat.lib`, only when the sequence uses the repeat residues (DA1/DC1/DG1/DT1: 2+ identical consecutive internal bases). It is only needed to rebuild the system with tleap.

Rebuilding into a directory that already holds a build removes the `disang.rst` and decks that the new build does not write (for example `dens_WT4.in` after a high-salt build), since `run_md.sh` picks its stages by which decks exist.

The intermediate files go to `out/<name>/build/`: CG PDB, tleap inputs and logs, and the topology before the CMAP.

`run_md.sh <name> [TARGET_NS=1000]` runs:
- the EM on the CPU (`pmemd`, falling back to `sander`), checking the final energy;
- the GPU stages with `pmemd.cuda`.

Before each GPU stage it waits until no other compute process uses the
GPU. Set `WAIT_GPU=0` on clusters that assign GPUs for you.

Recommendations from the benchmark:
- Run **several replicas** per system (3 or more): single-replica results on G4 tetrads and Holliday junctions vary more than the differences between parameter sets.
- Never simulate a G4 without channel cations.

### Main options (both builders)

| Option | Default | Meaning |
|---|---|---|
| `--salt M` | 0.15 | salt on top of neutralization, SIRAH rule; 0 = neutralize only; the Z-DNA benchmark used 3.0 |
| `--cation NaW\|KW` | NaW | bulk cation (NaCl or KCl) |
| `--no-ztype` | | skip the Z typing |
| `--g4-cation KW4\|NW4`, `--g4-site between\|plane`, `--g4-tips` | KW4, between | channel cations placed when the input has none |
| `--no-g4-cations` | | stop instead of placing them |
| `--ring-bond RES.ATOM:RES.ATOM` | | extra tleap bond (circular strands) |
| `--no-end-restraint`, `--no-decks` | | skip the DISANG / the decks and `run_md.sh` |
| `--cg-input` | | the input is already a CG PDB |

## Going back: `backmap_dna.py` (CG → all-atom)

```
python backmap_dna.py cg.prmtop traj_dir -o out/system --n-frames 50
```

`traj_dir` holds the run's trajectory chunks (`md.nc`, `md2.nc`, ..., the
naming `run_md.sh` uses). Pass `--traj md.nc md2.nc ...` instead if your
files are named differently. `--n-frames` picks that many evenly spaced
frames across the whole run (default 50).

Each selected frame goes through these steps:
1. the CG coordinates are extracted;
2. the heavy atoms are geometrically reconstructed, with a numpy port of the NeRF/internal-coordinate method of SIRAH's `sirah_vmdtk.tcl` (no VMD needed);
3. hydrogens are added and a short vacuum minimization is run (`tleap` + `sander`), as SIRAH's own tool does.

The frames are combined into one `<prefix>.nc` (AMBER NetCDF) with a shared
`<prefix>.prmtop`.
- CG water and bulk-ion beads are not reconstructed. G4 channel cations (KW4/NW4) are kept as K⁺/Na⁺ at the bead position, with the TIP3P ion parameters (`leaprc.water.tip3p`). The output has the DNA, the protein and the channel cations. Add `--resolvate` to re-solvate frame 0 with explicit TIP3P water.
- `--jobs N` minimizes N frames in parallel.

**Nucleotide conformations.** The CG beads give the base atoms, C4′ and P; the
sugar and the rest of the backbone come from a template. There are four, each
measured on one residue of a crystal in `examples/`:

| Template | Conformation | Source |
|---|---|---|
| B (default) | anti, C2′-endo | 1BNA |
| A | anti, C3′-endo | 116D (A-DNA) |
| syn | syn G, C2′-endo (anti → syn step of a G-tract) | 1JPQ (G4) |
| Z | syn purine C3′-endo / anti pyrimidine with the Z backbone | 181D (Z-DNA) |

Each nucleotide of each frame is built with all of its templates (G has four,
A, C and T three), and the one that best fits the beads it does not copy is
kept. The fit compares C1′ as the template places it with C1′ as the base
predicts it, which separates syn from anti. It also checks the O5′–P and
O3′–P(i+1) bond lengths, which separate the puckers and the Z backbone. A
template is only eligible if the χ it gives is within 90° of the χ of its own
crystal residue, so a syn template never goes under an anti base or the
reverse. The run prints how many nucleotides took each template; `--no-conformers` builds
them all with the B template, as before. Rebuilding the CG mapping of crystals
not used for the templates gave these errors (mean |Δ| against the crystal,
after the minimization):

| Structure | χ (B only → templates) | α (B only → templates) | sugar phase P (B only → templates) |
|---|---|---|---|
| 137D, A-DNA | 16° → 6° | 19° → 22° | 58° → 14° |
| 3WBO ×3, Z-DNA | 46° → 3° | 103° → 12° | 96° → 7° |
| 2F8W ×3, Z-DNA | 45° → 7° | 122° → 15° | 97° → 13° |
| 1JRN, antiparallel G4 | 15° → 8° | 68° → 23° | 19° → 15° |
| 4DIH, thrombin aptamer (G4) | 20° → 11° | 82° → 40° | 36° → 37° |
| 1KF1, 7LL0, parallel G4 (all anti) | within 4° of B only | within 3° | within 6° |

The G4 loops still come out worst: they have conformations none of the four templates covers.

Before the minimization, the O3′–P(i+1) bond of frames from a CG simulation is often stretched (median
1.9–2.1 Å, longer with the syn template), with any template, B included: the CG geometry around the
sugar is looser than an atomistic one. The 150-step minimization closes every one (1.61 Å median, at
most 1.70 Å on 1bna, 4ocb and 1jpq frames). Giving that bond more weight in the template choice was
tried and rejected: it made B-DNA simulations take the A template (C3′-endo) for 30–60% of their
nucleotides, only to fit the bond.

The bead set is the same in ηθDNA 1.0 and the v17 development model, so trajectories of either
can be backmapped. It was tested on ηθDNA 1.0 trajectories of 1bna, 116d (3 M), 4ocb and 1jpq (with its
channel K⁺) from the benchmark campaign.

This tool needs **no SIRAH installation**. Both reconstruction recipes are bundled:
- `params/backmap_sirah.json` holds SIRAH's protein/water recipe, ported verbatim from `sirah_vmdtk.tcl`;
- `params/backmap_dna.json` holds the recipe for our DNA beads, derived from `examples/1bna.pdb`, with the A, syn and Z templates from `examples/116d.pdb`, `1jpq.pdb` and `181d.pdb` (RCSB files, unmodified).

The one-time scripts that produced them are in `cg_backmap/tools/`.

**Known limitation.** The protein protonation state (HID/HIE/HIP, …) cannot
be recovered from SIRAH's CG protein beads; `tleap` assigns its defaults
when it adds hydrogens.

## Web app: "ηθDNA model & tools"

Published at **<https://danslab.xyz/etathetadna/>** (version 1.0.0, built from `v1.0.0`).

`web/` is a static web app with the same mapping and backmapping code, running in the browser
(Python compiled to WebAssembly with Pyodide, as in the lab's dsXNAbuilder and panmer apps).
Files are read on the user's computer and nothing is sent to a server.

| Tab | What it does |
|---|---|
| Map | All-atom PDB → ηθDNA CG PDB (`convert_dna`), with the G-quadruplex channel cations (`g4`). It also gives a package with `build.sh`, which runs `build_dna.py --cg-input` on your computer (tleap + SIRAH). |
| Backmap | CG frames → heavy-atom PDB (`cg_backmap.reconstruct`, with the B/A/syn/Z templates, SIRAH proteins and channel cations). Input: a CG PDB (one MODEL per frame), or a prmtop with an AMBER NetCDF trajectory, a restart or a PDB. Only the solute part of each frame is read from the trajectory file. It also gives a package that adds the hydrogens and runs the minimization with AmberTools, as `backmap_dna.py` does. |
| The model | Beads, residue names, the terms of ηθDNA 1.0 and the backmap templates. |
| Command line | Downloads: the tools (`etathetadna-tools.zip`: the three entry points, `cg_dna`, `cg_backmap`, `params/`, examples, tests) and the ηθDNA 1.0 parameters alone (`etathetadna-params.zip`, with a README of every file in load order). Every option of `build_dna.py`, `build_dna_protein.py` and `backmap_dna.py`, `run_md.sh` and the Python API. |
| Documentation | Tutorial, input formats, limits. |

The Python side is `cg_web/`; it needs only NumPy. ParmEd is imported only by the
command-line paths, and `tests/test_web_service.py` checks that the web path runs without it.
The downloads and the option reference are made at build time by `scripts/web_cli.py`, which reads the
argparse parsers (`make_parser()` of each tool). The page therefore always documents the options of the
code it ships, and `tests/test_cli_docs.py` fails if an option has no help text.

```bash
scripts/build_web.sh                    # Pyodide + numpy + NGL (pinned), the packages, the downloads
                                        # (run it with the tools' Python: PYTHON=..., it needs ParmEd)
python3 scripts/serve.py                # http://localhost:8770/
python scripts/e2e.py --downloads ~/e2e --prmtop X.prmtop --traj md.nc   # headless Firefox (selenium)
scripts/deploy_danslab.sh /path/to/web-danslab   # copy to public/etathetadna/ + add the Apps card
```

`deploy_danslab.sh` does not commit or push the site: review it, then commit and push the
web-danslab checkout, whose GitHub Pages workflow publishes it. To update the published app, run
the three commands above from the commit to publish (`build_web.sh` stamps the version and the
commit into the app).

## Requirements

- Python 3.8+, [ParmEd](https://parmed.github.io/ParmEd/) and `numpy` (`pip install -r requirements.txt`).
- `tleap` and `sander` on `PATH` (from [AmberTools](https://ambermd.org/AmberTools.php)); `backmap_dna.py` also needs `cpptraj`. Running the MD needs `pmemd`/`pmemd.cuda` (AMBER).
- **Builders only:** a local [SIRAH](http://www.sirahff.com) installation. It is not bundled (third-party force field). Point `--sirah-dir` or `$SIRAH_HOME` at it.
- **`build_dna_protein.py` only:** [`pdb2pqr`](https://pdb2pqr.readthedocs.io/) and `perl` on `PATH`.

## Validation

`cg_dna/tools/check_against_campaign.py` rebuilds the 24 systems of the model's benchmark campaign (run as v18) from their simulated coordinates. It compares the solute term by term with the campaign topologies:

- atoms, charges and masses;
- bonds, angles, dihedrals and impropers, including the 1-4 flags and scaling;
- CMAP terms and grids;
- the full LJ table;
- the DISANG restraints.

Result (2026-11-19): **23/24 identical**. Only the water count differs, by a few WT4, because the solute is re-solvated in another orientation.

The exception is 2f8w_x3, which is a deviation of the campaign and not of this package. That run reused an earlier test topology that also typed the two 3′-terminal *syn* guanines, which have no Z backbone. The final rule, implemented here, leaves them untyped.

From the atomistic `examples/1bna.pdb`, the CG structure, water and ion counts
are identical to the campaign's 1bna. The generated decks match the campaign
decks except for their titles.

## Limitations

- **Unsupported residues are dropped.** The DNA converter keeps only standard DA/DC/DG/DT `ATOM` records, so modified bases written as `HETATM` (e.g. 5-bromo-dU in 1JPQ) are lost and break the strand. Rename them to the parent base first.
- **Modified cytosines.** `params/dna_vf.lib` defines 5-methyl-C (`DMC/MC5/MC3`) and 5-hydroxymethyl-C (`DOC/OC5/OC3`), but the internal `DMC` unit types its N1 bead as `KN`, which no parameter file defines. Modified cytosines are also never Z-typed.
- **Not covered:**
  - implicit solvent (GB);
  - Mg²⁺;
  - the Z-DNA *syn* typing of guanines whose Z state is not visible in the input (the typing reads the input geometry only).

## Package layout

```
build_dna.py, build_dna_protein.py, backmap_dna.py   # command-line entry points
cg_dna/
├── convert_dna.py       # all-atom -> CG DNA PDB (repeat residues, 5'/3' caps)
├── convert_protein.py   # DNA+protein: split chains, pdb2pqr + SIRAH cgconv.pl, merge
├── g4.py                # G-tetrad detection and channel cations (KW4/NW4)
├── tleap_build.py       # tleap input (ηθDNA 1.0 parameter stack), salt rule, runs tleap
├── cmap.py              # eta/theta + phi/chi CMAP injection (pure ParmEd)
├── topology.py          # junction angles, kn5, C4' improper, Z typing, 3pB
├── model.py             # constants of ηθDNA 1.0 (with their provenance)
├── disang.py            # WC restraints on the terminal base pairs
├── decks.py             # AMBER decks of the ηθDNA 1.0 protocol
├── build.py             # the whole chain, shared by both builders
├── paths.py             # bundled parameters + your SIRAH install
└── tools/check_against_campaign.py   # dev-only regression against the benchmark campaign
cg_backmap/              # CG -> all-atom reconstruction (see above)
cg_web/                  # the web app's Python side (Pyodide): service, webapi, topology, netcdf
web/                     # the static web app (index.html, app.js, worker.js, style.css)
scripts/                 # web build, local server, end-to-end test, danslab deployment
params/
├── dna_vf.lib, repeat.lib, cationes_g4.lib
├── frcmod/              # the ηθDNA 1.0 frcmod stack, in load order in cg_dna/paths.py
├── cmap/                # etatheta_{A,C,G,T,GZ,CZ}.dat, chi_{A,C,G,T}.dat
├── run_md.sh            # copied next to every build
└── backmap_*.json       # backmapping recipes
examples/                # 1bna.pdb (atomistic), 4ocb_CG.pdb (Z-DNA, CG), 7x7q_trun.pdb,
                         # 116d/181d/1jpq.pdb (backmap templates), 1kf1.pdb (G4, web example),
                         # cg_frames/ (CG frames of the benchmark campaign, backmap examples)
tests/                   # pytest (pip install -r requirements-dev.txt; pytest tests/);
                         # the full builds run only with tleap and SIRAH_HOME available
validation/              # git-ignored, local only
```

Every function in `cg_dna/` and `cg_backmap/` can be imported directly.
`build_dna.build()`, `cg_dna.build.build_system()` and
`backmap_dna.backmap()` are the shortest entry points.

## Where the science comes from

This tool only assembles input files. The model design, the fitting
protocol and the benchmark are in the main repo,
**[MMBAI-Lab/eta-theta-DNA](https://github.com/MMBAI-Lab/eta-theta-DNA)**.

## Contact

[MMBAI — Molecular Modeling, Bioinformatics & AI](https://danslab.xyz/contact/) · Universidad de la República & Institut Pasteur de Montevideo
