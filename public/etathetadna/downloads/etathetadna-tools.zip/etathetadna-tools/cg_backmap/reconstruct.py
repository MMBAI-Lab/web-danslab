"""Per-frame CG -> all-atom heavy-atom reconstruction engine.

Shared by both recipe tables (our own DNA table and the ported SIRAH
protein/water table) -- there is exactly one NeRF-execution engine, not
one per table.

Chain discovery mirrors cg_dna/cmap.py's proven approach: neighbors are
found via bond connectivity in the CG prmtop (P-K bead bonds for DNA,
backbone bead bonds for SIRAH protein), not residue-number arithmetic --
this is what lets a circular topology (e.g. the mini-mini minicircle, with
an explicit ring-closure bond) work with no special-casing.
"""
import numpy as np

from cg_dna.model import CHANNEL_IONS, KNAMES, PNAMES

from . import nerf
from .recipe import resolve_ref


def find_dna_chains(parm):
    """Return a list of chains, each an ordered list of residue indices
    (0-based), built by walking P<->C4' bond connectivity starting from
    each 5'-terminal residue (one whose P bead, if any, has no C4' bond
    partner in another residue).

    DNA beads are recognized by NAME (C4A/C4C/C4G/C4T and PA/PC/PG/PT, as
    in cg_dna/model.py), not by atom type: the G4 channel cation KW4 and
    SIRAH's bulk KW have types that also start with "K", and a type-based
    check took each of them for a one-residue DNA chain (KW4 has no
    backmap recipe, so every G4 frame failed). Residues without these
    beads (water, ions, channel cations, protein) are not part of any DNA
    chain.
    """
    def c4_bead(residue):
        return next((a for a in residue.atoms if a.name in KNAMES), None)

    dna_residues = [r for r in parm.residues if c4_bead(r) is not None]
    if not dna_residues:
        return []

    # next-residue map: this residue's C4' bead bonds to the NEXT residue's
    # P bead.
    next_of = {}
    prev_of = {}
    for r in dna_residues:
        c4 = c4_bead(r)
        p_partners = [a for a in c4.bond_partners if a.name in PNAMES and a.residue is not r]
        if p_partners:
            nxt = p_partners[0].residue
            next_of[r.idx] = nxt.idx
            prev_of[nxt.idx] = r.idx

    visited = set()
    chains = []
    starts = [r.idx for r in dna_residues if r.idx not in prev_of]
    for start in starts:
        if start in visited:
            continue
        chain = [start]
        visited.add(start)
        cur = start
        while cur in next_of and next_of[cur] not in visited:
            cur = next_of[cur]
            chain.append(cur)
            visited.add(cur)
        chains.append(chain)
    # any residues left over (e.g. a fully circular chain with no free 5'
    # end) form their own chain(s), starting arbitrarily.
    remaining = [r.idx for r in dna_residues if r.idx not in visited]
    while remaining:
        start = remaining[0]
        chain = [start]
        visited.add(start)
        cur = start
        while cur in next_of and next_of[cur] not in visited:
            cur = next_of[cur]
            chain.append(cur)
            visited.add(cur)
        chains.append(chain)
        remaining = [r.idx for r in dna_residues if r.idx not in visited]
    return chains


def find_protein_chains(parm):
    """Return a list of chains (ordered residue-index lists) for SIRAH CG
    protein residues, walking backbone-bead bond connectivity. SIRAH's
    protein backbone bead is named GN (amide N); consecutive residues'
    GN...GC...GO backbone beads are bonded GO(i)-GN(i+1) in the CG
    topology, so we walk GN<->GN adjacency via the shared backbone bond
    chain (any backbone atom's inter-residue bond partner identifies the
    neighbor)."""
    def backbone_atom(residue, name):
        for a in residue.atoms:
            if a.name == name:
                return a
        return None

    protein_residues = [r for r in parm.residues if backbone_atom(r, "GN") is not None]
    if not protein_residues:
        return []

    next_of = {}
    prev_of = {}
    for r in protein_residues:
        gn = backbone_atom(r, "GN")
        # the inter-residue backbone bond is GN(i) - GC/GO(i-1) depending on
        # SIRAH's exact backbone bonding; find any bond partner in a
        # DIFFERENT residue that is itself a protein residue -- that is the
        # previous residue by construction (peptide bond).
        prev_partners = [a for a in gn.bond_partners if a.residue is not r and a.residue in protein_residues]
        if prev_partners:
            prev_r = prev_partners[0].residue
            next_of[prev_r.idx] = r.idx
            prev_of[r.idx] = prev_r.idx

    visited = set()
    chains = []
    starts = [r.idx for r in protein_residues if r.idx not in prev_of]
    for start in starts:
        if start in visited:
            continue
        chain = [start]
        visited.add(start)
        cur = start
        while cur in next_of and next_of[cur] not in visited:
            cur = next_of[cur]
            chain.append(cur)
            visited.add(cur)
        chains.append(chain)
    return chains


def find_channel_ions(parm):
    """G4 channel cations (KW4/NW4, cg_dna/g4.py), each as a one-residue
    "chain": the recipe table keeps them as K+/Na+ at the bead position.
    Bulk ions and water are not reconstructed."""
    return [[r.idx] for r in parm.residues if r.name in CHANNEL_IONS]


def _lookup_placed(built, own, chain_len, i, ref):
    """'place' refs always resolve against already-built (copied or placed)
    atoms: this residue's own (own) or a neighbor's (built), via the
    /-  /+ offset convention."""
    atom_name, offset = resolve_ref(ref)
    if offset == 0:
        return own[atom_name]
    target_i = i + offset
    if not (0 <= target_i < chain_len):
        raise ValueError(f"ref {ref!r} at chain position {i} has no neighbor at offset {offset}")
    return built[(target_i, atom_name)]


def _lookup_native(cg_atoms_per_res, i, candidate):
    """'copy' sources always resolve against NATIVE CG bead coordinates
    (same or neighbor residue, via /-  /+), never an already-placed atom --
    mirrors SIRAH's own sirah_build: ':' instructions always read the raw
    CG trajectory frame, only '+' (place) instructions read from the
    residue's own newly-built atom table. Returns None if this candidate
    isn't present (caller tries the next fallback candidate)."""
    atom_name, offset = resolve_ref(candidate)
    target_i = i + offset
    if not (0 <= target_i < len(cg_atoms_per_res)):
        return None
    return cg_atoms_per_res[target_i].get(atom_name)


def _copied_atom(recipes, cg_resnames, cg_atoms_per_res, j, atom):
    """Native position of an atom that residue j copies from a CG bead
    (e.g. the next residue's P), or None."""
    if not (0 <= j < len(cg_resnames)):
        return None
    entry = recipes.get(cg_resnames[j])
    if not entry or entry.get("nomap"):
        return None
    for instr in entry["instructions"]:
        if instr["op"] == "copy" and instr["atom"] == atom:
            sources = instr["source"] if isinstance(instr["source"], list) else [instr["source"]]
            for src in sources:
                found = _lookup_native(cg_atoms_per_res, j, src)
                if found is not None:
                    return np.asarray(found, dtype=float)
    return None


def _build_residue(i, cg_resname, instructions, cg_atoms_per_res, built, chain_len):
    """Run one instruction list for chain position i; returns {atom: xyz}."""
    own = {}
    for instr in instructions:
        if instr["op"] == "copy":
            sources = instr["source"] if isinstance(instr["source"], list) else [instr["source"]]
            for src in sources:
                found = _lookup_native(cg_atoms_per_res, i, src)
                if found is not None:
                    own[instr["atom"]] = np.asarray(found, dtype=float)
                    break
            else:
                raise ValueError(
                    f"{cg_resname}: none of the candidate source beads {sources} "
                    f"for atom {instr['atom']!r} could be resolved"
                )
        else:  # "place"
            pts = [_lookup_placed(built, own, chain_len, i, ref) for ref in instr["refs"]]
            at3, at2, at1 = pts
            own[instr["atom"]] = nerf.place_nerf(
                at3[None, :], at2[None, :], at1[None, :],
                instr["r"], instr["theta"], instr["phi"],
            )[0]
    return own


def fit_score(fit, own, i, cg_resnames, cg_atoms_per_res, recipes):
    """How badly a built nucleotide fits the beads its template does not
    use (A^2): the squared distance between C1' as the sugar template puts
    it and C1' as the base predicts it, plus the squared deviations of the
    bonds in fit["bonds"] (O5'-P, O3'-P(i+1)); a bond whose partner is
    missing (chain end) is left out."""
    c1 = fit["C1'"]
    at3, at2, at1 = (own[r] for r in c1["refs"])
    pred = nerf.place_nerf(at3[None, :], at2[None, :], at1[None, :], c1["r"], c1["theta"], c1["phi"])[0]
    score = float(((own["C1'"] - pred) ** 2).sum())
    for a, b, d0 in fit["bonds"]:
        name, offset = resolve_ref(b)
        pb = own.get(name) if offset == 0 else _copied_atom(recipes, cg_resnames, cg_atoms_per_res, i + offset, name)
        if pb is not None and a in own:
            score += (float(np.linalg.norm(own[a] - pb)) - d0) ** 2
    return score


# A template is eligible only if the chi it gives is within this many
# degrees of the chi of its own crystal residue (fit["chi"]).
CHI_GATE = 90.0


def _pick_conformer(recipe, own_b, i, cg_resname, cg_resnames, cg_atoms_per_res, built, recipes):
    """Build nucleotide i with every template and keep the lowest
    fit_score() among those whose rebuilt chi is within CHI_GATE of the
    template's own chi (fit["chi"]); if none is, the lowest overall.
    Returns (label, {atom: xyz})."""
    fit = recipe["fit"]
    glyn, ring = fit["C1'"]["refs"][:2]
    trials = [("B", own_b)] + [(label, _build_residue(i, cg_resname, alt, cg_atoms_per_res, built, len(cg_resnames)))
                               for label, alt in recipe["conformers"].items()]
    scored = []
    for label, own in trials:
        score = fit_score(fit, own, i, cg_resnames, cg_atoms_per_res, recipes)
        chi = nerf.dihedral(own["O4'"], own["C1'"], own[glyn], own[ring])
        ok = abs((chi - fit["chi"][label] + 180) % 360 - 180) < CHI_GATE
        scored.append((not ok, score, label, own))
    _, _, label, own = min(scored, key=lambda t: (t[0], t[1]))
    return label, own


def reconstruct_chain(chain_residue_idxs, parm, frame_coords, recipes, allow_unmapped=False, conformers=True):
    """Reconstruct one chain (a list of 0-based residue indices, already
    ordered 5'->3' or N->C by find_dna_chains/find_protein_chains) for one
    frame's coordinates (frame_coords: (natom, 3) ndarray matching parm's
    atom ordering).

    Returns an ordered list of {'output_resname': str, 'atoms': {name:
    (3,) ndarray}} (plus 'conformer' for nucleotides) -- one entry per
    non-nomap residue, ready to be written out as a heavy-atom PDB by the
    caller.

    Thin wrapper around reconstruct_residues() -- derives cg_resnames/
    cg_atoms_per_res from a real ParmEd Structure (needs bond connectivity,
    hence a real prmtop); reconstruct_residues() itself has no ParmEd
    dependency and is what tests/test_dna_recipe_roundtrip.py exercises
    directly against a hand-built residue list (no prmtop required).
    """
    residues = [parm.residues[i] for i in chain_residue_idxs]
    cg_atoms_per_res = [
        {a.name: frame_coords[a.idx] for a in r.atoms}
        for r in residues
    ]
    cg_resnames = [r.name for r in residues]
    return reconstruct_residues(cg_resnames, cg_atoms_per_res, recipes, allow_unmapped=allow_unmapped,
                                conformers=conformers)


def reconstruct_residues(cg_resnames, cg_atoms_per_res, recipes, allow_unmapped=False, conformers=True):
    """Core reconstruction loop, no ParmEd dependency: cg_resnames[i] is
    the CG residue type name at chain position i; cg_atoms_per_res[i] is a
    {atom_name: (3,) coords} dict of that residue's own native CG beads.
    Both lists must already be in chain order (5'->3' / N->C).

    A nucleotide whose recipe has conformer templates is built with each
    of them (B, A, syn, Z) and the one with the lowest fit_score() is
    kept, among those that leave chi on the template's side
    (_pick_conformer); its name goes to the output entry as 'conformer'.
    With conformers=False every nucleotide uses the default B template."""
    built = {}
    out = []
    n = len(cg_resnames)
    for i, cg_resname in enumerate(cg_resnames):
        recipe = recipes.get(cg_resname)
        if recipe is None:
            if allow_unmapped:
                print(f"Warning: no backmap recipe for CG residue type {cg_resname!r} -- dropping it.")
                continue
            raise ValueError(
                f"no backmap recipe for CG residue type {cg_resname!r} "
                f"(pass allow_unmapped=True / --allow-unmapped to drop it with a warning instead)"
            )
        if recipe.get("nomap"):
            continue

        # SIRAH-style first/last overrides apply based on this residue's
        # REAL chain position (no res- / res+ neighbor), not its CG
        # resname -- e.g. every C-terminal protein residue needs its "N+"
        # scratch atom (used to place the carbonyl C) sourced from its own
        # GN bead instead of a nonexistent next residue's, regardless of
        # which s/n/c/a/m-prefixed name matched. Our own DNA table has no
        # overrides (5'/3' termini are separate CG resnames instead), so
        # this is a no-op there.
        instructions = recipe["instructions"]
        override = None
        if i == 0 and "first_override" in recipe:
            override = {ov["atom"]: ov for ov in recipe["first_override"]}
        elif i == len(cg_resnames) - 1 and "last_override" in recipe:
            override = {ov["atom"]: ov for ov in recipe["last_override"]}
        if override:
            instructions = [override.get(instr["atom"], instr) for instr in instructions]

        own = _build_residue(i, cg_resname, instructions, cg_atoms_per_res, built, n)
        entry = {"output_resname": recipe["output_resname"]}
        if recipe.get("conformers") and recipe.get("fit"):
            chosen = "B"
            if conformers:
                chosen, own = _pick_conformer(recipe, own, i, cg_resname, cg_resnames, cg_atoms_per_res,
                                              built, recipes)
            entry["conformer"] = chosen
        built.update({(i, name): xyz for name, xyz in own.items()})
        entry["atoms"] = {name: own[name] for name in recipe["print"]}
        out.append(entry)
    return out


def reconstruct_structure(parm, frame_coords, recipes, allow_unmapped=False, conformers=True):
    """Reconstruct every DNA and protein chain present in one CG frame,
    plus the G4 channel cations (find_channel_ions).
    parm: the CG topology, a ParmEd Structure or any object with the same
    residues/atoms/bond_partners attributes (cg_web.topology builds one
    from a CG PDB or a prmtop without ParmEd, for the web app).
    frame_coords: (natom, 3) ndarray, same atom order as parm.
    Returns an ordered list of chains, each a list of per-residue dicts
    (as returned by reconstruct_chain) -- caller writes these out as a
    single heavy-atom PDB (one TER between chains).
    """
    chains = find_dna_chains(parm) + find_protein_chains(parm) + find_channel_ions(parm)
    return [reconstruct_chain(chain, parm, frame_coords, recipes, allow_unmapped=allow_unmapped,
                              conformers=conformers)
            for chain in chains]


def reconstruct_frame(prmtop_path, frame_coords, recipes, allow_unmapped=False, conformers=True):
    """reconstruct_structure() for the CG prmtop at prmtop_path (read with
    ParmEd, imported here so that the rest of this module runs without it,
    e.g. in the browser)."""
    import parmed as pmd

    return reconstruct_structure(pmd.load_file(prmtop_path), frame_coords, recipes,
                                 allow_unmapped=allow_unmapped, conformers=conformers)


DNA_OUTPUT_RESNAMES = {"DA", "DC", "DG", "DT", "DA5", "DC5", "DG5", "DT5",
                        "DA3", "DC3", "DG3", "DT3"}
ION_OUTPUT_RESNAMES = {"K+", "Na+"}


def write_heavy_pdb(chains, out_path):
    """Write the reconstruct_frame() output as a single heavy-atom-only
    PDB (one TER between chains, matching tleap's own chain/terminus
    auto-detection -- see hydrogenate.py's docstring: the first/last
    residue of each TER-delimited chain gets tleap's default terminal
    treatment, no special residue-name signaling needed).

    Returns (has_protein, has_dna, has_ions): which force fields
    hydrogenate.py's tleap step needs to source for this frame.
    """
    has_protein = False
    has_dna = False
    has_ions = False
    lines = []
    serial = 1
    for chain_idx, chain in enumerate(chains):
        chain_id = chr(ord("A") + chain_idx % 26)
        last_resnum = None
        for res_idx, res in enumerate(chain, start=1):
            resname = res["output_resname"]
            if resname in DNA_OUTPUT_RESNAMES:
                has_dna = True
            elif resname in ION_OUTPUT_RESNAMES:
                has_ions = True
            else:
                has_protein = True
            for atom_name, xyz in res["atoms"].items():
                lines.append(
                    f"ATOM  {serial:5d} {atom_name:<4}{resname:>4} {chain_id}{res_idx:4d}    "
                    f"{xyz[0]:8.3f}{xyz[1]:8.3f}{xyz[2]:8.3f}  1.00  0.00"
                )
                serial += 1
            last_resnum = res_idx
        if last_resnum is not None:
            lines.append(f"TER   {serial:5d}      {chain[-1]['output_resname']:>3} {chain_id}{last_resnum:4d}")
            serial += 1
    with open(out_path, "w") as f:
        f.write("\n".join(lines) + "\nEND\n")
    return has_protein, has_dna, has_ions
