#!/usr/bin/env python3
"""One-time, developer-run tool: derive our own eta-theta-DNA backmapping
recipe (params/backmap_dna.json) by measuring idealized internal
coordinates from a real reference structure (examples/1bna.pdb, already
vendored in this repo).

Our CG-DNA model (cg_dna/convert_dna.py's CG_ATOMS) keeps a different,
sparser backbone anchor set than SIRAH's own DNA model (only P + C4', vs
SIRAH's P + C5' + C1'), so SIRAH's own DNA recipe isn't reusable here --
this script builds an independent one, using the exact same NeRF
machinery (cg_backmap/nerf.py) as the ported SIRAH table.

Every constant is measured fresh from ONE reference structure (not mixed
with any of SIRAH's own numbers, even where a ref-trio choice happens to
coincide) -- a single, auditable provenance for every number in the
output table. Reference atoms are chosen to be real chemical bonds where
possible (so the measured "r" is a genuine, conformation-invariant bond
length); a few placements (e.g. a ring carbon with only 2 heavy-atom
bonds) necessarily use a 3rd, non-bonded reference point to fully
constrain the NeRF frame -- fine for the same reason SIRAH's own
constants are, since the downstream tleap+sander minimization step
(cg_backmap/hydrogenate.py) relaxes away any local strain from using one
fixed idealized geometry everywhere, rather than a per-conformation
preset.

Conformer templates. The B recipe above (1BNA: anti, C2'-endo) is the
default "instructions" of every nucleotide entry. Each entry also carries
"conformers": the same recipe measured on one residue of another
conformation (CONFORMERS below), and "fit": the checks the reconstruction
uses to pick, per nucleotide and frame, the template that best fits the
CG beads it does not copy:
  - C1' as the base predicts it (in the base plane, from N9/C4/C8 or
    N1/C2/C6, measured on the 1BNA residue) against C1' as the sugar
    template places it: this is what tells syn from anti;
  - the O5'-P and O3'-P(i+1) bond lengths (1BNA): this is what tells the
    sugar pucker and the backbone apart;
  - "chi": the glycosidic angle of each template residue. A template is
    only taken when the chi it gives is within 90 deg of its own, so a
    syn template never ends up under an anti base (or the reverse).
The reference structures are the RCSB files, unmodified, in examples/.
The 1BNA numbers are unchanged, so the default B reconstruction is the
same as before the conformers were added.

G4 channel cations (cg_dna/g4.py, KW4/NW4) get a one-atom entry that keeps
them as the all-atom ion (K+/Na+) at the bead position.

Usage:
    python cg_backmap/tools/derive_dna_constants.py
"""
import json
import os
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, REPO_ROOT)

from cg_dna.convert_dna import load_pdb, group_by_residue, CG_ATOMS, ATOM_NAME_MAP  # noqa: E402
from cg_backmap.nerf import dihedral, measure_internal_coords, place_nerf  # noqa: E402

REFERENCE_PDB = os.path.join(REPO_ROOT, "examples", "1bna.pdb")

# One representative INTERNAL residue per base from 1BNA chain A
# (5'-CGCGAATTCGCG-3'), each with a valid i-1 neighbor. The measurement
# only needs real atom coordinates -- terminal vs. internal status of the
# CALIBRATION residue itself doesn't matter (see BASE_TOPOLOGY's 5'-term
# alt steps, which are measured from the SAME internal residue).
CALIBRATION = {
    "G": {"resid": 2, "chain": "A", "prev_resid": 1},
    "C": {"resid": 3, "chain": "A", "prev_resid": 2},
    "A": {"resid": 5, "chain": "A", "prev_resid": 4},
    "T": {"resid": 7, "chain": "A", "prev_resid": 6},
}

# Conformer templates: (reference PDB in examples/, {base: (chain, resid,
# prev_resid)}). Each residue is the internal residue of its class and base
# closest to the class median of alpha, beta, gamma, delta, chi and the
# pucker phase in that structure.
#   A    116D, A-DNA dodecamer (all anti, C3'-endo)
#   syn  1JPQ, Oxytricha G4 with K+ (syn G, C2'-endo, as in the G4 crystals:
#        the step anti G -> syn G of a G-tract)
#   Z    181D, Z-DNA d(CACGCG): syn purines C3'-endo (CpG / CpA steps),
#        anti pyrimidines C2'-endo with the Z backbone (GpC / GpT steps)
CONFORMERS = {
    "A": ("116d.pdb", {"G": ("A", 3, 2), "C": ("A", 10, 9), "T": ("A", 8, 7), "A": ("A", 9, 8)}),
    "syn": ("1jpq.pdb", {"G": ("B", 2003, 2002)}),
    "Z": ("181d.pdb", {"G": ("B", 10, 9), "A": ("A", 2, 1), "C": ("A", 5, 4), "T": ("B", 11, 10)}),
}

# G4 channel cations: CG residue (bead of the same name) -> all-atom ion.
CHANNEL_IONS = {"KW4": "K+", "NW4": "Na+"}

# Per base: the glycosidic nitrogen (N9 purines / N1 pyrimidines, both
# already native/kept), the ring-atom placement order (each entry's ref
# triple uses real bonded neighbors as at3/at2 wherever the ring provides
# them; a 3rd non-bonded-but-available point fills in where a ring atom
# genuinely only has 2 heavy-atom bonds), and a native ring atom usable as
# the 3rd reference for the 5'-terminal-only C5' placement (no phosphate,
# no i-1 neighbor available at a real 5' end).
BASE_TOPOLOGY = {
    "G": {
        "glyN": "N9",
        "ring_order": [
            ("C2", ["N1", "N3", "N2"]),
            ("C4", ["N3", "N9", "C2"]),
            ("C5", ["C4", "N9", "N7"]),
            ("C6", ["C5", "N1", "O6"]),
            ("C8", ["N9", "N7", "C4"]),
        ],
        "term5_ref3": "N7",
    },
    "A": {
        "glyN": "N9",
        "ring_order": [
            ("C2", ["N1", "N3", "N9"]),
            ("C4", ["N3", "N9", "C2"]),
            ("C5", ["C4", "N9", "N7"]),
            ("C6", ["C5", "N1", "N6"]),
            ("C8", ["N9", "N7", "C4"]),
        ],
        "term5_ref3": "N7",
    },
    "T": {
        "glyN": "N1",
        "ring_order": [
            ("C2", ["N1", "N3", "O2"]),
            ("C4", ["N3", "O4", "C2"]),
            ("C5", ["C4", "C7", "N3"]),
            ("C6", ["C5", "N1", "C2"]),
        ],
        "term5_ref3": "O2",
    },
    "C": {
        "glyN": "N1",
        "ring_order": [
            ("C2", ["N1", "N3", "O2"]),
            ("C4", ["N3", "C5", "N4"]),
            ("C6", ["C5", "N1", "C4"]),
        ],
        "term5_ref3": "O2",
    },
}

# Backbone/sugar reconstruction, shared by all 4 bases (glyN substituted
# per base). Internal residues get the full 9-step chain (needs the
# previous residue's C4', hence the true phosphodiester P-O5' link);
# 5'-terminal residues (no phosphate emitted by convert_dna.py, no i-1
# neighbor) get their own 2-step C5'/O5' alternative, then share steps
# 5-9 unchanged with the internal recipe.
BACKBONE_INTERNAL = [
    ("C5'", ["C4'", "P", "C4'/-"]),
    ("O5'", ["C5'", "C4'", "P"]),
    ("OP2", ["P", "O5'", "C4'/-"]),
    ("OP1", ["P", "OP2", "O5'"]),
    ("C1'", ["{glyN}", "C4'", "C5'"]),
    ("O4'", ["C1'", "{glyN}", "C5'"]),
    ("C2'", ["C1'", "{glyN}", "O4'"]),
    ("C3'", ["C4'", "O4'", "C5'"]),
    ("O3'", ["C3'", "C4'", "C2'"]),
]
BACKBONE_5TERM = [
    ("C5'", ["C4'", "{glyN}", "{term5_ref3}"]),
    ("O5'", ["C5'", "C4'", "{glyN}"]),
    ("C1'", ["{glyN}", "C4'", "C5'"]),
    ("O4'", ["C1'", "{glyN}", "C5'"]),
    ("C2'", ["C1'", "{glyN}", "O4'"]),
    ("C3'", ["C4'", "O4'", "C5'"]),
    ("O3'", ["C3'", "C4'", "C2'"]),
]

# C1' as the base predicts it: glycosidic N + the two ring atoms bonded to
# it (the "fit" check that tells syn from anti, see the module docstring).
C1_FROM_BASE = {"G": ["N9", "C4", "C8"], "A": ["N9", "C4", "C8"],
                "C": ["N1", "C2", "C6"], "T": ["N1", "C2", "C6"]}

RESID_1LETTER = {"DG": "G", "DA": "A", "DT": "T", "DC": "C"}
OUTPUT_RESNAME = {"G": "DG", "A": "DA", "T": "DT", "C": "DC"}
CG_RESNAME_INTERNAL = {"G": "DGX", "A": "DAX", "T": "DTX", "C": "DCX"}
CG_RESNAME_5TERM = {"G": "GX5", "A": "AX5", "T": "TX5", "C": "CX5"}
CG_RESNAME_3TERM = {"G": "GX3", "A": "AX3", "T": "TX3", "C": "CX3"}
CG_RESNAME_REPEAT = {"G": "DG1", "A": "DA1", "T": "DT1", "C": "DC1"}


def _format_ref(name, offset_str):
    return f"{name}{offset_str}" if offset_str else name


def _resolve_refs(ref_names, glyN, term5_ref3=None):
    """Substitute {glyN}/{term5_ref3} placeholders in a ref-name list."""
    out = []
    for r in ref_names:
        r = r.replace("{glyN}", glyN)
        if term5_ref3 is not None:
            r = r.replace("{term5_ref3}", term5_ref3)
        out.append(r)
    return out


def measure_instruction(atom_coords, prev_coords, target_atom, ref_names):
    """ref_names may include a '<atom>/-' suffix (previous residue). Look
    up each ref + the target atom in the appropriate coordinate dict and
    return a translated 'place' instruction (constants only, refs kept
    symbolic for the output JSON)."""
    def coord_of(ref):
        if ref.endswith("/-"):
            return prev_coords[ref[:-2]]
        return atom_coords[ref]

    p_at3, p_at2, p_at1 = (coord_of(r) for r in ref_names)
    p_at4 = atom_coords[target_atom]
    r, theta, phi = measure_internal_coords(p_at3, p_at2, p_at1, p_at4)
    return {"atom": target_atom, "op": "place", "refs": ref_names, "r": r, "theta": theta, "phi": phi}


def build_base_entry(base, atom_coords, prev_coords):
    topo = BASE_TOPOLOGY[base]
    glyN = topo["glyN"]

    instructions = []
    built_names = set()

    # 1. Copy the atoms our CG model keeps natively (source = CG bead name,
    #    from cg_dna.convert_dna's own tables -- kept in sync automatically).
    cg_base_key = f"D{base}"
    for aa_name in CG_ATOMS[cg_base_key]:
        cg_bead = ATOM_NAME_MAP[cg_base_key][aa_name]
        instructions.append({"atom": aa_name, "op": "copy", "source": cg_bead})
        built_names.add(aa_name)

    # 2. Ring atoms not kept natively, placed by NeRF from real bonded
    #    neighbors (measured from the calibration residue).
    for atom, ref_names in topo["ring_order"]:
        instr = measure_instruction(atom_coords, prev_coords, atom, ref_names)
        instructions.append(instr)
        built_names.add(atom)

    # 3. Backbone/sugar (internal recipe: full phosphodiester chain).
    for atom, ref_template in BACKBONE_INTERNAL:
        ref_names = _resolve_refs(ref_template, glyN)
        instr = measure_instruction(atom_coords, prev_coords, atom, ref_names)
        instructions.append(instr)
        built_names.add(atom)

    print_list = ["P", "OP1", "OP2", "O5'", "C5'", "C4'", "O4'", "C3'", "O3'", "C2'", "C1'"] + [
        a for a in CG_ATOMS[cg_base_key] if a not in ("P", "C4'")
    ] + [atom for atom, _ in topo["ring_order"]]
    # de-duplicate while preserving first occurrence
    seen = set()
    print_list = [a for a in print_list if not (a in seen or seen.add(a))]
    missing = [a for a in print_list if a not in built_names]
    assert not missing, f"{base}: print list references atom(s) never built: {missing}"

    return {"output_resname": OUTPUT_RESNAME[base], "instructions": instructions, "print": print_list}


def build_5term_entry(base, atom_coords):
    """5'-terminal: no phosphate, no i-1 neighbor. Ring-atom placement is
    identical to the internal recipe (doesn't touch the backbone at all);
    only the C5'/O5' steps get their own alternative ref triples, and
    OP1/OP2 are dropped entirely (convert_dna.py never emits a 5'
    phosphate)."""
    topo = BASE_TOPOLOGY[base]
    glyN = topo["glyN"]

    instructions = []
    cg_base_key = f"D{base}"
    for aa_name in CG_ATOMS[cg_base_key]:
        if aa_name == "P":
            continue  # convert_dna.py drops the 5'-terminal phosphate
        cg_bead = ATOM_NAME_MAP[cg_base_key][aa_name]
        instructions.append({"atom": aa_name, "op": "copy", "source": cg_bead})

    for atom, ref_names in topo["ring_order"]:
        instructions.append(measure_instruction(atom_coords, {}, atom, ref_names))

    for atom, ref_template in BACKBONE_5TERM:
        ref_names = _resolve_refs(ref_template, glyN, topo["term5_ref3"])
        instructions.append(measure_instruction(atom_coords, {}, atom, ref_names))

    print_list = ["O5'", "C5'", "C4'", "O4'", "C3'", "O3'", "C2'", "C1'"] + [
        a for a in CG_ATOMS[cg_base_key] if a not in ("P", "C4'")
    ] + [atom for atom, _ in topo["ring_order"]]
    seen = set()
    print_list = [a for a in print_list if not (a in seen or seen.add(a))]

    return {"output_resname": f"{OUTPUT_RESNAME[base]}5", "instructions": instructions, "print": print_list}


def self_check(base, entry, atom_coords, prev_coords, label):
    """Replay this entry's own instructions and confirm every 'place'
    atom reproduces the calibration structure's real coordinates to
    machine precision (regression guard against a transcription bug in
    ref order/atom naming -- NOT a generalization test, see
    tests/test_dna_recipe_roundtrip.py for that)."""
    built = {}
    for instr in entry["instructions"]:
        if instr["op"] == "copy":
            continue  # copies are native input, trivially correct by construction
        def coord_of(ref):
            if ref.endswith("/-"):
                return prev_coords[ref[:-2]]
            if ref in built:
                return built[ref]
            return atom_coords[ref]
        p3, p2, p1 = (coord_of(r) for r in instr["refs"])
        placed = place_nerf(p3[None, :], p2[None, :], p1[None, :], instr["r"], instr["theta"], instr["phi"])[0]
        built[instr["atom"]] = placed
        real = atom_coords[instr["atom"]]
        err = ((placed - real) ** 2).sum() ** 0.5
        if err > 1e-6:
            raise AssertionError(f"{label}/{base}: self-check FAILED for {instr['atom']} (err={err:.2e} A)")


def res_coords(pdb_path, resid, chain, resname_prefix="D"):
    """{atom name: (3,) array} of one residue (ATOM records only)."""
    import numpy as np

    for (resname, rid, ch, _seg), res_atoms in group_by_residue(load_pdb(pdb_path)).items():
        if rid == resid and ch == chain and resname.startswith(resname_prefix):
            return {a["name"]: np.array((a["x"], a["y"], a["z"]), dtype=float) for a in res_atoms}
    raise KeyError(f"residue {resname_prefix}{resid} chain {chain} not found in {pdb_path}")


def template_chi(base, coords):
    """Glycosidic angle chi (O4'-C1'-N9-C4 / O4'-C1'-N1-C2) of a residue."""
    glyn, ring = C1_FROM_BASE[base][:2]
    return dihedral(coords["O4'"], coords["C1'"], coords[glyn], coords[ring])


def fit_checks(base, atom_coords, next_coords, term5=False):
    """The "fit" block of an entry (see the module docstring), measured on
    the 1BNA calibration residue and its 3' neighbor."""
    import numpy as np

    c1 = measure_instruction(atom_coords, {}, "C1'", C1_FROM_BASE[base])
    bonds = [] if term5 else [["O5'", "P", float(np.linalg.norm(atom_coords["O5'"] - atom_coords["P"]))]]
    bonds.append(["O3'", "P/+", float(np.linalg.norm(atom_coords["O3'"] - next_coords["P"]))])
    return {"C1'": {k: c1[k] for k in ("refs", "r", "theta", "phi")}, "bonds": bonds}


def main():
    table = {}
    for base, cal in CALIBRATION.items():
        atom_coords = res_coords(REFERENCE_PDB, cal["resid"], cal["chain"], f"D{base}")
        prev_coords = res_coords(REFERENCE_PDB, cal["prev_resid"], cal["chain"])
        next_coords = res_coords(REFERENCE_PDB, cal["resid"] + 1, cal["chain"])

        internal_entry = build_base_entry(base, atom_coords, prev_coords)
        self_check(base, internal_entry, atom_coords, prev_coords, "internal")
        term5_entry = build_5term_entry(base, atom_coords)
        self_check(base, term5_entry, atom_coords, {}, "5-terminal")

        # conformer templates, same recipe measured on another residue
        conf_internal, conf_5term = {}, {}
        chis = {"B": template_chi(base, atom_coords)}
        for label, (pdb, residues) in CONFORMERS.items():
            if base not in residues:
                continue
            chain, resid, prev_resid = residues[base]
            path = os.path.join(REPO_ROOT, "examples", pdb)
            t_coords = res_coords(path, resid, chain, f"D{base}")
            t_prev = res_coords(path, prev_resid, chain)
            e = build_base_entry(base, t_coords, t_prev)
            self_check(base, e, t_coords, t_prev, f"{label} internal")
            e5 = build_5term_entry(base, t_coords)
            self_check(base, e5, t_coords, {}, f"{label} 5-terminal")
            assert e["print"] == internal_entry["print"] and e5["print"] == term5_entry["print"]
            conf_internal[label] = e["instructions"]
            conf_5term[label] = e5["instructions"]
            chis[label] = template_chi(base, t_coords)

        fit = dict(fit_checks(base, atom_coords, next_coords), chi=chis)
        internal_entry.update(conformers=conf_internal, fit=fit)
        term5_entry.update(conformers=conf_5term, fit=dict(fit_checks(base, atom_coords, next_coords, term5=True), chi=chis))
        table[CG_RESNAME_INTERNAL[base]] = internal_entry
        table[CG_RESNAME_3TERM[base]] = {
            "output_resname": f"{OUTPUT_RESNAME[base]}3",
            "instructions": internal_entry["instructions"],
            "print": internal_entry["print"],
            "conformers": conf_internal,
            "fit": fit,
        }
        table[CG_RESNAME_REPEAT[base]] = {"alias_of": CG_RESNAME_INTERNAL[base]}
        table[CG_RESNAME_5TERM[base]] = term5_entry

        print(f"{base}: internal {len(internal_entry['instructions'])} instr / "
              f"{len(internal_entry['print'])} atoms, "
              f"5'-term {len(term5_entry['instructions'])} instr / {len(term5_entry['print'])} atoms, "
              f"conformers B + {' '.join(conf_internal)} -- self-check OK")

    for cg_name, ion in CHANNEL_IONS.items():
        table[cg_name] = {"output_resname": ion, "print": [ion],
                          "instructions": [{"atom": ion, "op": "copy", "source": cg_name}]}

    out_path = os.path.join(REPO_ROOT, "params", "backmap_dna.json")
    with open(out_path, "w") as f:
        json.dump(table, f, indent=2, sort_keys=True)
        f.write("\n")
    print(f"\nWrote {out_path}: {len(table)} entries.")


if __name__ == "__main__":
    main()
