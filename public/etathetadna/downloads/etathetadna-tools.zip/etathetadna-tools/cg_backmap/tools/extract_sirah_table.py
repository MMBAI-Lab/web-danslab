#!/usr/bin/env python3
"""One-time, developer-run tool: extract SIRAH's own NeRF backmapping
recipe table (protein + water/ion `nomap` entries only) from
sirah_vmdtk.tcl and translate it into this repo's recipe JSON schema
(cg_backmap/recipe.py), bundled at params/backmap_sirah.json.

NOT part of the runtime import graph -- end users of backmap_dna.py never
run this, never need Tcl, and never need a SIRAH install. Re-run this only
if the bundled table needs to be regenerated (e.g. against a newer SIRAH
release).

sirah_vmdtk.tcl cannot be `source`d whole outside VMD -- its very last
proc, sirah_macros, calls VMD's `atomselect` unconditionally at load time.
The proc we actually need, sirah_mapdb (a pure `dict set` data table, zero
VMD calls), is extracted as standalone text and run through a plain
`tclsh` (confirmed present, no VMD/Tk required for this proc).

Usage:
    python cg_backmap/tools/extract_sirah_table.py \
        /path/to/sirah_x2.3_24-07.amber/tools/sirah_vmdtk.tcl
"""
import json
import os
import re
import subprocess
import sys
import tempfile

# CG residue name prefixes that denote a standard SIRAH protein residue at
# a given chain position: s=internal, n=N-terminal, c=C-terminal, a/m=SIRAH's
# own alternate N-/C-terminal capping variants. Anything else (SIRAH's own
# DNA model, lipids, glycans, the disulfide-bridge-only CYS/CYX stub
# entries) is out of scope for this repo -- protein/water only.
PROTEIN_PREFIXES = "sncam"

# Water/ion CG residue names SIRAH itself never backmaps (dropped entirely,
# re-solvated separately) -- ported verbatim as {"nomap": true}.
NOMAP_NAMES = {"WT4", "WLS", "ClW", "NaW", "KW", "WAT", "SOL", "NA", "CL"}

# Metal ions with a trivial 1:1 CG bead -> real atom copy (no NeRF needed).
ION_COPY_NAMES = {"MgX", "CaX", "ZnX"}


def extract_mapdb_proc(tcl_path):
    """Return the standalone text of `proc sirah_mapdb {} { ... }` (start
    to matching top-level `proc <next> ...`), reading the line range
    dynamically rather than hardcoding line numbers (robust to the exact
    line numbers shifting between SIRAH releases)."""
    with open(tcl_path) as f:
        lines = f.readlines()
    start = next(i for i, l in enumerate(lines) if l.startswith("proc sirah_mapdb"))
    end = next(i for i, l in enumerate(lines) if i > start and l.startswith("proc "))
    return "".join(lines[start:end])


def dump_backmap_dict(mapdb_proc_text):
    """Run mapdb_proc_text through a plain tclsh, call sirah_mapdb, and
    return the populated $backmap dict as Tcl's own string representation."""
    with tempfile.TemporaryDirectory() as scratch:
        proc_path = os.path.join(scratch, "sirah_mapdb_only.tcl")
        driver_path = os.path.join(scratch, "dump.tcl")
        dump_path = os.path.join(scratch, "dump.txt")
        with open(proc_path, "w") as f:
            f.write(mapdb_proc_text)
        with open(driver_path, "w") as f:
            f.write(f"""\
source {{{proc_path}}}
sirah_mapdb
set fh [open {{{dump_path}}} w]
puts $fh $backmap
close $fh
""")
        result = subprocess.run(["tclsh", driver_path], capture_output=True, text=True)
        if result.returncode != 0 or not os.path.isfile(dump_path):
            raise RuntimeError(f"tclsh extraction failed:\n{result.stdout}\n{result.stderr}")
        with open(dump_path) as f:
            return f.read()


def parse_tcl_list(text, pos=0, end=None):
    """Minimal Tcl list/dict text parser: whitespace-separated elements,
    brace-delimited elements may nest and are returned with braces
    stripped (not recursively parsed -- callers recurse explicitly where a
    sub-element is itself known to be a list/dict). Sufficient for this
    machine-generated, well-formed dump (no literal unbalanced braces or
    backslash-escaping in the actual data)."""
    if end is None:
        end = len(text)
    elements = []
    n = end
    while True:
        while pos < n and text[pos] in " \t\n\r":
            pos += 1
        if pos >= n:
            break
        if text[pos] == "{":
            depth = 1
            start = pos + 1
            pos += 1
            while pos < n and depth > 0:
                if text[pos] == "{":
                    depth += 1
                elif text[pos] == "}":
                    depth -= 1
                pos += 1
            elements.append(text[start:pos - 1])
        else:
            start = pos
            while pos < n and text[pos] not in " \t\n\r":
                pos += 1
            elements.append(text[start:pos])
    return elements, pos


def as_pairs(list_text):
    elements, _ = parse_tcl_list(list_text)
    if len(elements) % 2 != 0:
        raise ValueError(f"expected an even-length (key value)* list, got {len(elements)} elements")
    return dict(zip(elements[0::2], elements[1::2]))


def translate_instruction(atom_name, instr_text):
    """SIRAH's per-atom build instruction -> this repo's schema."""
    parts, _ = parse_tcl_list(instr_text)
    kind = parts[0]
    if kind == ":":
        sources = parts[1:]
        source = sources[0] if len(sources) == 1 else sources
        return {"atom": atom_name, "op": "copy", "source": source}
    if kind == "+":
        refs, _ = parse_tcl_list(parts[1])
        r, theta, phi = parse_tcl_list(parts[2])[0]
        return {"atom": atom_name, "op": "place", "refs": refs,
                "r": float(r), "theta": float(theta), "phi": float(phi)}
    raise ValueError(f"unknown instruction kind {kind!r} for atom {atom_name!r}: {instr_text!r}")


def translate_entry(key, entry_text):
    fields = as_pairs(entry_text)
    if "nomap" in fields:
        return {"nomap": True}

    out_instructions = []
    if "build" in fields:
        for atom_name, instr_text in as_pairs(fields["build"]).items():
            out_instructions.append(translate_instruction(atom_name, instr_text))

    print_list, _ = parse_tcl_list(fields["print"])

    entry = {
        "output_resname": fields["name"].strip(),
        "instructions": out_instructions,
        "print": print_list,
    }

    # SIRAH applies 'first'/'last' overrides based on the residue's ACTUAL
    # chain position at runtime (does it have a res-/res+ neighbor?), not
    # based on which CG resname (s/n/c/a/m-prefixed) was looked up --
    # confirmed by reading sirah_build's own logic. Store them separately
    # (applied by reconstruct.py's chain-position check), not merged
    # unconditionally into 'instructions'.
    for position, field_name in (("first_override", "first"), ("last_override", "last")):
        if field_name in fields:
            sub_fields = as_pairs(fields[field_name])
            if "apply" in sub_fields:
                raise NotImplementedError(
                    f"{key!r}: '{field_name} apply' (whole-recipe swap) is only used by "
                    f"SIRAH's own DNA model, which this repo doesn't port -- unexpected on "
                    f"a protein entry, investigate before proceeding."
                )
            if "build" in sub_fields:
                entry[position] = [
                    translate_instruction(atom_name, instr_text)
                    for atom_name, instr_text in as_pairs(sub_fields["build"]).items()
                ]

    return entry


def build_table(mapdb_proc_text):
    dump_text = dump_backmap_dict(mapdb_proc_text)
    all_entries = as_pairs(dump_text)

    # Discover the full set of amino-acid position codes from the internal
    # ('s'-prefixed) entries, then keep every s/n/c/a/m variant that exists
    # for each -- avoids hand-enumerating SIRAH's ~30 residue/variant codes.
    aa_codes = sorted({k[1:] for k in all_entries if k.startswith("s") and k[1:]})
    keep_protein = {
        f"{prefix}{code}"
        for code in aa_codes
        for prefix in PROTEIN_PREFIXES
        if f"{prefix}{code}" in all_entries
    }

    table = {}
    for key in keep_protein | NOMAP_NAMES | ION_COPY_NAMES:
        if key not in all_entries:
            continue
        table[key] = translate_entry(key, all_entries[key])

    # SIRAH's n/c/a/m (position-variant) entries turn out to be byte-
    # identical to their 's' (internal) counterpart for every residue in
    # this table (verified: 124/124 comparisons, zero exceptions) -- the
    # backmap build recipe genuinely doesn't depend on chain position
    # (tleap's own default first/last-residue-in-chain detection is what
    # actually adds terminal H1/H2/H3/OXT later, not this table). Collapse
    # the duplicates to 'alias_of' rather than storing identical data 5x.
    for code in aa_codes:
        base_key = f"s{code}"
        if base_key not in table:
            continue
        for prefix in "ncam":
            key = f"{prefix}{code}"
            if key in table and table[key] == table[base_key]:
                table[key] = {"alias_of": base_key}

    return table


def main():
    if len(sys.argv) != 2:
        sys.exit(f"Usage: {sys.argv[0]} /path/to/sirah_vmdtk.tcl")
    tcl_path = sys.argv[1]

    proc_text = extract_mapdb_proc(tcl_path)
    table = build_table(proc_text)

    repo_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    out_path = os.path.join(repo_root, "params", "backmap_sirah.json")
    with open(out_path, "w") as f:
        json.dump(table, f, indent=2, sort_keys=True)
        f.write("\n")

    n_recipes = sum(1 for v in table.values() if "instructions" in v)
    n_nomap = sum(1 for v in table.values() if v.get("nomap"))
    print(f"Wrote {out_path}: {n_recipes} buildable recipes, {n_nomap} nomap entries "
          f"({len(table)} total).")


if __name__ == "__main__":
    main()
