"""Optional post-hoc re-solvation of a backmapped (hydrogenated, solute-
only) structure with real explicit water.

Mirrors cg_dna/tleap_build.py's exact template-string + subprocess.run +
returncode/file-existence-check pattern, but for ALL-ATOM force fields
(leaprc.protein.ff14SB / leaprc.DNA.OL15) instead of SIRAH's CG ones --
matches the documented SIRAH workflow this tool otherwise follows: CG
water is dropped during backmapping (see reconstruct.py's `nomap`
handling), then re-solvated fresh, exactly as SIRAH's own sirah_backmap
tool expects the user to do afterward.

Applied once, to a single (solute-only) structure -- typically frame 0's
already-hydrogenated topology/coordinates, since the solute topology is
identical across every frame of one system. Re-solvating every individual
frame independently (a different, disconnected water arrangement per
frame) is a legitimate but separate use case; call build_tleap_script/
run_tleap yourself per frame if you need that -- it is not exposed as a
first-class backmap_dna.py CLI mode.
"""
import os
import subprocess

_TLEAP_TEMPLATE = """\
{source_lines}\
m = loadpdb {solute_pdb}
solvatebox m TIP3PBOX {box_pad}
addionsrand m Na+ 0
addionsrand m Cl- 0
saveamberparm m {prmtop} {inpcrd}
quit
"""


def build_tleap_script(solute_pdb, out_prefix, has_protein, has_dna, box_pad=10.0):
    source_lines = ""
    if has_protein:
        source_lines += "source leaprc.protein.ff14SB\n"
    if has_dna:
        source_lines += "source leaprc.DNA.OL15\n"
    source_lines += "source leaprc.water.tip3p\n"
    prmtop = f"{out_prefix}.prmtop"
    inpcrd = f"{out_prefix}.inpcrd"
    text = _TLEAP_TEMPLATE.format(
        source_lines=source_lines,
        solute_pdb=os.path.abspath(solute_pdb),
        box_pad=box_pad,
        prmtop=prmtop,
        inpcrd=inpcrd,
    )
    return text, prmtop, inpcrd


def run_tleap(solute_pdb, out_prefix, has_protein, has_dna, box_pad=10.0, tleap_bin="tleap"):
    out_dir = os.path.dirname(os.path.abspath(out_prefix)) or "."
    os.makedirs(out_dir, exist_ok=True)

    text, prmtop, inpcrd = build_tleap_script(solute_pdb, out_prefix, has_protein, has_dna, box_pad=box_pad)
    tleap_in = f"{out_prefix}_resolvate.in"
    with open(tleap_in, "w") as fh:
        fh.write(text)

    result = subprocess.run(
        [tleap_bin, "-f", os.path.basename(tleap_in)],
        cwd=out_dir, capture_output=True, text=True, errors="replace",
    )
    if result.returncode != 0 or not os.path.isfile(prmtop) or not os.path.isfile(inpcrd):
        raise RuntimeError(
            f"tleap re-solvation failed (exit {result.returncode}). Full output:\n"
            f"{result.stdout}\n{result.stderr}"
        )
    return prmtop, inpcrd
