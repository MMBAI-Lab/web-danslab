"""cg_backmap: recover an all-atom trajectory from a finished CG MD run of
the ηθDNA force field, v17 or v18 (DNA-only or DNA+protein/SIRAH).

See backmap_dna.py at the repo root for the command-line entry point; the
functions in this package are also meant to be imported directly.
"""
