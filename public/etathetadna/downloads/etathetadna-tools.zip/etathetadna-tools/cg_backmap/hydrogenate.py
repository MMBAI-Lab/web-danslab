"""Per-frame hydrogen placement + vacuum minimization.

Ported protocol, same defaults as SIRAH's own sirah_backmap
(sirah_vmdtk.tcl:2238-2488,2657-2676): tleap's own residue-template
matching (keyed off each residue's output_resname) is what actually adds
hydrogens when loading a heavy-atom-only PDB -- there is no separate H-
builder in this tool. A short vacuum minimization (100 steepest-descent +
50 conjugate-gradient steps, no periodic box, no implicit solvent, 12 A
cutoff) then relaxes the strain introduced by the idealized NeRF geometry
and the freshly-placed hydrogens.

Must run once per frame (hydrogen COORDINATES depend on that frame's own
heavy-atom geometry), but each frame is fully independent -- see
backmap_dna.py's --jobs flag for parallel execution across frames.
"""
import os
import subprocess

_MIN_IN_TEMPLATE = """\
Minimization
&cntrl
imin=1,ntmin=1,maxcyc={maxcyc},ncyc={ncyc},ntpr=50,ntxo=2,
ntb=0,igb=0,cut={cutoff}
/
"""

_LEAP_TEMPLATE = """\
{source_lines}\
m = loadpdb {heavy_pdb}
saveamberparm m {prmtop} {rst7}
quit
"""


def force_field_sources(has_protein, has_dna, has_ions=False):
    """The tleap 'source' lines for a frame's content (see
    build_hydrogenation_leap_script)."""
    lines = ""
    if has_protein:
        lines += "source leaprc.protein.ff14SB\n"
    if has_dna:
        lines += "source leaprc.DNA.OL15\n"
    if has_ions:
        lines += "source leaprc.water.tip3p\n"
    return lines


def build_hydrogenation_leap_script(heavy_pdb, out_prefix, has_protein, has_dna, has_ions=False):
    """Only sources the force fields actually needed for THIS frame's
    residue content (unlike SIRAH's own script, which unconditionally
    sources ff14SB + lipid21 + phosaa + GLYCAM regardless of content --
    our systems are DNA and DNA+protein only, so there's no reason to
    carry that, and it keeps tleap's log easier to audit). G4 channel
    cations (K+/Na+) take their parameters from leaprc.water.tip3p, the
    water model resolvate.py solvates with."""
    if not (has_protein or has_dna):
        raise ValueError("heavy_pdb has neither protein nor DNA residues -- nothing to hydrogenate")
    source_lines = force_field_sources(has_protein, has_dna, has_ions)
    prmtop = f"{out_prefix}.prmtop"
    rst7 = f"{out_prefix}.rst7"
    text = _LEAP_TEMPLATE.format(
        source_lines=source_lines,
        heavy_pdb=os.path.abspath(heavy_pdb),
        prmtop=prmtop,
        rst7=rst7,
    )
    return text, prmtop, rst7


def hydrogenate_and_minimize_frame(heavy_pdb, out_prefix, has_protein, has_dna, has_ions=False,
                                    tleap_bin="tleap", sander_bin="sander",
                                    maxcyc=150, ncyc=100, cutoff=12.0):
    """Run tleap (add H) then sander (vacuum minimization) for one frame's
    heavy-atom PDB. Returns (prmtop_path, coords) where coords is an
    (natom, 3) ndarray of the MINIMIZED, hydrogenated structure.

    Everything happens inside out_prefix's own directory (the caller is
    expected to give each frame its own scratch subdir) -- tleap/sander
    are run with cwd set there so their own relative-path outputs don't
    collide across parallel frames.
    """
    out_dir = os.path.dirname(os.path.abspath(out_prefix)) or "."
    os.makedirs(out_dir, exist_ok=True)

    leap_text, prmtop, rst7 = build_hydrogenation_leap_script(heavy_pdb, out_prefix, has_protein, has_dna, has_ions)
    leap_in = f"{out_prefix}_tleap.in"
    with open(leap_in, "w") as fh:
        fh.write(leap_text)
    result = subprocess.run([tleap_bin, "-f", os.path.basename(leap_in)],
                             cwd=out_dir, capture_output=True, text=True, errors="replace")
    if result.returncode != 0 or not os.path.isfile(prmtop) or not os.path.isfile(rst7):
        raise RuntimeError(
            f"tleap hydrogenation failed for {heavy_pdb} (exit {result.returncode}). "
            f"Full output:\n{result.stdout}\n{result.stderr}"
        )

    min_in = f"{out_prefix}_min.in"
    with open(min_in, "w") as fh:
        fh.write(_MIN_IN_TEMPLATE.format(maxcyc=maxcyc, ncyc=ncyc, cutoff=cutoff))
    min_out = f"{out_prefix}_min.out"
    min_rst = f"{out_prefix}_min.ncrst"
    sander_cmd = [
        sander_bin, "-O",
        "-i", os.path.basename(min_in),
        "-p", os.path.basename(prmtop),
        "-c", os.path.basename(rst7),
        "-o", os.path.basename(min_out),
        "-r", os.path.basename(min_rst),
    ]
    result = subprocess.run(sander_cmd, cwd=out_dir, capture_output=True, text=True, errors="replace")
    if result.returncode != 0 or not os.path.isfile(min_rst):
        raise RuntimeError(
            f"sander minimization failed for {heavy_pdb} (exit {result.returncode}). "
            f"Full output:\n{result.stdout}\n{result.stderr}"
        )

    import parmed as pmd     # here, so that the leap/min templates above load without ParmEd

    minimized = pmd.load_file(prmtop, xyz=min_rst)
    coords = minimized.coordinates.copy()
    return prmtop, coords
