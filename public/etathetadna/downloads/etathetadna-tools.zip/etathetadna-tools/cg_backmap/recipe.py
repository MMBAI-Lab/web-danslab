"""Load and validate backmapping recipe tables (params/backmap_dna.json,
params/backmap_sirah.json).

Schema, per CG residue name:
    {"output_resname": "DC",
     "instructions": [
         {"atom": "P", "op": "copy", "source": "PC"},
         {"atom": "C2", "op": "place", "refs": ["N1", "O2", "N3"],
          "r": 1.22, "theta": 30.0, "phi": 0.0},
         ...
     ],
     "print": ["P", "OP1", ...]}

"copy" source may be a single bead name or a list of fallback candidates,
tried in order (first one actually present in that CG residue wins) --
mirrors SIRAH's own ":"-instruction semantics exactly (e.g. their DNA
table's "C1' {: O3' C1X}").
A DNA entry may also carry conformer templates (built by
cg_backmap/tools/derive_dna_constants.py):
    "conformers": {"A": [...], "syn": [...], "Z": [...]},
        alternative instruction lists (same atoms, same refs, constants
        measured on another conformation); "instructions" is the default B;
    "fit": {"C1'": {"refs": ["N9", "C4", "C8"], "r": .., "theta": .., "phi": ..},
            "bonds": [["O5'", "P", 1.59], ["O3'", "P/+", 1.61]],
            "chi": {"B": -111, "A": -167, "syn": 65, "Z": 65}}
        what reconstruct.py scores to pick one per nucleotide: C1' placed
        from the base against C1' from the template, and bond lengths
        (a "/+" atom is the next residue's copied bead); a template is
        only eligible if the chi it gives is within 90 deg of its "chi".
or:
    {"nomap": true}                 # dropped entirely (water/ions)
or:
    {"alias_of": "DCX"}             # reuse another entry's recipe verbatim

A ref atom name may be suffixed "/-" (previous residue, by bond
connectivity) or "/+" (next residue); unsuffixed = same residue.
"""
import json


def resolve_ref(atom_name):
    """'C4\\'/-' -> ("C4'", -1); 'C4\\'' -> ("C4'", 0); 'C4\\'/+' -> ("C4'", +1)."""
    if atom_name.endswith("/-"):
        return atom_name[:-2], -1
    if atom_name.endswith("/+"):
        return atom_name[:-2], +1
    return atom_name, 0


def _check_instructions(name, label, instructions):
    """Every same-residue 'place' ref must be built earlier in the list;
    returns the set of atoms the list builds."""
    built = set()
    for instr in instructions:
        if instr["op"] == "copy":
            built.add(instr["atom"])
        elif instr["op"] == "place":
            for ref in instr["refs"]:
                atom, offset = resolve_ref(ref)
                if offset == 0 and atom not in built:
                    raise ValueError(
                        f"{name} ({label}): 'place' instruction for {instr['atom']!r} "
                        f"references {ref!r} before it is built (check instruction order)"
                    )
            built.add(instr["atom"])
        else:
            raise ValueError(f"{name} ({label}): unknown op {instr['op']!r} for atom {instr['atom']!r}")
    return built


def load_recipes(*json_paths):
    """Merge one or more recipe JSON files, resolve 'alias_of' entries, and
    validate every 'place' instruction's refs are resolvable given that
    entry's own instruction order (same-residue refs only -- cross-residue
    refs are, by construction, always available since they point at a
    neighbor's already-fully-built residue). Raises ValueError on a
    duplicate CG residue name across files (a real conflict) or an
    unresolvable/misordered 'place' instruction.
    """
    merged = {}
    for path in json_paths:
        with open(path) as f:
            table = json.load(f)
        for name, entry in table.items():
            if name in merged:
                raise ValueError(f"duplicate recipe for CG residue {name!r} (in {path})")
            merged[name] = entry

    # Resolve aliases (copy the target's full entry, keep looking up
    # transitively in case an alias points at another alias).
    def resolve_alias(name, seen=()):
        entry = merged[name]
        if "alias_of" not in entry:
            return entry
        target = entry["alias_of"]
        if target in seen:
            raise ValueError(f"alias cycle: {' -> '.join(seen)} -> {target}")
        return resolve_alias(target, seen + (name,))

    resolved = {name: resolve_alias(name) for name in merged}

    for name, entry in resolved.items():
        if entry.get("nomap"):
            continue
        variants = {"instructions": entry["instructions"]}
        variants.update({f"conformer {c!r}": instrs for c, instrs in entry.get("conformers", {}).items()})
        for label, instructions in variants.items():
            built = _check_instructions(name, label, instructions)
            missing_print = [a for a in entry["print"] if a not in built]
            if missing_print:
                raise ValueError(f"{name} ({label}): 'print' lists atom(s) never built: {missing_print}")
            fit = entry.get("fit")
            if fit:
                needed = [resolve_ref(r) for r in fit["C1'"]["refs"]] + [("C1'", 0)]
                needed += [resolve_ref(r) for bond in fit["bonds"] for r in bond[:2]]
                absent = [a for a, offset in needed if offset == 0 and a not in built]
                if absent:
                    raise ValueError(f"{name} ({label}): 'fit' uses atom(s) never built: {absent}")
        if entry.get("conformers"):
            no_chi = ({"B"} | set(entry["conformers"])) - set(entry.get("fit", {}).get("chi", {}))
            if no_chi:
                raise ValueError(f"{name}: 'fit' has no chi for template(s) {sorted(no_chi)}")

    return resolved
