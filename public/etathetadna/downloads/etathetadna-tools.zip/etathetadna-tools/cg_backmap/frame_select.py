"""Discover a CG trajectory's chunk files, pick N evenly-spaced frames
across the whole (potentially multi-chunk) run, and extract each selected
frame as a standalone restart file.

Chunk-naming convention (md.nc, md2.nc, ..., mdN.nc) mirrors the one
used by the v17 and v18 production campaigns (and by run_md.sh)
(see campaña_final/analyze_all.py's find_replica_trajs()), simplified to
one replica directory at a time -- this tool backmaps one finished run,
not a whole multi-replica campaign.
"""
import os
import subprocess

import parmed as pmd


def discover_traj_chunks(traj_dir, base="md"):
    """md.nc, md2.nc, ..., mdN.nc -- only the ones that actually exist, in
    order. Stops at the first gap (same convention as
    campaña_final/analyze_all.py's chunk discovery)."""
    chunks = []
    first = os.path.join(traj_dir, f"{base}.nc")
    if not os.path.exists(first):
        return chunks
    chunks.append(first)
    n = 2
    while True:
        path = os.path.join(traj_dir, f"{base}{n}.nc")
        if not os.path.exists(path):
            break
        chunks.append(path)
        n += 1
    return chunks


def chunk_frame_counts(chunk_paths):
    """Frame count per chunk, via ParmEd's own NetCDF reader -- no
    subprocess needed for this purely administrative query (ParmEd is
    already a hard dependency)."""
    counts = []
    for path in chunk_paths:
        traj = pmd.amber.NetCDFTraj.open_old(path)
        counts.append(traj.frame)
        traj.close()
    return counts


def select_global_frames(frame_counts, n_frames):
    """Evenly spaced GLOBAL frame indices (0-based) across the full
    concatenated trajectory. Deduplicated and warns if n_frames exceeds
    the total available (falls back to every frame)."""
    import numpy as np

    total = sum(frame_counts)
    if total == 0:
        raise ValueError("no frames found across the given chunks")
    if n_frames > total:
        print(f"Warning: --n-frames {n_frames} exceeds the {total} frames available; using all {total}.")
        n_frames = total
    idx = np.linspace(0, total - 1, n_frames, dtype=int)
    return sorted(set(int(i) for i in idx))


def global_to_chunk_local(frame_counts, global_idx):
    """(chunk_index, local_frame_index) -- local_frame_index is 1-based
    (cpptraj's own trajin frame numbering)."""
    cursor = 0
    for chunk_idx, count in enumerate(frame_counts):
        if global_idx < cursor + count:
            return chunk_idx, (global_idx - cursor) + 1
        cursor += count
    raise IndexError(f"global frame index {global_idx} is out of range (total {cursor} frames)")


def extract_cg_frame(prmtop_path, chunk_path, local_idx, out_rst7, cpptraj_bin="cpptraj"):
    """Extract ONE frame (1-based local_idx within chunk_path) as an
    AMBER restart file, autoimaged (avoids split-across-periodic-boundary
    artifacts that would corrupt the bond-connectivity-based chain
    discovery in reconstruct.py). Mirrors campaña_final/
    generate_overlays.py's build_reference/extract_frame
    script-generation + subprocess.run pattern."""
    out_dir = os.path.dirname(os.path.abspath(out_rst7)) or "."
    os.makedirs(out_dir, exist_ok=True)
    script = [
        f"parm {os.path.abspath(prmtop_path)}",
        f"trajin {os.path.abspath(chunk_path)} {local_idx} {local_idx}",
        "autoimage",
        f"trajout {os.path.abspath(out_rst7)} restart",
        "go", "quit",
    ]
    scpath = f"{out_rst7}.cpptraj"
    with open(scpath, "w") as fh:
        fh.write("\n".join(script) + "\n")
    result = subprocess.run([cpptraj_bin, "-i", scpath], capture_output=True, text=True, errors="replace")
    if result.returncode != 0 or not os.path.isfile(out_rst7):
        raise RuntimeError(
            f"cpptraj frame extraction failed ({chunk_path} frame {local_idx}):\n"
            f"{result.stdout}\n{result.stderr}"
        )
    return out_rst7


def select_and_extract(prmtop_path, traj_dir, n_frames, scratch_dir, cpptraj_bin="cpptraj"):
    """Convenience wrapper: discover chunks in traj_dir, pick n_frames
    evenly-spaced global indices, extract each as scratch_dir/frame_%04d.rst7.
    Returns a list of (global_idx, rst7_path) in ascending global_idx order."""
    chunks = discover_traj_chunks(traj_dir)
    if not chunks:
        raise FileNotFoundError(f"no md.nc/md2.nc/... chunks found in {traj_dir}")
    counts = chunk_frame_counts(chunks)
    global_idxs = select_global_frames(counts, n_frames)

    os.makedirs(scratch_dir, exist_ok=True)
    out = []
    for k, gidx in enumerate(global_idxs):
        chunk_idx, local_idx = global_to_chunk_local(counts, gidx)
        rst7 = os.path.join(scratch_dir, f"frame_{k:04d}.rst7")
        extract_cg_frame(prmtop_path, chunks[chunk_idx], local_idx, rst7, cpptraj_bin=cpptraj_bin)
        out.append((gidx, rst7))
    return out
