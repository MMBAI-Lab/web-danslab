"""Combine N independent, already-hydrogenated-and-minimized per-frame
coordinate sets into one multi-frame AMBER NetCDF trajectory + shared
prmtop.

ParmEd, not cpptraj, for this step: by this point there's no trajectory-
chunking or box-imaging left to do (that was frame_select.py's job) --
just N (natom, 3) arrays to stack, and ParmEd is already a hard
dependency, so this adds no new tool.
"""
import shutil

import parmed as pmd


def write_multiframe_nc(coords_per_frame, out_nc, natom, title="backmapped"):
    """coords_per_frame: list of (natom, 3) ndarrays, already in the
    correct final frame order (see backmap_dna.py's --jobs handling --
    frame order must be tracked by explicit index, not worker completion
    order, when run in parallel)."""
    for i, c in enumerate(coords_per_frame):
        if c.shape != (natom, 3):
            raise ValueError(f"frame {i}: expected shape ({natom}, 3), got {c.shape}")

    traj = pmd.amber.NetCDFTraj.open_new(out_nc, natom, box=False, crds=True, title=title)
    for coords in coords_per_frame:
        traj.add_coordinates(coords)
    traj.close()


def write_final_prmtop(any_frame_prmtop, out_prmtop):
    """Topology (atom count/names/bonds) is identical across every frame
    of one system (same molecule, same tleap recipe each time) -- just
    copy any one frame's tleap-generated prmtop as the shared final one."""
    shutil.copyfile(any_frame_prmtop, out_prmtop)
