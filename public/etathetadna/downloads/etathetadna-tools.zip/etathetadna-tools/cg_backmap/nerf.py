"""NeRF (Natural Extension Reference Frame) atom placement -- the geometric
core of the backmapping reconstruction, ported from SIRAH's own `addatom`
Tcl proc (sirah_vmdtk.tcl:758-797), same reference-frame construction and
angle convention, generalized to numpy so many frames can be placed in one
call.
"""
import numpy as np


def place_nerf(at3, at2, at1, r, theta_deg, phi_deg):
    """Place a 4th point at bond length r from at3, bond angle theta_deg at
    (at4, at3, at2), and dihedral phi_deg at (at4, at3, at2, at1).

    at3, at2, at1: (N, 3) arrays (a single frame is (1, 3)). r/theta_deg/
    phi_deg: python floats -- every recipe constant in this project is one
    idealized scalar shared across all frames, never measured per-frame.

    Direct port of SIRAH's `addatom` proc: at3 is the bonded/nearest atom
    (the new atom sits off of it), at2 the middle reference, at1 the far
    dihedral reference. Returns an (N, 3) array.
    """
    at3 = np.asarray(at3, dtype=float)
    at2 = np.asarray(at2, dtype=float)
    at1 = np.asarray(at1, dtype=float)

    v12 = at1 - at2
    v32 = at3 - at2
    x_axis = np.cross(v32, v12)
    z_axis = np.cross(x_axis, v32)

    r23 = np.linalg.norm(v32, axis=-1, keepdims=True)
    e1 = x_axis / np.linalg.norm(x_axis, axis=-1, keepdims=True)
    e2 = v32 / r23
    e3 = z_axis / np.linalg.norm(z_axis, axis=-1, keepdims=True)

    d = np.radians(phi_deg)
    a = np.radians(180.0 - theta_deg)
    x = r * np.sin(a) * np.sin(d)
    y = r * np.cos(a) + r23[..., 0]
    z = r * np.sin(a) * np.cos(d)

    return at2 + e1 * x[..., None] + e2 * y[..., None] + e3 * z[..., None]


def dihedral(a, b, c, d):
    """Dihedral angle a-b-c-d of four (3,) points, degrees in (-180, 180]."""
    a, b, c, d = (np.asarray(x, dtype=float) for x in (a, b, c, d))
    b0, b1, b2 = a - b, c - b, d - c
    b1 = b1 / np.linalg.norm(b1)
    v = b0 - np.dot(b0, b1) * b1
    w = b2 - np.dot(b2, b1) * b1
    return float(np.degrees(np.arctan2(np.dot(np.cross(b1, v), w), np.dot(v, w))))


def measure_internal_coords(p_at3, p_at2, p_at1, p_at4):
    """Single-frame inverse of place_nerf: recover (r, theta_deg, phi_deg)
    from 4 real (3,) coordinates, using the same reference-frame convention
    as place_nerf. Used only by tools/derive_dna_constants.py to calibrate
    idealized constants from a real reference structure -- never imported
    at backmapping runtime.
    """
    p_at3 = np.asarray(p_at3, dtype=float)
    p_at2 = np.asarray(p_at2, dtype=float)
    p_at1 = np.asarray(p_at1, dtype=float)
    p_at4 = np.asarray(p_at4, dtype=float)

    v43 = p_at4 - p_at3
    r = np.linalg.norm(v43)

    v23 = p_at2 - p_at3
    cos_theta = np.dot(v43, v23) / (np.linalg.norm(v43) * np.linalg.norm(v23))
    theta_deg = np.degrees(np.arccos(np.clip(cos_theta, -1.0, 1.0)))

    # Dihedral at4-at3-at2-at1, standard formula via the two half-plane normals.
    b1 = p_at3 - p_at4
    b2 = p_at2 - p_at3
    b3 = p_at1 - p_at2
    n1 = np.cross(b1, b2)
    n2 = np.cross(b2, b3)
    m1 = np.cross(n1, b2 / np.linalg.norm(b2))
    x = np.dot(n1, n2)
    y = np.dot(m1, n2)
    # Negated relative to the textbook dihedral formula: place_nerf (a direct
    # port of SIRAH's addatom) uses the opposite handedness for d4, verified
    # by this function's own round-trip test (tests/test_nerf.py).
    phi_deg = -np.degrees(np.arctan2(y, x))

    return float(r), float(theta_deg), float(phi_deg)
