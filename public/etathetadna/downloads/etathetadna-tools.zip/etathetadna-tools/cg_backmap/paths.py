"""Resolve bundled backmapping recipe-table paths.

Unlike cg_dna (which needs a user-supplied SIRAH installation at runtime,
via --sirah-dir/SIRAH_HOME), cg_backmap needs no external force field
install: SIRAH's own protein/water backmapping recipe was extracted once
(see tools/extract_sirah_table.py) and is bundled here as plain data,
same policy as cg_dna's own dna_vf.lib/repeat.lib/frcmod files.
"""
import os

from cg_dna.paths import PARAMS_DIR

BACKMAP_DNA_JSON = os.path.join(PARAMS_DIR, "backmap_dna.json")
BACKMAP_SIRAH_JSON = os.path.join(PARAMS_DIR, "backmap_sirah.json")


def check_bundled_params():
    """Sanity check the bundled recipe tables are present (protects against
    a partial checkout/clone) before doing any real work."""
    missing = [p for p in (BACKMAP_DNA_JSON, BACKMAP_SIRAH_JSON) if not os.path.isfile(p)]
    if missing:
        raise SystemExit(
            "Missing bundled backmapping recipe file(s):\n  " + "\n  ".join(missing) +
            "\nThis looks like a partial checkout of the repo."
        )
