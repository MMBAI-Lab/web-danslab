"""Resolve bundled parameter file paths and the user's SIRAH installation.

SIRAH (http://www.sirahff.com) is a third-party force field and is
deliberately NOT bundled in this repo -- point --sirah-dir (or the
SIRAH_HOME environment variable) at your own SIRAH install, the same way
the AMBER binaries themselves are an external dependency you install
separately.
"""
import os

# This file lives at <repo_root>/cg_dna/paths.py.
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARAMS_DIR = os.path.join(REPO_ROOT, "params")

DNA_VF_LIB = os.path.join(PARAMS_DIR, "dna_vf.lib")
REPEAT_LIB = os.path.join(PARAMS_DIR, "repeat.lib")
CATIONS_G4_LIB = os.path.join(PARAMS_DIR, "cationes_g4.lib")
FRCMOD_DIR = os.path.join(PARAMS_DIR, "frcmod")
CMAP_DIR = os.path.join(PARAMS_DIR, "cmap")
RUN_SCRIPT = os.path.join(PARAMS_DIR, "run_md.sh")

# Loaded via `loadamberparams` in exactly this order -- the stack of the v18
# final benchmark campaign. cationes_g4.frcmod only defines the G4 channel
# cations KW4/NW4 and their pairs: it changes nothing in systems without them.
FRCMOD_FILES = [
    "umbrella_v16.dat",            # base force field (PG vdW fix, eta/theta and cousins at 0)
    "repeat_AT_v15.dat",           # A/T "repeat"-variant bonded terms
    "repeat_GC_v15.dat",           # G/C "repeat"-variant bonded terms
    "v16_zero_pk_torsions.frcmod",  # zeroes the 1D P-K torsions (replaced by the CMAP)
    "LJoff_eta-theta.frcmod",      # off-diagonal LJ: WC/Hoogsteen/sugar-edge pairing strengths
    "cationes_g4.frcmod",          # G4 channel cations KW4/NW4 (bare-ion radii towards the channel beads)
    "zero_cousin_dihedrals_fixed.frcmod",  # zeroes the cross-residue "cousin" torsions
    "soft_junction_angles_k10.frcmod",     # junction angles K-N-base, N-K-P, K-P-K (k reset to 20 after tleap)
]

CMAP_BASES = ["A", "C", "G", "T"]
CMAP_ET_GRIDS = CMAP_BASES + ["GZ", "CZ"]   # GZ/CZ: Z-typed G and C


def frcmod_paths():
    return [os.path.join(FRCMOD_DIR, name) for name in FRCMOD_FILES]


def etatheta_grid_path(key):
    """key: A, C, G, T, GZ or CZ."""
    return os.path.join(CMAP_DIR, f"etatheta_{key}.dat")


def chi_grid_path(base):
    return os.path.join(CMAP_DIR, f"chi_{base}.dat")


def resolve_sirah_dir(cli_value=None):
    """--sirah-dir flag takes priority; falls back to the SIRAH_HOME
    environment variable. Raises a clear error if neither is set/valid,
    since nothing downstream can proceed without SIRAH's water/ion (and,
    for the DNA+protein module, protein) force field files."""
    sirah_dir = cli_value or os.environ.get("SIRAH_HOME")
    if not sirah_dir:
        raise SystemExit(
            "No SIRAH installation given. Pass --sirah-dir /path/to/sirah "
            "or set the SIRAH_HOME environment variable. Get SIRAH from "
            "http://www.sirahff.com -- it is not bundled in this repo."
        )
    sirah_dir = os.path.abspath(sirah_dir)
    leaprc = os.path.join(sirah_dir, "leaprc.sirah")
    if not os.path.isfile(leaprc):
        raise SystemExit(
            f"'{sirah_dir}' does not look like a SIRAH installation "
            f"(expected to find leaprc.sirah there)."
        )
    return sirah_dir


def check_bundled_params():
    """Sanity check the bundled files are all present (protects against a
    partial checkout/clone) before doing any real work."""
    missing = [p for p in [DNA_VF_LIB, REPEAT_LIB, CATIONS_G4_LIB, RUN_SCRIPT, *frcmod_paths()]
               if not os.path.isfile(p)]
    missing += [etatheta_grid_path(k) for k in CMAP_ET_GRIDS if not os.path.isfile(etatheta_grid_path(k))]
    missing += [chi_grid_path(b) for b in CMAP_BASES if not os.path.isfile(chi_grid_path(b))]
    if missing:
        raise SystemExit(
            "Missing bundled parameter file(s):\n  " + "\n  ".join(missing) +
            "\nThis looks like a partial checkout of the repo."
        )
