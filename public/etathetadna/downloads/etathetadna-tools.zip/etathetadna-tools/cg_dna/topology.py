"""Post-tleap topology steps of the v18 model (steps 2-6 of cg_dna/model.py).

Each function edits a ParmEd Structure in place. finalize() runs the whole
chain on the CMAP-injected prmtop and writes the final one.

Ported, without changes in behaviour, from the scripts that built the v18
benchmark campaign in the main repo:
  step 2  model_iterations/v18/prep_T12/build_angleset.py (v17:20 v17:20 v17:20)
  step 3  model_iterations/v18/build_P28.py (g_angles, kn_angles)
  step 4  benchmark/campana_v18T29/build_v18T29.py (imp_quads_bonded)
  step 5  build_v18T29.py (ztype_bench, type_bench) + model_iterations/v18/build_T29.py
          (margin, apply29, cmap29) + build_T27.py (key, owned)
  step 6  benchmark/campana_v18T29/primos3p/build_3p.py (quads) + build_3pB.py
"""
from collections import defaultdict

import numpy as np
import parmed as pmd
from parmed.topologyobjects import CmapType, Dihedral, DihedralType

from . import cmap as cmapmod
from . import model as M
from . import paths


def _t(atom):
    return atom.type[0].upper() if atom.type else ""


def angle_deg(X, a):
    u, v = X[a.atom1.idx] - X[a.atom2.idx], X[a.atom3.idx] - X[a.atom2.idx]
    return float(np.degrees(np.arccos(np.clip(u @ v / np.linalg.norm(u) / np.linalg.norm(v), -1, 1))))


def dihedral_deg(X, idx):
    """Dihedral of 4 atom indices, degrees in [0, 360)."""
    p = X[list(idx)]
    b0, b1, b2 = p[0] - p[1], p[2] - p[1], p[3] - p[2]
    b1 = b1 / np.linalg.norm(b1)
    v, w = b0 - (b0 @ b1) * b1, b2 - (b2 @ b1) * b1
    return float(np.degrees(np.arctan2(np.cross(b1, v) @ w, v @ w)) % 360)


def dna_residues(p):
    return {r.idx for r in p.residues if any(a.name in M.KNAMES for a in r.atoms)}


def res_base(r):
    """Base letter as the Z typing reads it (DGX/DG1 -> G, GX5 -> G, DMC -> M)."""
    return r.name[1] if r.name[0] == "D" else r.name[0]


# ------------------------------------------------------------------ step 2
def junction_angles_k20(p):
    """K-N-base, N-K-P (own and next P) and K-P-K angles: same theta0
    (rounded to 0.01 deg), k = 20."""
    types, n = {}, defaultdict(int)
    for a in p.angles:
        t = [_t(x) for x in (a.atom1, a.atom2, a.atom3)]
        e = sorted([t[0], t[2]])
        if t[1] == "N" and "K" in e:
            cls = "KNB"
        elif t[1] == "K" and e == ["N", "P"]:
            cls = "NKP"
        elif t[1] == "P" and e == ["K", "K"]:
            cls = "KPK"
        else:
            continue
        tk = (round(a.type.theteq, 2), round(M.JUNCTION_K, 2))
        if tk not in types:
            types[tk] = pmd.AngleType(tk[1], tk[0], list=p.angle_types)
            p.angle_types.append(types[tk])
        a.type = types[tk]
        n[cls] += 1
    return dict(n)


# ------------------------------------------------------------------ step 3
def kn5(p):
    """Guanine only: P-K-N / N-K-P(i+1) to 89.0 / 86.8 at k 10, and
    C4'-N9-N3 / C4'-N9-N7 to k 5 (theta0 unchanged)."""
    dna = dna_residues(p)
    if any(a.atom2.type in ("KG", "Kg") and a.atom2.residue.idx not in dna for a in p.angles):
        raise RuntimeError("angles centred on a KG/Kg bead outside the DNA")
    n1 = 0
    for a in p.angles:
        if a.atom2.type not in ("KG", "Kg") or {_t(a.atom1), _t(a.atom3)} != {"N", "P"}:
            continue
        P = a.atom1 if a.atom1.type[0] in "Pp" else a.atom3
        th0 = M.KN5_PKN_THETA0 if P.residue is a.atom2.residue else M.KN5_NKP_THETA0
        t = pmd.AngleType(M.KN5_PKN_K, th0)
        p.angle_types.append(t)
        a.type = t
        n1 += 1
    n2 = 0
    for a in p.angles:
        ends = {a.atom1.name, a.atom3.name}
        if a.atom2.name != "N9G" or "C4G" not in ends or not ends & {"N3G", "N7G"}:
            continue
        t = pmd.AngleType(M.KN5_KNB_K, a.type.theteq)
        p.angle_types.append(t)
        a.type = t
        n2 += 1
    p.angle_types.claim()
    return n1, n2


# ------------------------------------------------------------------ step 4
def improper_quads(p):
    """(P(i), N(i), K(i), P(i+1)) with P(i+1) = the P bonded to C4'(i) in
    another residue (ring closures included)."""
    out = []
    for b in "GCAT":
        P, K, N = M.BEADS[b]
        for r in p.residues:
            nm = {a.name: a for a in r.atoms}
            if not all(x in nm for x in (P, K, N)):
                continue
            nxt = [x for x in nm[K].bond_partners if x.name in M.PNAMES and x.residue is not r]
            if nxt:
                out.append((nm[P].idx, nm[N].idx, nm[K].idx, nxt[0].idx))
    return out


def chirality_impropers(p):
    t = pmd.DihedralType(M.IMP_K, M.IMP_PER, M.IMP_PHASE)
    p.dihedral_types.append(t)
    Q = improper_quads(p)
    for q in Q:
        p.dihedrals.append(pmd.Dihedral(*[p.atoms[i] for i in q], improper=True, ignore_end=True, type=t))
    p.dihedral_types.claim()
    return Q


# ------------------------------------------------------------------ step 5
def angle_key(a):
    """(owner residue, class) of a DNA angle centred on P or K, or K-N-base;
    None for any other angle."""
    c = a.atom2
    ct = _t(c)
    e = (a.atom1, a.atom3)
    if ct == "P":
        prev = [x for x in e if x.residue.idx != c.residue.idx]
        return (c.residue.idx, f"K-P-K {res_base(prev[0].residue)}p{res_base(c.residue)}") if len(prev) == 1 else None
    if ct == "K":
        tag = frozenset("N" if _t(x) == "N" else "P" if x.residue.idx == c.residue.idx else "P+" for x in e)
        tag = {frozenset(["P", "N"]): "P-K-N", frozenset(["N", "P+"]): "N-K-P+", frozenset(["P", "P+"]): "P-K-P+"}.get(tag)
        return (c.residue.idx, tag) if tag else None
    if ct == "N" and any(_t(x) == "K" for x in e):
        o = [x for x in e if _t(x) != "K"][0]
        return c.residue.idx, f"K-{c.name}-{o.name}"
    return None


def owned_angles(p):
    """residue -> [(\"<base> <class>\", angle)] for angles whose 3 beads are DNA."""
    dna = dna_residues(p)
    out = defaultdict(list)
    for a in p.angles:
        if not {a.atom1.residue.idx, a.atom2.residue.idx, a.atom3.residue.idx} <= dna:
            continue
        k = angle_key(a)
        if k:
            out[k[0]].append((f"{res_base(p.residues[k[0]])} {k[1]}", a))
    return out


def _margin(X, L, classes):
    v = [abs(angle_deg(X, a) - a.type.theteq) - abs(angle_deg(X, a) - M.Z_THETA0[lab])
         for lab, a in L if lab in M.Z_THETA0 and lab.split(" ", 1)[1] in classes]
    return float(np.mean(v)) if v else None


def input_basins(p, X, i):
    """JCIM 2024 basins containing the input eta/theta of residue i (by
    bonds); None if eta/theta is undefined (chain ends)."""
    r = p.residues[i]
    nm = {a.name: a for a in r.atoms}
    K = next((nm[k] for k in M.KNAMES if k in nm), None)
    P = next((nm[x] for x in M.PNAMES if x in nm), None)
    if K is None or P is None:
        return None
    Kp = [x for x in P.bond_partners if x.name in M.KNAMES and x.residue is not r]
    Pn = [x for x in K.bond_partners if x.name in M.PNAMES and x.residue is not r]
    Kn = [x for x in Pn[0].bond_partners if x.name in M.KNAMES and x.residue is not r] if Pn else []
    if not (Kp and Pn and Kn):
        return None
    e = dihedral_deg(X, [Kp[0].idx, P.idx, K.idx, Pn[0].idx])
    t = dihedral_deg(X, [P.idx, K.idx, Pn[0].idx, Kn[0].idx])
    return [n for n, e0, e1, t0, t1 in M.BASINS if e0 <= e <= e1 and t0 <= t <= t1]


def z_typing(p, X):
    """Z typing from the input geometry. Returns (syn G, Z-backbone G, Z C,
    margins {G residue: (syn margin, backbone margin)}). Only Z-backbone G
    and Z C are retyped; a syn G without Z backbone (G4 tetrads) is not."""
    own = owned_angles(p)
    syn, bbz, margins = set(), set(), {}
    for i, L in own.items():
        if res_base(p.residues[i]) != "G":
            continue
        ms, mb = _margin(X, L, M.SYN_CLASSES), _margin(X, L, M.ZBB_CLASSES)
        margins[i] = (ms, mb)
        if ms is not None and ms >= M.Z_MARGIN:
            syn.add(i)
            if mb is not None and mb >= M.Z_MARGIN:
                bbz.add(i)
    # basin guard: input eta/theta in Ia -> Z backbone; in another catalogued
    # basin -> not; undefined or uncatalogued -> the angle margin decides
    guarded = set()
    for i in syn:
        bs = input_basins(p, X, i)
        if bs and "Ia" in bs:
            guarded.add(i)
        elif not bs and i in bbz:
            guarded.add(i)
    bbz = guarded

    def neighbours(i):
        return {x.residue.idx for a in p.residues[i].atoms for x in a.bond_partners} - {i}

    zc = set()
    for i, L in own.items():
        L = [(lab, a) for lab, a in L if lab in M.Z_THETA0]
        if res_base(p.residues[i]) != "C" or not L:
            continue
        dz = np.mean([abs(angle_deg(X, a) - M.Z_THETA0[lab]) for lab, a in L])
        db = np.mean([abs(angle_deg(X, a) - a.type.theteq) for lab, a in L])
        if dz < db and neighbours(i) & bbz:
            zc.add(i)
    return syn, bbz, zc, margins


def apply_z_angles(p, X, bbz, zc):
    """theta0 = Z value in the Z classes of the typed residues; k unchanged.
    Returns {(i, j, k): (class, Z theta0, input angle)}."""
    sel = {i: M.Z_CLASSES["G"] for i in bbz}
    sel.update({i: M.Z_CLASSES["C"] for i in zc})
    cache, new, own = {}, {}, owned_angles(p)
    for i, cls in sel.items():
        for lab, a in own[i]:
            if lab not in M.Z_THETA0 or lab.split(" ", 1)[1] not in cls:
                continue
            k = (a.type.k, M.Z_THETA0[lab])
            if k not in cache:
                cache[k] = pmd.AngleType(*k)
                p.angle_types.append(cache[k])
            a.type = cache[k]
            new[(a.atom1.idx, a.atom2.idx, a.atom3.idx)] = (lab, M.Z_THETA0[lab], angle_deg(X, a))
    p.angle_types.claim()
    return new


def is_etatheta(c):
    return c.atom4.type[0] in "Pp"


def grid_values(c):
    """CMAP grid of a term in file order (phi outer, psi inner)."""
    n = c.type.resolution
    return np.array([c.type.grid[i, j] for i in range(n) for j in range(n)])


def etatheta_grid_key(c, bbz, zc):
    i, r = c.atom3.residue.idx, c.atom3.residue
    b = cmapmod.base_of(r)
    zb = res_base(r)
    return b + ("Z" if (zb == "G" and i in bbz) or (zb == "C" and i in zc) else "")


def apply_z_cmaps(p, bbz, zc):
    """Give every eta/theta CMAP the grid of its base, or the GZ / CZ grid for
    Z-typed nucleotides. The phi/chi CMAPs are left alone."""
    types, n = {}, defaultdict(int)
    for c in p.cmaps:
        if not is_etatheta(c):
            continue
        k = etatheta_grid_key(c, bbz, zc)
        if k not in types:
            types[k] = CmapType(M.CMAP_RESOLUTION, cmapmod.load_grid(paths.etatheta_grid_path(k)))
            p.cmap_types.append(types[k])
        c.type = types[k]
        n[k] += 1
    p.cmap_types.claim()
    p.cmap_types.index_members()
    p.cmaps.index_members()
    return dict(n)


# ------------------------------------------------------------------ step 6
def tpb_quads(p):
    """[(class, (b, N, K, P(i+1)))] for every nucleotide with a bonded next P;
    class 'chi' if b is the chi bead, 'other' for the other base bead on N."""
    out = []
    for r in p.residues:
        K = [a for a in r.atoms if a.name in M.KNAMES]
        if not K:
            continue
        K = K[0]
        N = next(a for a in r.atoms if a.name in M.NNAMES)
        bases = [a for a in N.bond_partners if a is not K]
        if len(bases) != 2 or not {b.name for b in bases} <= set(M.CHI_BEAD_NAMES + M.OTHER_BEAD_NAMES):
            raise RuntimeError(f"{r}: unexpected beads bonded to {N.name}: {[b.name for b in bases]}")
        Pn = [a for a in K.bond_partners if a.name in M.PNAMES and a.residue is not r]
        if not Pn:
            continue   # 3' end
        Pn = Pn[0]
        for b in bases:
            out.append(("chi" if b.name in M.CHI_BEAD_NAMES else "other", (b, N, K, Pn)))
    return out


def add_3pB(p, typed):
    """Add the 3pB torsions that touch no Z-typed nucleotide. Returns
    (added, total candidates)."""
    allq = tpb_quads(p)
    Q = [(c, a) for c, a in allq if all(x.residue.idx not in typed for x in a)]
    if not Q:
        return 0, len(allq)
    types = {}
    for c, (k, per, ph) in M.TPB.items():
        types[c] = DihedralType(k, per, ph, 1.2, 2.0)
        p.dihedral_types.append(types[c])
    for c, a in Q:
        p.dihedrals.append(Dihedral(*a, improper=False, ignore_end=True, type=types[c]))
    p.dihedral_types.claim()
    return len(Q), len(allq)


# ------------------------------------------------------------------ chain
def finalize(cmap_prmtop, inpcrd, out_prmtop, ztype=True, verbose=True):
    """Steps 2-6 on the CMAP-injected topology; writes out_prmtop and returns
    a summary dict."""
    p = pmd.load_file(cmap_prmtop, inpcrd)
    X = np.asarray(p.coordinates)
    s = {}
    s["junction_k20"] = junction_angles_k20(p)
    s["kn5_angles"] = kn5(p)
    s["impropers"] = len(chirality_impropers(p))
    if ztype:
        syn, bbz, zc, margins = z_typing(p, X)
    else:
        syn, bbz, zc, margins = set(), set(), set(), {}
    s["z_angles"] = len(apply_z_angles(p, X, bbz, zc))
    s["etatheta_grids"] = apply_z_cmaps(p, bbz, zc)
    s["syn_G"], s["z_G"], s["z_C"] = sorted(syn), sorted(bbz), sorted(zc)
    s["3pB"] = add_3pB(p, bbz | zc)
    p.save(out_prmtop, overwrite=True)

    chk = pmd.load_file(out_prmtop)
    bad = [c for c in chk.cmaps if is_etatheta(c) and not np.allclose(
        grid_values(c), cmapmod.load_grid(paths.etatheta_grid_path(etatheta_grid_key(c, bbz, zc))), atol=1e-4)]
    if bad:
        raise RuntimeError(f"{len(bad)} eta/theta CMAP terms with the wrong grid after saving")
    if verbose:
        lab = lambda S: ", ".join(f"{p.residues[i].name}{p.residues[i].number}" for i in sorted(S)) or "none"
        print(f"junction angles at k 20: {s['junction_k20']}; kn5 (G) {s['kn5_angles'][0]} + {s['kn5_angles'][1]} angles; "
              f"{s['impropers']} C4' impropers")
        print(f"Z typing{'' if ztype else ' (disabled)'}: Z-backbone G {lab(bbz)}; Z C {lab(zc)}; "
              f"syn G left untyped {lab(syn - bbz)}")
        print(f"eta/theta CMAP grids {s['etatheta_grids']}; 3pB torsions {s['3pB'][0]} of {s['3pB'][1]}")
    return s
