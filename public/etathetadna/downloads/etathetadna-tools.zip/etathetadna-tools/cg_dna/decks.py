"""AMBER input decks of the v18 protocol (the decks of the v18 benchmark campaign).

DNA systems (em, [dens], eq, md, md2):
  em    1500 cycles, solute restrained (wt 10) -- run on CPU, see run_md.sh
  dens  only at high salt (>= 1 M): 50 ps NPT at 100 K, solute restrained,
        repeated by run_md.sh until the volume settles
  eq    750 ps NPT, dt 10 fs, TEMP0 ramp 0 -> 100 -> 298 K (nmropt = 1),
        solute restrained (wt 10)
  md    first 100 ns of production, dt 20 fs; md2 = every further 100 ns
DNA-protein systems (SIRAH multi-stage protocol, em1, em2, eq1, eq2, md, md2):
  em1   complex backbone restrained (wt 2.4); em2 whole solute (wt 2.4)
  eq1   5 ns NPT, ramp to 300 K, whole solute restrained (wt 2.4)
  eq2   25 ns NPT, backbone restrained (wt 0.24); production at 300 K
Every NPT stage uses the Monte Carlo barostat and Langevin dynamics
(gamma 50). Production carries the WC end restraint (DISANG) when the
system has restrainable ends. `chngmask = 0` everywhere: the CG bonded
topology relies on it.
"""
import os

# Every deck either protocol writes. run_md.sh picks its stages by which of
# them exist (dens_WT4.in -> compaction, em1_WT4.in -> DNA-protein protocol),
# so write() removes those an earlier build in the same directory left.
DECK_NAMES = ("em_WT4.in", "dens_WT4.in", "eq_WT4.in", "em1_WT4.in", "em2_WT4.in",
              "eq1_WT4.in", "eq2_WT4.in", "md_WT4.in", "md2_WT4.in")

_EWALD = "&ewald\n  chngmask=0,\n&end\n/\n"
_EWALD_SP = " &ewald\n  chngmask=0,\n &end\n /\n"


def _ramp(t_final):
    return (f" &wt type ='TEMP0',\n  istep1 = 0, istep2 = 12500,\n  value1 = 0.0, value2 = 100.0,\n /\n"
            f" &wt type ='TEMP0',\n  istep1 = 12500, istep2 = 25000,\n  value1 = 100.0, value2 = {t_final:.1f},\n /\n"
            f" &wt type ='TEMP0',\n  istep1 = 25000, istep2 = 0,\n  value1 = {t_final:.1f}, value2 = {t_final:.1f},\n /\n"
            " &wt type='END'\n /\n")


def _md(title, temp, disang, extra=""):
    nmr = 1 if disang else 0
    txt = (f"{title}\n &cntrl\n  imin = 0, ntx = 5, irest = 1, nmropt = {nmr},\n\n"
           "  nstlim = 5000000, dt = 0.020,\n  ntpr = 5000, ntwx = 5000, ntwr = 5000, ioutfm=1, ntxo=2,\n\n"
           "  ntb = 2, ntp = 1, pres0 = 1.0, barostat = 2,\n\n"
           f"  ntt = 3, gamma_ln = 50.0, ig = -1,\n  temp0 = {temp:.1f}, tempi = {temp:.1f},\n\n"
           f"  ntc = 1, ntf = 1,\n\n  cut = 12.0, nrespa = 1,\n{extra}\n &end\n /\n" + _EWALD_SP)
    if disang:
        txt += " &wt type='END'\n /\nDISANG=disang.rst\n &end\n"
    return txt


def dna_decks(name, mask, disang, high_salt):
    """{file name: text} for a DNA-only system. mask: restraintmask of the
    solute (DNA + channel cations), e.g. ':1-24'."""
    ends = "DISANG WC restraint on the terminal pairs" if disang else "no end restraint"
    d = {}
    d["em_WT4.in"] = (f"{name} -- EM, solute restrained (as in the EQ)\n&cntrl\n  imin = 1,\n"
                      f"  ntr = 1, restraint_wt=10, restraintmask='{mask}',\n"
                      "  maxcyc = 1500, ntmin=1, ncyc = 100, ntpr = 50, ntxo=2,\n\n  ntb = 1, ntp = 0,\n  cut = 12,\n&end\n/\n"
                      + _EWALD)
    if high_salt:
        d["dens_WT4.in"] = (f"{name} -- compaction before the EQ (high salt), 50 ps NPT at 100 K, solute restrained\n"
                            " &cntrl\n  imin = 0, ntx = 1, irest = 0, nmropt = 0,\n\n"
                            "  nstlim = 5000, dt = 0.010,\n  ntpr = 500, ntwx = 0, ntwr = 500, ioutfm=1, ntxo=2,\n\n"
                            "  ntb = 2, ntp = 1, pres0 = 1.0, barostat = 2,\n\n"
                            "  ntt = 3, gamma_ln = 50.0, ig = -1,\n  temp0 = 100.0, tempi = 0.0,\n\n"
                            "  ntc = 1, ntf = 1,\n\n  cut = 12.0, nrespa = 1,\n\n"
                            f"  ntr = 1,\n  restraint_wt=10,\n  restraintmask='{mask}',\n\n &end\n /\n" + _EWALD_SP)
    d["eq_WT4.in"] = (f"{name} -- EQ 750 ps NPT, solute restrained, ramp 0->100->298 K (nmropt=1)\n"
                      " &cntrl\n  imin = 0, ntx = 1, irest = 0, nmropt = 1,\n\n"
                      "  nstlim = 75000, dt = 0.010,\n  ntpr = 5000, ntwx = 5000, ntwr = 5000, ioutfm=1, ntxo=2,\n\n"
                      "  ntb = 2, ntp = 1, pres0 = 1.0, barostat = 2,\n\n"
                      "  ntt = 3, gamma_ln = 50.0, ig = -1,\n  temp0 = 298.0, tempi = 0.0,\n\n"
                      "  ntc = 1, ntf = 1,\n\n  cut = 12.0, nrespa = 1,\n\n"
                      f"  ntr = 1,\n  restraint_wt=10,\n  restraintmask='{mask}',\n\n &end\n /\n" + _EWALD_SP
                      + _ramp(298.0) + " &end\n")
    d["md_WT4.in"] = _md(f"{name} -- production, first 100 ns chunk; {ends}", 298.0, disang)
    d["md2_WT4.in"] = _md(f"{name} -- production, every further 100 ns chunk; {ends}", 298.0, disang)
    return d


BACKBONE_MASK = "@GN,GO,PA,PC,PG,PT,C4A,C4C,C4G,C4T"   # SIRAH protein backbone + DNA P and C4'


def protein_decks(name, mask, disang):
    """{file name: text} for a DNA-protein system. mask: the whole solute."""
    ends = "DISANG WC restraint on the DNA terminal pairs" if disang else "no end restraint"
    em = lambda what, m: (f"{name} -- {what} (wt 2.4)\n&cntrl\n  imin = 1,\n"
                          "  maxcyc = 5000, ntmin=1, ncyc = 100, ntpr = 50, ntxo=2,\n  ntb = 1, ntp = 0,\n  cut = 12,\n"
                          f"  ntr = 1,\n  restraint_wt=2.4,\n  restraintmask='{m}',\n&end\n/\n" + _EWALD)
    d = {"em1_WT4.in": em("em1: complex backbone restrained", BACKBONE_MASK),
         "em2_WT4.in": em("em2: whole solute restrained", mask)}
    d["eq1_WT4.in"] = (f"{name} -- eq1: 5 ns NPT, whole solute restrained (wt 2.4), ramp 0->100->300 K (nmropt=1)\n"
                       " &cntrl\n  imin = 0, ntx = 1, irest = 0, nmropt = 1,\n"
                       "  nstlim = 250000, dt = 0.020,\n  ntpr = 5000, ntwx = 5000, ntwr = 5000, ioutfm=1, ntxo=2,\n"
                       "  ntb = 2, ntp = 1, pres0 = 1.0, barostat = 2,\n"
                       "  ntt = 3, gamma_ln = 50.0, ig = -1,\n  temp0 = 300.0, tempi = 0.0,\n"
                       "  ntc = 1, ntf = 1,\n  cut = 12.0, nrespa = 1,\n"
                       f"  ntr = 1,\n  restraint_wt=2.4,\n  restraintmask='{mask}',\n &end\n /\n" + _EWALD_SP
                       + _ramp(300.0))
    d["eq2_WT4.in"] = (f"{name} -- eq2: 25 ns NPT, complex backbone restrained (wt 0.24), 300 K\n"
                       " &cntrl\n  imin = 0, ntx = 1, irest = 0,\n"
                       "  nstlim = 1250000, dt = 0.020,\n  ntpr = 5000, ntwx = 5000, ntwr = 5000, ioutfm=1, ntxo=2,\n"
                       "  ntb = 2, ntp = 1, pres0 = 1.0, barostat = 2,\n"
                       "  ntt = 3, gamma_ln = 50.0, ig = -1,\n  temp0 = 300.0, tempi = 300.0,\n"
                       "  ntc = 1, ntf = 1,\n  cut = 12.0, nrespa = 1,\n"
                       f"  ntr = 1,\n  restraint_wt=0.24,\n  restraintmask='{BACKBONE_MASK}',\n &end\n /\n" + _EWALD_SP)
    d["md_WT4.in"] = _md(f"{name} -- production, first 100 ns chunk, 300 K; {ends}", 300.0, disang, "\n  ntr = 0,")
    d["md2_WT4.in"] = _md(f"{name} -- production, every further 100 ns chunk, 300 K; {ends}", 300.0, disang, "\n  ntr = 0,")
    return d


def write(decks, out_dir):
    """Write the decks, and remove the decks of DECK_NAMES that this build
    does not write but an earlier build in out_dir did."""
    for f in DECK_NAMES:
        if f not in decks and os.path.exists(os.path.join(out_dir, f)):
            os.remove(os.path.join(out_dir, f))
    for f, txt in decks.items():
        open(os.path.join(out_dir, f), "w").write(txt)
    return sorted(decks)
