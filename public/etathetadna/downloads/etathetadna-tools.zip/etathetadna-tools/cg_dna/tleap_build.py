"""Write the tleap input for the v18 model and run it (with salt).

Two modes, matching the two CLI entry points:

  - protein=False (build_dna.py): loads SIRAH's WT4 water box and ions
    file by file, as the DNA-only systems of the v18 benchmark campaign.
  - protein=True (build_dna_protein.py): `source leaprc.sirah` instead,
    which brings SIRAH's protein force field plus the same water/ions, as
    the protein-DNA systems of the campaign (1kx5, 7x7q).

In both modes the ηθDNA overlay (dna_vf.lib, repeat.lib, cationes_g4.lib
and the frcmod stack of paths.FRCMOD_FILES) is loaded on top, in the same
order.

Salt follows the SIRAH rule used in the campaign: a first tleap pass
solvates and neutralizes, its WT4 count W0 gives n = a*W0/(1+2a) ion pairs
with a = C/(0.15*34), and the second pass adds them.
"""
import os
import re
import subprocess

from . import model, paths

_WATER_IONS_BLOCK = """\
loadoff {sirah_dir}/wt4box.off
loadoff {sirah_dir}/solv.lib
loadoff {sirah_dir}/ions.lib
loadamberparams {sirah_dir}/solv.frcmod
loadamberparams {sirah_dir}/ions.frcmod
"""

_SIRAH_SOURCE_BLOCK = """\
addPath {sirah_dir}
source {sirah_dir}/leaprc.sirah
"""

_TLEAP_TEMPLATE = """\
{water_or_protein_block}\
loadoff {dna_vf_lib}
loadoff {repeat_lib}
loadoff {cations_lib}
{frcmod_lines}\
m = loadpdb {cg_pdb}
{bond_lines}\
solvateoct m WT4BOX 20 0.7
{addions_lines}\
saveamberparm m {prmtop} {inpcrd}
quit
"""


def salt_pairs(w0, conc):
    """Ion pairs for `conc` M with the SIRAH rule, given W0 WT4 beads."""
    if conc <= 0:
        return 0
    a = conc / (0.15 * 34)
    return int(a * w0 / (1 + 2 * a) + 0.5)


def build_tleap_script(cg_pdb, prmtop, inpcrd, sirah_dir, protein=False, bonds=(), cation="NaW", n_pairs=0):
    """bonds: tleap atom specs to join, e.g. [("m.182.C4G", "m.1.PA")] to close
    a circular strand. cation: NaW or KW (salt and neutralization)."""
    frcmod_lines = "".join(f"loadamberparams {p}\n" for p in paths.frcmod_paths())
    block = (_SIRAH_SOURCE_BLOCK if protein else _WATER_IONS_BLOCK).format(sirah_dir=sirah_dir)
    addions = f"addionsrand m {cation} 0\n"
    if protein:
        addions += "addionsrand m ClW 0\n"   # the protein may leave the system positive
    if n_pairs:
        addions += f"addionsrand m {cation} {n_pairs} ClW {n_pairs}\n"
    return _TLEAP_TEMPLATE.format(
        water_or_protein_block=block,
        dna_vf_lib=paths.DNA_VF_LIB,
        repeat_lib=paths.REPEAT_LIB,
        cations_lib=paths.CATIONS_G4_LIB,
        frcmod_lines=frcmod_lines,
        cg_pdb=os.path.abspath(cg_pdb),
        bond_lines="".join(f"bond {a} {b}\n" for a, b in bonds),
        addions_lines=addions,
        prmtop=os.path.abspath(prmtop),
        inpcrd=os.path.abspath(inpcrd),
    )


def _run(text, tleap_in, tleap_bin):
    with open(tleap_in, "w") as fh:
        fh.write(text)
    r = subprocess.run([tleap_bin, "-f", os.path.basename(tleap_in)], cwd=os.path.dirname(tleap_in),
                       capture_output=True, text=True, errors="replace")
    out = r.stdout + r.stderr
    open(tleap_in[:-3] + ".log", "w").write(out)
    if r.returncode != 0 or "Errors = 0" not in out:
        tail = "\n".join(out.splitlines()[-40:])
        raise RuntimeError(f"tleap failed ({tleap_in}, exit code {r.returncode}). Last lines:\n{tail}")
    return out


def run_tleap(cg_pdb, out_prefix, sirah_dir, protein=False, bonds=(), cation="NaW", salt=model.DEFAULT_SALT_M,
              tleap_bin="tleap", verbose=True):
    """Solvate, neutralize and add salt. Returns (dry_prmtop, inpcrd, info);
    "dry" = before the CMAP, not unsolvated."""
    out_prefix = os.path.abspath(out_prefix)
    os.makedirs(os.path.dirname(out_prefix), exist_ok=True)
    dry, crd = f"{out_prefix}_dry.prmtop", f"{out_prefix}.inpcrd"
    info = dict(cation=cation, salt_M=salt)
    if salt > 0:
        text = build_tleap_script(cg_pdb, f"{out_prefix}_nosalt.prmtop", f"{out_prefix}_nosalt.inpcrd", sirah_dir,
                                  protein, bonds, cation, 0)
        out = _run(text, f"{out_prefix}_tleap0.in", tleap_bin)
        w0 = int(re.findall(r"^\s*WT4\s+(\d+)", out, re.M)[-1])
        info.update(W0=w0, ion_pairs=salt_pairs(w0, salt))
        for f in (f"{out_prefix}_nosalt.prmtop", f"{out_prefix}_nosalt.inpcrd"):
            os.remove(f)
    else:
        info.update(ion_pairs=0)
    text = build_tleap_script(cg_pdb, dry, crd, sirah_dir, protein, bonds, cation, info["ion_pairs"])
    _run(text, f"{out_prefix}_tleap.in", tleap_bin)
    if verbose:
        msg = f"{salt} M: WT4 after neutralizing {info['W0']}, {info['ion_pairs']} {cation}/ClW pairs" if salt > 0 \
            else "neutralized only (no salt)"
        print(f"tleap OK ({msg}): {dry}")
    return dry, crd, info
