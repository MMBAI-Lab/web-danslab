"""All-atom PDB -> coarse-grained (CG) DNA PDB converter.

Maps standard atomistic DNA residues (DA/DC/DG/DT) onto the eta-theta CG
DNA representation: each nucleotide keeps a handful of backbone/base atoms,
renamed to this model's bead-naming convention, and residues are re-typed
depending on their position in the chain:

  - internal residue           -> DAX / DCX / DGX / DTX
  - 5' terminus of a strand    -> AX5 / CX5 / GX5 / TX5  (phosphate dropped)
  - 3' terminus of a strand    -> AX3 / CX3 / GX3 / TX3
  - 2nd, 4th, ... residue of   -> DA1 / DC1 / DG1 / DT1  ("repeat" variant,
    a run of 2+ identical                                 see compute_repeat_flags)
    consecutive INTERNAL bases

Vendored from the main eta-theta-DNA repo's scripts/gral/convert_to_cg_dna.py
(same logic, comments translated to English for this standalone package).
Pure standard library, no third-party dependencies.
"""
from collections import defaultdict

# Atom names to keep from the all-atom structure, per base.
CG_ATOMS = {
    'DG': ['P', "C4'", 'N9', 'N1', 'N2', 'N3', 'O6', 'N7'],
    'DA': ['P', "C4'", 'N6', 'N1', 'N7', 'N3', 'N9'],
    'DT': ['P', "C4'", 'N1', 'O2', 'N3', 'O4', 'C7'],
    'DC': ['P', "C4'", 'N1', 'O2', 'N3', 'N4', 'C5'],
}

# Output residue name per (base, chain position).
RES_CG_MAP = {
    'DG': 'DGX', 'DA': 'DAX', 'DT': 'DTX', 'DC': 'DCX',
    'DG_5': 'GX5', 'DA_5': 'AX5', 'DT_5': 'TX5', 'DC_5': 'CX5',
    'DG_3': 'GX3', 'DA_3': 'AX3', 'DT_3': 'TX3', 'DC_3': 'CX3',
    # "Repeat" variants use different atom types (Pg/Kg, Pa/Ka, Pc/Kc, Pt/Kt
    # instead of PG/KG, PA/KA, PC/KC, PT/KT), defined in params/repeat.lib.
    # They exist to break an eta/theta degeneracy: when two consecutive
    # INTERNAL residues are the same base, eta(i)=C4X-PX-C4X-PX and
    # theta(i)=PX-C4X-PX-C4X are built from the exact same atom-type
    # sequence (or its reverse) on both sides, so AMBER's dihedral-type
    # lookup can't tell the two terms apart. There is no '_5'/'_3' repeat
    # variant, so chain termini are never re-typed this way.
    'DG_rep': 'DG1', 'DA_rep': 'DA1', 'DT_rep': 'DT1', 'DC_rep': 'DC1',
}

# All-atom -> CG bead name, per base.
ATOM_NAME_MAP = {
    'DG': {"C4'": 'C4G', 'N9': 'N9G', 'N1': 'N1G', 'N2': 'N2G', 'N3': 'N3G', 'O6': 'O6G', 'N7': 'N7G', 'P': 'PG'},
    'DA': {"C4'": 'C4A', 'N6': 'N6A', 'N1': 'N1A', 'N7': 'N7A', 'N3': 'N3A', 'N9': 'N9A', 'P': 'PA'},
    'DT': {"C4'": 'C4T', 'N1': 'N1T', 'O2': 'O2T', 'N3': 'N3T', 'O4': 'O4T', 'C7': 'C7T', 'P': 'PT'},
    'DC': {"C4'": 'C4C', 'N1': 'N1C', 'O2': 'O2C', 'N3': 'N3C', 'N4': 'N4C', 'C5': 'C5C', 'P': 'PC'},
}


def load_pdb(filepath):
    """Parse ATOM records from a PDB file by fixed column offsets.

    'segment' increments on every TER line -- needed because some PDBs
    separate duplex strands with a bare TER and no distinct chain letter;
    without this, two strands sharing chain='' would merge into one
    continuous chain and the second strand would lose its 5'/3' capping
    (it would end up typed as an internal/repeat residue instead of
    terminal).
    """
    atoms = []
    segment = 0
    with open(filepath) as f:
        for line in f:
            if line.startswith("ATOM"):
                atoms.append({
                    'name': line[12:16].strip(),
                    'resname': line[17:20].strip(),
                    'chain': line[21].strip(),
                    'resid': int(line[22:26]),
                    'segment': segment,
                    'x': float(line[30:38]),
                    'y': float(line[38:46]),
                    'z': float(line[46:54]),
                })
            elif line.startswith("TER"):
                segment += 1
    return atoms


def group_by_residue(atoms):
    grouped = defaultdict(list)
    for atom in atoms:
        key = (atom['resname'], atom['resid'], atom['chain'], atom['segment'])
        grouped[key].append(atom)
    return grouped


def determine_residue_position(res_keys, i):
    if i == 0:
        return '_5'
    if i == len(res_keys) - 1:
        return '_3'
    return ''


def compute_repeat_flags(same_chain_keys):
    """One bool per residue in the chain: True if it must use the '_rep'
    variant (DG1/DC1/DA1/DT1) instead of the canonical name, because it is
    the 2nd, 4th, ... member of a run of 2+ identical consecutive INTERNAL
    bases.

    Within each run, canonical/rep alternate starting with canonical
    (X, rep, X, rep, ...). Terminal residues (5'/3', first or last of the
    chain) are never flagged -- there is no '_rep' template for termini --
    and they don't consume an alternation slot (the count restarts at the
    first internal residue of the run).
    """
    n = len(same_chain_keys)
    flags = [False] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and same_chain_keys[j + 1][0] == same_chain_keys[i][0]:
            j += 1
        parity = 0
        for idx in range(i, j + 1):
            is_terminal = (idx == 0) or (idx == n - 1)
            if is_terminal:
                continue
            if parity % 2 == 1:
                flags[idx] = True
            parity += 1
        i = j + 1
    return flags


def convert_to_cg(atoms):
    """Convert a flat list of all-atom records (from load_pdb) into a list
    of CG-DNA PDB lines (no trailing newline, no END record)."""
    grouped = group_by_residue(atoms)
    res_keys = sorted(grouped.keys(), key=lambda x: (x[2], x[3], x[1]))

    cg_lines = []
    atom_serial = 1

    segments = sorted(set((k[2], k[3]) for k in res_keys))
    for chain, segment in segments:
        # Keep only residues that will actually produce output atoms: a
        # recognized DNA resname AND at least one deposited atom that's in
        # its keep-list. A residue that's nominally DNA but has none of its
        # kept atoms resolved (e.g. a disordered 5'/3' end with only a
        # single dangling O3' modeled) would otherwise consume the i==0/
        # i==len-1 index slot without emitting anything -- silently
        # shifting 5'/3' status onto its neighbor, whose phosphate then
        # doesn't get dropped. That residue is still the *first* one
        # actually written to the CG PDB for this chain, so SIRAH's own
        # addPdbResMap (build_dna_protein.py's tleap path only) retypes it
        # to a X5/X3 cap on its own independent chain-boundary detection --
        # but the leftover phosphate atom has no place in that cap's
        # template -> "Atom ... does not have a type" fatal error in tleap.
        same_chain_keys = [
            rk for rk in res_keys
            if rk[2] == chain and rk[3] == segment and rk[0] in CG_ATOMS
            and any(a['name'] in CG_ATOMS[rk[0]] for a in grouped[rk])
        ]
        if not same_chain_keys:
            continue
        repeat_flags = compute_repeat_flags(same_chain_keys)
        chain_last_resid = None
        chain_last_resname = None
        for i, (resname, resid, _, _) in enumerate(same_chain_keys):
            pos_suffix = determine_residue_position(same_chain_keys, i)
            base_atoms = grouped[(resname, resid, chain, segment)]
            keep_atoms = CG_ATOMS[resname]

            if pos_suffix:
                cg_resname = RES_CG_MAP[f"{resname}{pos_suffix}"]
            elif repeat_flags[i]:
                cg_resname = RES_CG_MAP[f"{resname}_rep"]
            else:
                cg_resname = RES_CG_MAP[resname]

            for atom in base_atoms:
                if pos_suffix == '_5' and atom['name'] == 'P':
                    continue  # no phosphate at the free 5' end
                if atom['name'] in keep_atoms:
                    new_name = ATOM_NAME_MAP[resname].get(atom['name'], atom['name'])
                    cg_lines.append(
                        f"ATOM  {atom_serial:5d} {new_name:<4} {cg_resname:>3} {chain}{resid:4d}    "
                        f"{atom['x']:8.3f}{atom['y']:8.3f}{atom['z']:8.3f}  1.00  0.00           "
                    )
                    atom_serial += 1

            chain_last_resid = resid
            chain_last_resname = cg_resname

        cg_lines.append(f"TER   {atom_serial:5d}      {chain_last_resname:>3} {chain}{chain_last_resid:4d}")
        atom_serial += 1

    return cg_lines


def write_pdb(lines, output_path):
    with open(output_path, 'w') as f:
        for line in lines:
            f.write(line + '\n')
        f.write('END\n')


REPEAT_RESNAMES = {'DA1', 'DC1', 'DG1', 'DT1'}


def uses_repeat_variant(cg_pdb_path):
    """True if this CG PDB contains at least one '_rep' residue (DA1/DC1/
    DG1/DT1) -- i.e. this particular sequence has a run of 2+ identical
    consecutive internal bases. Most systems don't; used to decide whether
    params/repeat.lib is worth copying alongside a build's output (see
    build_dna.py/build_dna_protein.py) -- no point bundling a residue
    library the build never actually used."""
    with open(cg_pdb_path) as f:
        for line in f:
            if line.startswith("ATOM") and line[17:20].strip() in REPEAT_RESNAMES:
                return True
    return False


def convert(input_pdb, output_pdb):
    """Convert an all-atom PDB to a CG-DNA PDB. Any non-DNA chain (protein,
    water, ions, ...) is silently dropped -- see convert_protein.py for the
    DNA+protein pipeline."""
    atoms = load_pdb(input_pdb)
    cg_lines = convert_to_cg(atoms)
    write_pdb(cg_lines, output_pdb)
    return output_pdb


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python convert_dna.py input.pdb output_cg.pdb")
        sys.exit(1)
    convert(sys.argv[1], sys.argv[2])
