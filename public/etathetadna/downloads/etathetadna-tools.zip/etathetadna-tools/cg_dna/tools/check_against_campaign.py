#!/usr/bin/env python3
"""Dev-only regression: rebuild the systems of the ηθDNA v18 benchmark
campaign with this package and compare them, term by term, with the
topologies that were simulated.

    python -m cg_dna.tools.check_against_campaign <benchmark dir> <work dir> --sirah-dir DIR [systems ...]

<benchmark dir> is the main repo's data/benchmark (it holds
<sys>/v18final/rep1/<sys>.prmtop + .inpcrd). For each system the solute
(DNA, protein, channel cations) is written to a CG PDB straight from the
campaign prmtop/inpcrd (same coordinates, so the same Z typing input),
with TER between residues that are not bonded and --ring-bond for bonds
between non-consecutive residues (circular strands). The build uses the
campaign salt (3 M for the Z systems and 116d_3M, KCl when the campaign
used KW) and is compared on the solute:

  atoms (name, type, charge, mass), bonds, angles, dihedrals (incl.
  impropers, 1-4 flags and scaling), CMAP terms and grids, the LJ table
  over every pair of atom types, the DISANG restraints (by bead), and the
  ion/water counts.
"""
import argparse
import os
import re
import sys
from collections import Counter

import numpy as np
import parmed as pmd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from cg_dna import build, model  # noqa: E402

SYSTEMS = ["1bna", "116d_015M", "116d_3M", "1jve", "1nqs", "1m6g", "8y0f", "4ocb", "3qba", "3qba_015M", "3qba_x3",
           "3qba_x3_nodis", "181d_x3", "3wbo_x3", "2f8w_x3", "7ll0_k", "7ll0_k_KCl", "1jpq", "1jpq_KCl", "352d", "6zte",
           "mini-mini", "1kx5", "7x7q"]
SALT_3M = {"116d_3M", "4ocb", "3qba", "3qba_x3", "3qba_x3_nodis", "181d_x3", "3wbo_x3", "2f8w_x3"}
NO_RESTRAINT = {"3qba_x3_nodis"}            # campaign variant run without the DISANG
PROTEIN = {"1kx5", "7x7q"}
SOLVENT = ("WT4", "NaW", "ClW", "KW")
r6 = lambda x: round(float(x), 6)


def solute_pdb(prm, crd, out):
    """Write the solute of the campaign system as a PDB; return (n residues,
    ring bonds as tleap specs)."""
    p = pmd.load_file(prm, crd)
    X = np.asarray(p.coordinates)
    names = [r.name for r in p.residues]
    n = next(i for i, x in enumerate(names) if x in SOLVENT)
    bonded = set()
    ring = []
    for b in p.bonds:
        i, j = sorted((b.atom1.residue.idx, b.atom2.residue.idx))
        if i == j or j >= n:
            continue
        bonded.add((i, j))
        if j - i > 1:
            a1, a2 = (b.atom1, b.atom2) if b.atom1.residue.idx == j else (b.atom2, b.atom1)
            ring.append((f"m.{j + 1}.{a1.name}", f"m.{i + 1}.{a2.name}"))
    L, k = [], 0
    for i in range(n):
        r = p.residues[i]
        for a in r.atoms:
            k += 1
            x = X[a.idx]
            L.append(f"ATOM  {k:5d} {a.name:<4s} {r.name:>3s}  {i + 1:4d}    {x[0]:8.3f}{x[1]:8.3f}{x[2]:8.3f}  1.00  0.00")
        if (i, i + 1) not in bonded:
            L.append("TER")
    open(out, "w").write("\n".join(L) + "\nEND\n")
    return n, ring


def terms(p, nat):
    sel = range(nat)
    canon = lambda t: min(t, t[::-1])
    B = Counter((*canon((b.atom1.idx, b.atom2.idx)), r6(b.type.k), r6(b.type.req)) for b in p.bonds if b.atom1.idx < nat)
    A = Counter((*canon((a.atom1.idx, a.atom2.idx, a.atom3.idx)), r6(a.type.k), r6(a.type.theteq))
                for a in p.angles if a.atom1.idx < nat)
    D = Counter((*((d.atom1.idx, d.atom2.idx, d.atom3.idx, d.atom4.idx) if d.improper else
                   canon((d.atom1.idx, d.atom2.idx, d.atom3.idx, d.atom4.idx))),
                 d.improper, d.ignore_end, r6(d.type.phi_k), r6(d.type.per), r6(d.type.phase),
                 r6(d.type.scee), r6(d.type.scnb)) for d in p.dihedrals if d.atom1.idx < nat)
    C = Counter((c.atom1.idx, c.atom2.idx, c.atom3.idx, c.atom4.idx, c.atom5.idx,
                 tuple(round(c.type.grid[i, j], 4) for i in range(24) for j in range(24))) for c in p.cmaps
                if c.atom1.idx < nat)
    At = [(a.name, a.type, r6(a.charge), r6(a.mass)) for a in p.atoms[:nat]] if sel else []
    return dict(atoms=At, bonds=B, angles=A, dihedrals=D, cmaps=C)


def lj_table(prm):
    d = pmd.amber.AmberFormat(prm).parm_data
    ntypes = d["POINTERS"][1]
    tname = {}
    for t, i in zip(d["AMBER_ATOM_TYPE"], d["ATOM_TYPE_INDEX"]):
        tname.setdefault(i, t)
    out = {}
    for i in range(1, ntypes + 1):
        for j in range(i, ntypes + 1):
            k = d["NONBONDED_PARM_INDEX"][ntypes * (i - 1) + j - 1]
            if k > 0:
                out[tuple(sorted((tname[i], tname[j])))] = (d["LENNARD_JONES_ACOEF"][k - 1], d["LENNARD_JONES_BCOEF"][k - 1])
    return out


def disang_beads(f, p):
    if not os.path.exists(f):
        return Counter()
    pairs = re.findall(r"iat\s*=\s*(\d+)\s*,\s*(\d+)", open(f).read())
    lab = lambda i: (p.atoms[i - 1].residue.idx, p.atoms[i - 1].name)
    return Counter(frozenset((lab(int(a)), lab(int(b)))) for a, b in pairs)


def compare(s, bench, work, sirah):
    ref_dir = os.path.join(bench, s, "v18final", "rep1")
    rprm, rcrd = os.path.join(ref_dir, f"{s}.prmtop"), os.path.join(ref_dir, f"{s}.inpcrd")
    wd = os.path.join(work, s)
    os.makedirs(os.path.join(wd, "build"), exist_ok=True)
    pdb = os.path.join(wd, "build", "campaign_solute.pdb")
    nres, ring = solute_pdb(rprm, rcrd, pdb)
    ref = pmd.load_file(rprm)
    cation = "KW" if any(r.name == "KW" for r in ref.residues) else "NaW"
    salt = 3.0 if s in SALT_3M else 0.15
    prm, crd, summ = build.build_system(pdb, os.path.join(wd, s), sirah, protein=s in PROTEIN, bonds=ring, cation=cation,
                                       salt=salt, end_restraint=s not in NO_RESTRAINT, verbose=False)
    new = pmd.load_file(prm)
    nat = sum(len(r.atoms) for r in ref.residues[:nres])
    assert nat == sum(len(r.atoms) for r in new.residues[:nres])
    tr, tn = terms(ref, nat), terms(new, nat)
    out = []
    for k in tr:
        if tr[k] != tn[k]:
            if isinstance(tr[k], Counter):
                out.append(f"{k}: {sum((tr[k] - tn[k]).values())} only in the campaign, {sum((tn[k] - tr[k]).values())} only here")
            else:
                bad = [i for i, (a, b) in enumerate(zip(tr[k], tn[k])) if a != b]
                out.append(f"{k}: {len(bad)} differ, first {tr[k][bad[0]]} vs {tn[k][bad[0]]}")
    lr, ln = lj_table(rprm), lj_table(prm)
    com = set(lr) & set(ln)
    bad = [k for k in com if not np.allclose(lr[k], ln[k], rtol=1e-6, atol=1e-8)]
    if bad:
        out.append(f"LJ: {len(bad)} type pairs differ, e.g. {sorted(bad)[:4]}")
    miss = sorted({t for k in set(lr) ^ set(ln) for t in k})
    if miss:
        out.append(f"LJ: types only in one table {miss[:8]}")
    dr = disang_beads(os.path.join(ref_dir, "disang.rst"), ref)
    dn = disang_beads(os.path.join(wd, "disang.rst"), new)
    if dr != dn:
        out.append(f"DISANG: campaign {sum(dr.values())} restraints, here {sum(dn.values())}, common {sum((dr & dn).values())}")
    cr = Counter(r.name for r in ref.residues if r.name in SOLVENT + model.CHANNEL_IONS)
    cn = Counter(r.name for r in new.residues if r.name in SOLVENT + model.CHANNEL_IONS)
    ions = "same ions/water" if cr == cn else f"ions/water campaign {dict(cr)} vs here {dict(cn)}"
    t = summ["topology"]
    info = (f"{nres} solute residues, {nat} beads; CMAP {summ['cmap']['eta_theta']}+{summ['cmap']['phi_chi']}; "
            f"Z G {len(t['z_G'])}, Z C {len(t['z_C'])}; 3pB {t['3pB'][0]}; ring bonds {len(ring)}; {ions}")
    return out, info


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bench")
    ap.add_argument("work")
    ap.add_argument("--sirah-dir", required=True)
    ap.add_argument("systems", nargs="*", default=SYSTEMS)
    a = ap.parse_args()
    nbad = 0
    for s in a.systems:
        try:
            diffs, info = compare(s, a.bench, a.work, a.sirah_dir)
        except Exception as e:   # report and go on with the next system
            diffs, info = [f"ERROR {type(e).__name__}: {e}"], ""
        nbad += bool(diffs)
        print(f"{'OK  ' if not diffs else 'DIFF'} {s}: {info}", flush=True)
        for d in diffs:
            print(f"       {d}", flush=True)
    print(f"\n{len(a.systems) - nbad}/{len(a.systems)} systems identical to the campaign on the solute")
    sys.exit(1 if nbad else 0)


if __name__ == "__main__":
    main()
