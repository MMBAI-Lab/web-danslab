"""Shared build chain of build_dna.py and build_dna_protein.py (v18 model).

  CG PDB [+ G4 channel cations] -> tleap (WT4, neutralize, salt)
  -> CMAP eta/theta + phi/chi -> junction angles k 20 -> kn5 + C4' improper
  -> Z typing -> 3pB -> checks -> DISANG + decks + run_md.sh

Outputs in the directory of the output prefix (one system per directory:
the deck names are fixed): <name>.prmtop, <name>.inpcrd, the decks,
disang.rst (if the system has restrainable WC ends), run_md.sh and
build_summary.json; intermediates in build/. A disang.rst or deck left by
an earlier build in the same directory and not written by this one is
removed (run_md.sh picks its stages by which decks exist).
"""
import json
import os
import shutil

import parmed as pmd

from . import cmap, decks, disang, g4, model, paths, tleap_build, topology

SALT_RESIDUES = ("WT4", "NaW", "ClW", "KW")


def solute_mask(prmtop):
    """':1-N' covering everything tleap did not add (DNA, protein, channel
    cations); checks that the solute comes first and is contiguous."""
    p = pmd.load_file(prmtop)
    names = [r.name for r in p.residues]
    n = next(i for i, x in enumerate(names) if x in SALT_RESIDUES)
    stray = [f"{x}{i + 1}" for i, x in enumerate(names[n:], n) if x not in SALT_RESIDUES]
    if stray:
        raise RuntimeError(f"solute residues after the solvent: {stray[:5]}")
    charge = sum(a.charge for a in p.atoms)
    if abs(charge) > 1e-3:
        raise RuntimeError(f"net charge {charge:.4f} after neutralizing")
    counts = {x: names.count(x) for x in SALT_RESIDUES + model.CHANNEL_IONS if x in names}
    return f":1-{n}", n, counts


def build_system(cg_pdb, out_prefix, sirah_dir, protein=False, source_pdb=None, bonds=(), cation="NaW",
                 salt=model.DEFAULT_SALT_M, ztype=True, g4_ion="KW4", g4_site="between", g4_tips=False,
                 g4_place=True, end_restraint=True, write_decks=True, tleap_bin="tleap", verbose=True):
    out_prefix = os.path.abspath(out_prefix)
    out_dir, name = os.path.dirname(out_prefix), os.path.basename(out_prefix)
    bdir = os.path.join(out_dir, "build")
    os.makedirs(bdir, exist_ok=True)
    summary = dict(model="ηθDNA 1.0 (v18: v18T29 + 3pB + KW4/NW4)", name=name, input=os.path.abspath(cg_pdb))

    # G4 channel cations
    work_pdb = os.path.join(bdir, f"{name}_cg.pdb")
    if os.path.abspath(cg_pdb) != work_pdb:
        shutil.copyfile(cg_pdb, work_pdb)
    if g4.has_channel_types(work_pdb):
        summary["g4"] = "channel cations already in the CG PDB (KW4/NW4)"
    else:
        src = open(source_pdb).readlines() if source_pdb else []
        ions, report = g4.channel_cations(open(work_pdb).readlines(), src, g4_ion, g4_site, g4_tips)
        if report:
            for l in report:
                print(l) if verbose else None
            if not g4_place:
                raise SystemExit("G-quadruplex tetrads found but channel cation placement is disabled "
                                 "(--no-g4-cations): a G4 must not be simulated with an empty channel.")
            g4.append_ions(work_pdb, ions)
            summary["g4"] = report + [f"{r} {lab}" for r, _, lab in ions]

    # tleap
    tprefix = os.path.join(bdir, name)
    dry, crd, info = tleap_build.run_tleap(work_pdb, tprefix, sirah_dir, protein, bonds, cation, salt, tleap_bin, verbose)
    summary["tleap"] = info

    # CMAPs and the post-tleap chain
    cmap_prm = os.path.join(bdir, f"{name}_cmap.prmtop")
    summary["cmap"] = cmap.inject(dry, cmap_prm, verbose)
    prmtop = f"{out_prefix}.prmtop"
    summary["topology"] = topology.finalize(cmap_prm, crd, prmtop, ztype, verbose)
    inpcrd = f"{out_prefix}.inpcrd"
    shutil.copyfile(crd, inpcrd)

    mask, n_solute, counts = solute_mask(prmtop)
    summary.update(restraintmask=mask, residues=counts)

    # DISANG, decks, runner. A disang.rst from an earlier build in this
    # directory goes first: disang.write() writes none when there are no
    # restrainable ends.
    rst = os.path.join(out_dir, "disang.rst")
    if os.path.exists(rst):
        os.remove(rst)
    n_rst = 0
    if end_restraint:
        n_rst, n_pairs, n_ends = disang.write(prmtop, inpcrd, rst, name)
        summary["disang"] = dict(restraints=n_rst, terminal_pairs=n_pairs, terminal_nucleotides=n_ends)
        if verbose:
            print(f"DISANG: {n_rst} WC restraints on {n_pairs} terminal pairs ({n_ends} terminal nucleotides)"
                  + ("" if n_rst else " -> production without end restraint"))
    if write_decks:
        d = decks.protein_decks(name, mask, n_rst > 0) if protein else decks.dna_decks(name, mask, n_rst > 0, salt >= 1.0)
        summary["decks"] = decks.write(d, out_dir)
        run = os.path.join(out_dir, "run_md.sh")
        shutil.copyfile(paths.RUN_SCRIPT, run)
        os.chmod(run, 0o775)
    json.dump(summary, open(os.path.join(out_dir, "build_summary.json"), "w"), indent=1, default=str)
    if verbose:
        print(f"\nDone: {prmtop}\n      {inpcrd}\n      restraintmask {mask} ({n_solute} solute residues); {counts}")
        if write_decks:
            print(f"      decks {' '.join(summary['decks'])}; run with: bash {run} {name}")
    return prmtop, inpcrd, summary
