"""Inject the two per-base CMAP corrections of the v18 model into a CG-DNA prmtop.

  eta/theta: C4'(i-1)-P(i)-C4'(i)-P(i+1)-C4'(i+1), for every nucleotide with
             a bonded previous AND next nucleotide (linear strand of N -> N-2
             terms, closed ring -> N);
  phi/chi:   C4'(i-1)-P(i)-C4'(i)-N(i)-B(i), for every nucleotide with a
             bonded previous nucleotide; B = the base bead of chi
             (D3 for A, J3 for G, S2 for C, M2 for T).

Neighbours are found through bonds, not residue numbers, so circular
strands (with an explicit ring-closure bond) work. Beads are recognized by
the first letter of their type (P, K, N), which also covers the "repeat"
residues DA1/DC1/DG1/DT1 (types Pa/Ka, Pc/Kc, ...).

Every proper torsion on a central P-K bond (replaced by the eta/theta CMAP)
or K-N bond (chi and its cousins, replaced by the phi/chi CMAP) is set to 0,
whatever the frcmod loading order left there.

Ported from the main repo's data/backbone_fitting/kai_v18/inject_cmap_v18.py.

CmapTypes are created only for (family, base) pairs that receive at least
one term: ParmEd prunes unreferenced CmapTypes on save, and the CMAP_INDEX
patch below has to match the types that survive.
"""
import numpy as np
import parmed as pmd
from parmed.topologyobjects import Cmap, CmapType

from . import model, paths

BASE_ORDER = "ACGT"


def load_grid(path):
    values = []
    for line in open(path):
        fields = line.split()
        if not fields or fields[0].startswith("#"):
            continue
        values.append(float(fields[2]))
    if len(values) != 576:
        raise ValueError(f"{path}: {len(values)} values (expected 576, a 24x24 grid)")
    return values


def base_of(residue):
    for c in residue.name:
        if c in "ACGT":
            return c
    return None


def _t(atom):
    return atom.type[0].upper() if atom.type else ""


def is_nucleotide(residue):
    """Has a C4' bead (type K/k). Keeps WT4 water (whose name contains a 'T')
    and SIRAH protein residues out."""
    return any(_t(a) == "K" for a in residue.atoms)


def c4_bead(residue):
    return next((a for a in residue.atoms if _t(a) == "K"), None)


def p_bead(residue):
    return next((a for a in residue.atoms if _t(a) == "P"), None)


def zero_torsions(parm):
    """Set to 0 every proper torsion whose central bond is P-K or K-N.
    Returns (n_pk, n_kn)."""
    n_pk = n_kn = 0
    for d in parm.dihedrals:
        if d.improper or d.type.phi_k == 0:
            continue
        central = {_t(d.atom2), _t(d.atom3)}
        if central == {"P", "K"}:
            d.type.phi_k = 0.0
            n_pk += 1
        elif central == {"K", "N"}:
            d.type.phi_k = 0.0
            n_kn += 1
    return n_pk, n_kn


def find_terms(parm):
    """[(family, base, (5 atoms))] in insertion order; family = 'et' or 'chi'."""
    pending = []
    for res in parm.residues:
        if not is_nucleotide(res):
            continue
        p_i, c4, b = p_bead(res), c4_bead(res), base_of(res)
        if p_i is None or c4 is None or b is None:
            continue
        prev = [a for a in p_i.bond_partners if _t(a) == "K" and a.residue is not res]
        if not prev:
            continue
        pn = [a for a in c4.bond_partners if _t(a) == "P" and a is not p_i]
        if pn and c4_bead(pn[0].residue) is not None:
            pending.append(("et", b, (prev[0], p_i, c4, pn[0], c4_bead(pn[0].residue))))
        nn = [a for a in c4.bond_partners if _t(a) == "N" and a.residue is res]
        bb = [a for a in nn[0].bond_partners if a.type == model.CHI_BEAD_TYPE[b]] if nn else []
        if nn and bb:
            pending.append(("chi", b, (prev[0], p_i, c4, nn[0], bb[0])))
    return pending


def expected_counts(parm):
    """(n eta/theta, n chi) terms the topology should get, from bonds alone."""
    n_et = n_chi = 0
    for res in parm.residues:
        c4, p_i = c4_bead(res), p_bead(res)
        if c4 is None:
            continue
        has_prev = p_i is not None and any(_t(x) == "K" and x.residue is not res for x in p_i.bond_partners)
        has_next = any(_t(x) == "P" and x.residue is not res for x in c4.bond_partners)
        n_chi += has_prev
        n_et += has_prev and has_next
    return n_et, n_chi


def inject(prmtop_in, prmtop_out, verbose=True):
    """Add both CMAPs to prmtop_in and write prmtop_out. Returns a dict with
    the counts. The output is reloaded and every term checked against the
    grid and the bead types it should have."""
    parm = pmd.load_file(prmtop_in)
    n_pk, n_kn = zero_torsions(parm)

    pending = find_terms(parm)
    used = {(fam, b) for fam, b, _ in pending}
    types, grids = {}, {}
    for fam in ("et", "chi"):
        for b in BASE_ORDER:
            if (fam, b) not in used:
                continue
            path = paths.etatheta_grid_path(b) if fam == "et" else paths.chi_grid_path(b)
            grids[(fam, b)] = load_grid(path)
            types[(fam, b)] = CmapType(model.CMAP_RESOLUTION, grids[(fam, b)])
            parm.cmap_types.append(types[(fam, b)])
    map_index = {k: i + 1 for i, k in enumerate(types)}

    term_keys = []
    for fam, b, atoms in pending:
        parm.cmaps.append(Cmap(*atoms, type=types[(fam, b)]))
        term_keys.append((fam, b))

    parm.cmap_types.index_members()
    parm.cmaps.index_members()
    # ParmEd does not create the CMAP flags of a prmtop that had none.
    parm.add_flag("CMAP_COUNT", "2I8", data=[len(parm.cmaps), len(parm.cmap_types)])
    parm.add_flag("CMAP_RESOLUTION", "20I4", data=[ct.resolution for ct in parm.cmap_types])
    parm.add_flag("CMAP_INDEX", "6I8", data=[0] * (6 * len(parm.cmaps)))
    parm.save(prmtop_out, overwrite=True)
    _patch_cmap_index(prmtop_out, term_keys, map_index)

    chk = pmd.load_file(prmtop_out)
    if len(chk.cmaps) != len(term_keys):
        raise RuntimeError(f"CMAP reload: {len(chk.cmaps)} terms, expected {len(term_keys)}")
    bad = 0
    for cm, (fam, b) in zip(chk.cmaps, term_keys):
        if not np.allclose(np.array(cm.type.grid), np.array(grids[(fam, b)]), atol=1e-4):
            bad += 1
        want = ["K", "P", "K", "P", "K"] if fam == "et" else ["K", "P", "K", "N", model.CHI_BEAD_TYPE[b][0]]
        if [_t(a) for a in (cm.atom1, cm.atom2, cm.atom3, cm.atom4, cm.atom5)] != want:
            bad += 1
    if bad:
        raise RuntimeError(f"CMAP reload: {bad} terms with the wrong grid or beads")

    n_et = sum(f == "et" for f, _ in term_keys)
    n_chi = len(term_keys) - n_et
    if (n_et, n_chi) != expected_counts(parm):
        raise RuntimeError(f"CMAP terms eta/theta {n_et}, chi {n_chi}; expected {expected_counts(parm)}")
    if verbose:
        print(f"CMAP: torsions zeroed P-K {n_pk}, K-N {n_kn}; terms eta/theta {n_et}, phi/chi {n_chi}; "
              f"types {list(types)}")
    return dict(zeroed_pk=n_pk, zeroed_kn=n_kn, eta_theta=n_et, phi_chi=n_chi)


def _patch_cmap_index(prmtop_out, term_keys, map_index):
    """ParmEd writes 0 in the map-index column of CMAP_INDEX when CMAP terms
    are added from scratch: rewrite it with the index of each term's type."""
    lines = open(prmtop_out).read().splitlines()
    out, i = [], 0
    while i < len(lines):
        out.append(lines[i])
        if lines[i].startswith("%FLAG CMAP_INDEX"):
            out.append(lines[i + 1])
            i += 2
            for k in term_keys:
                fields = lines[i].split()
                fields[5] = str(map_index[k])
                out.append("".join(f"{int(x):8d}" for x in fields))
                i += 1
            continue
        i += 1
    open(prmtop_out, "w").write("\n".join(out) + "\n")
