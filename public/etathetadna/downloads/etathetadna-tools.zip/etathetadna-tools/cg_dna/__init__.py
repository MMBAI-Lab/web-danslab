"""cg_dna: build AMBER-ready coarse-grained DNA (and DNA+protein) systems
for the ηθDNA 1.0 force field (v18 in the development history) from an all-atom PDB.

See build_dna.py and build_dna_protein.py at the repo root for the two
command-line entry points; the functions in this package are also meant
to be imported directly.
"""
