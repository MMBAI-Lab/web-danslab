"""Watson-Crick distance restraints on the terminal base pairs (DISANG file).

Every terminal nucleotide (no bonded previous or no bonded next nucleotide)
is paired with its WC partner: the nucleotide whose WC H-bond beads are all
closer than 3.6 A in the input structure. Each H-bond of the pair gets a
flat-bottom restraint: harmonic at 3.0 A (rk 5), linear outside 2-5 A.
G-C has 3 (N1G-N3C, N2G-O2C, O6G-N4C), A-T has 2 (N1A-N3T, N6A-O4T).

Ported from the main repo's benchmark/campana_v18_final/build_final.py
(disang_ends), validated there against the hand-written restraint files
of 1nqs, 1bna and 1jve. Ends without a WC partner (G-quadruplex tetrads,
single-stranded tails) get no restraint; circular strands have no ends.
"""
import numpy as np
import parmed as pmd

from . import model as M

HBONDS = {("G", "C"): [("N1G", "N3C"), ("N2G", "O2C"), ("O6G", "N4C")],
          ("A", "T"): [("N1A", "N3T"), ("N6A", "O4T")]}
CUTOFF = 3.6


def _base(r):
    return next(ch for ch in r.name if ch in "ACGT")


def terminal_pairs(p, X):
    """[(residue i, residue j, [(bead i, bead j), ...])], i < j."""
    dna = sorted(r.idx for r in p.residues if any(a.name in M.KNAMES for a in r.atoms))

    def bonded_out(r, from_names, to_names):
        return any(x.name in to_names and x.residue is not r
                   for a in r.atoms if a.name in from_names for x in a.bond_partners)

    ends = [p.residues[i] for i in dna
            if not bonded_out(p.residues[i], M.PNAMES, M.KNAMES) or not bonded_out(p.residues[i], M.KNAMES, M.PNAMES)]
    pairs = {}
    for ri in ends:
        best = None
        for j in dna:
            rj = p.residues[j]
            if rj is ri:
                continue
            key = (_base(ri), _base(rj)) if (_base(ri), _base(rj)) in HBONDS else (_base(rj), _base(ri))
            if key not in HBONDS:
                continue
            nm_i = {a.name: a.idx for a in ri.atoms}
            nm_j = {a.name: a.idx for a in rj.atoms}
            hb = [(x, y) if key == (_base(ri), _base(rj)) else (y, x) for x, y in HBONDS[key]]
            if not all(x in nm_i and y in nm_j for x, y in hb):
                continue
            dmax = max(np.linalg.norm(X[nm_i[x]] - X[nm_j[y]]) for x, y in hb)
            if dmax < CUTOFF and (best is None or dmax < best[0]):
                best = (dmax, rj)
        if best:
            pairs[tuple(sorted((ri.idx, best[1].idx)))] = True
    out = []
    for i, j in sorted(pairs):
        ri, rj = p.residues[i], p.residues[j]
        key = (_base(ri), _base(rj)) if (_base(ri), _base(rj)) in HBONDS else (_base(rj), _base(ri))
        out.append((i, j, [(x, y) if key == (_base(ri), _base(rj)) else (y, x) for x, y in HBONDS[key]]))
    return out, len(ends)


def write(prmtop, inpcrd, out, title):
    """Write the DISANG file; returns the number of restraints (0 = no file)."""
    p = pmd.load_file(prmtop, inpcrd)
    X = np.asarray(p.coordinates)
    pairs, n_ends = terminal_pairs(p, X)
    L = [f"WC distance restraints on the terminal base pairs ({title}): every H-bond",
         "of each terminal pair (3 for G-C, 2 for A-T). Written by cg_dna/disang.py."]
    n = 0
    for i, j, hb in pairs:
        ri, rj = p.residues[i], p.residues[j]
        L.append(f"# Pair {ri.name}(res{i + 1}) - {rj.name}(res{j + 1}): {len(hb)} WC H-bonds")
        for x, y in hb:
            a = next(t for t in ri.atoms if t.name == x)
            b = next(t for t in rj.atoms if t.name == y)
            L += [f"#   {x}(idx{a.idx + 1})-{y}(idx{b.idx + 1}): {np.linalg.norm(X[a.idx] - X[b.idx]):.2f}A", " &rst",
                  f"  iat={a.idx + 1},{b.idx + 1},", "  r1=2.0, r2=3.0, r3=3.0, r4=5.0,", "  rk2=5.0, rk3=5.0,", " &end"]
            n += 1
    if n:
        open(out, "w").write("\n".join(L) + "\n")
    return n, len(pairs), n_ends
