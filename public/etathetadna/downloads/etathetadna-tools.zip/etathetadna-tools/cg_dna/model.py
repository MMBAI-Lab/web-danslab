"""Constants of ηθDNA 1.0, the final model (developed as v18 = v18T29 + 3pB + KW4/NW4).

Everything here is a frozen copy of a value used to build the 24-system
benchmark campaign of the main repo (data/benchmark/campana_v18_final,
2026-11-15). The regression script cg_dna/tools/check_against_campaign.py
rebuilds those systems with this package and compares every bonded term
with the campaign topologies.

Steps applied after tleap, in this order (cg_dna/topology.py):

  1. CMAP eta/theta (per base) + CMAP phi/chi (per base); every proper
     torsion on a central P-K or K-N bond set to 0 (cg_dna/cmap.py).
  2. Junction angles K-N-base, N-K-P and K-P-K: same theta0, k = 20.
  3. kn5 (guanine only): P-K-N / N-K-P(i+1) theta0 89.0 / 86.8, k 10;
     C4'-N9-N3 / C4'-N9-N7 k 5 (theta0 unchanged).
  4. C4' chirality improper P(i)-N-K-P(i+1): k 4, per 1, phase 60.
  5. Z typing from the input geometry (G with syn base AND Z backbone, and
     the C next to them): theta0 of their junction angles set to the Z
     values below, and their CMAP eta/theta swapped for the GZ / CZ grid.
  6. 3pB: base(i)-N(i)-K(i)-P(i+1) torsions, skipping Z-typed nucleotides.
"""

# --- bead names ---------------------------------------------------------------
KNAMES = ("C4A", "C4C", "C4G", "C4T")          # C4' beads
PNAMES = ("PA", "PC", "PG", "PT")              # phosphate beads
NNAMES = ("N9A", "N9G", "N1C", "N1T")          # glycosidic N beads
BEADS = {"G": ("PG", "C4G", "N9G"), "C": ("PC", "C4C", "N1C"),
         "A": ("PA", "C4A", "N9A"), "T": ("PT", "C4T", "N1T")}
# base bead used by the chi CMAP (P-K-N-B) and the other base bead bonded to N
CHI_BEAD_TYPE = {"A": "D3", "G": "J3", "C": "S2", "T": "M2"}
CHI_BEAD_NAMES = ("N3A", "N3G", "O2C", "O2T")
OTHER_BEAD_NAMES = ("N7A", "N7G", "C5C", "C7T")

# Residues that are never DNA (solvent, salt, channel cations).
ENV_RESIDUES = ("WT4", "NaW", "ClW", "KW", "KW4", "NW4")
CHANNEL_IONS = ("KW4", "NW4")

# --- step 1: CMAP grids (params/cmap/) -----------------------------------------
# etatheta_<B>.dat: gap05 target - joint WHAM base, us_v18k20 (2026-10-22).
# etatheta_GZ.dat:  same, with basin Ia flattened (Z-typed G only).
# etatheta_CZ.dat:  same, with basin IV flattened (Z-typed C only).
# chi_<B>.dat:      conditional PDB target U(chi|phi) - umbrella base, A10_k20.
CMAP_RESOLUTION = 24

# --- step 2: junction angles ----------------------------------------------------
JUNCTION_K = 20.0

# --- step 3: kn5 (guanine) ------------------------------------------------------
KN5_PKN_THETA0 = 89.0      # P(i)-K-N
KN5_NKP_THETA0 = 86.8      # N-K-P(i+1)
KN5_PKN_K = 10.0
KN5_KNB_K = 5.0            # C4'-N9-N3 / C4'-N9-N7

# --- step 4: C4' chirality improper ---------------------------------------------
IMP_K, IMP_PER, IMP_PHASE = 4.0, 1, 60.0

# --- step 5: Z typing ----------------------------------------------------------
# theta0 per angle class (mean over the fully-Z nucleotides of the CG crystals
# 4ocb, 3wbo_x3 and 181d_x3; build_T27.zvalues()). Class names: "<base> <class>",
# angles owned by nucleotide i; "+" = bead of residue i+1.
Z_THETA0 = {
    "G K-P-K CpG": 69.63446855432757,
    "G P-K-N": 110.56778664183835,
    "G N-K-P+": 113.15599073044895,
    "G P-K-P+": 116.86170911487312,
    "G K-N9G-N3G": 73.05447085755893,
    "G K-N9G-N7G": 158.91537560168484,
    "C K-P-K GpC": 127.8266152265893,
    "C P-K-N": 95.37292893969196,
    "C N-K-P+": 116.41682587338606,
    "C P-K-P+": 105.51777221313068,
    "C K-N1C-C5C": 122.90290802716468,
    "C K-N1C-O2C": 116.77414992503199,
}
Z_CLASSES = {"G": ("K-P-K CpG", "P-K-N", "N-K-P+", "P-K-P+", "K-N9G-N3G", "K-N9G-N7G"),
             "C": ("K-P-K GpC", "P-K-N", "N-K-P+", "P-K-P+", "K-N1C-C5C", "K-N1C-O2C")}
SYN_CLASSES = ("P-K-N", "K-N9G-N3G", "K-N9G-N7G")          # syn base orientation (G)
ZBB_CLASSES = ("N-K-P+", "K-P-K CpG")                      # Z backbone (G)
ZBB_SET = ("N-K-P+", "P-K-P+", "K-P-K CpG")                # retyped too when the backbone is Z
Z_MARGIN = 10.0   # degrees: mean(|angle - theta0| - |angle - Z value|) needed to type

# eta/theta basins of JCIM 2024 (Tables 2-3), degrees on 0-360:
# (name, eta_min, eta_max, theta_min, theta_max). A syn G is typed Z backbone
# if its input eta/theta is in Ia; in another catalogued basin, it is not;
# undefined (chain ends) or uncatalogued -> the angle margin decides.
BASINS = [
    ("0", 141, 198, 162, 260), ("Ia", 105, 155, 230, 290),
    ("Ib", 167, 218, 283, 333), ("Ic", 144, 192, 223, 271),
    ("II", 262, 324, 216, 275), ("III", 227, 283, 183, 243),
    ("IV", 54, 142, 87, 146), ("Va", 154, 231, 100, 188),
    ("Vb", 146, 197, 33, 95), ("Vc", 121, 168, 145, 190),
    ("VI", 235, 287, 140, 188),
]

# --- step 6: 3pB ---------------------------------------------------------------
# base(i)-N(i)-K(i)-P(i+1), ignore_end (no 1-4), scee 1.2, scnb 2.0
TPB = {"chi": (10.0, 2, -16.0),     # base bead = the chi bead (N3A, N3G, O2C, O2T)
       "other": (10.0, 2, -100.0)}  # the other base bead bonded to N (N7A, N7G, C5C, C7T)

# --- salt (SIRAH rule) ---------------------------------------------------------
# n ion pairs = a*W0/(1+2a), a = C/(0.15*34), W0 = WT4 beads after neutralizing.
DEFAULT_SALT_M = 0.15
