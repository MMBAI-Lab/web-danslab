"""G-quadruplex channel cations (KW4 = K+, NW4 = Na+).

No G4 is simulated with an empty channel: without cations the tetrads open
during the minimization. SIRAH's KW/NaW are hydrated-size ions that do not
fit between tetrads, so the channel gets its own ion types KW4/NW4
(params/cationes_g4.lib + frcmod/cationes_g4.frcmod): bare-ion radii
towards the guanine O6/N1 and thymine O2/N3 beads and towards each other,
SIRAH KW/NaW towards everything else.

Rules (cg_dna.g4.add_channel_cations):
  - tetrads = 4 G joined by Hoogsteen pairs (N1(i)-O6(j) and N2(i)-N7(j)
    < 3.4 A); stacks = tetrads with centres < 4.5 A apart;
  - if the input structure has cations in the channel (crystal K+/Na+,
    within 1.5 A of the channel axis, up to 3 A beyond the outer tetrads),
    each becomes a KW4 (K+) or NW4 (Na+) at the same position, and nothing
    else is added;
  - otherwise one cation per site: 'between' (default; K+ site, one per
    gap between stacked tetrads, at the midpoint of the O6 centres) or
    'plane' (Na+ site, centre of each tetrad's O6; NW4 only), plus the
    optional 'tips' sites outside the outer tetrads.

Ported from the main repo's scripts/gral/place_g4_cations.py (validated on
1JPQ: the 5 sites fall 0.05-0.25 A from the crystal K+).
"""
import numpy as np

G_RES = {"DG", "G", "DGX", "DG1", "GX5", "GX3", "DG5", "DG3"}
HOOG_NAMES = ("O6", "N1", "N2", "N7")
K_NAMES = {"K", "K+", "KW", "KW4"}
NA_NAMES = {"NA", "NA+", "NAW", "NW4"}
TIP_OFFSET = {"KW4": 1.7, "NW4": 1.5}


def _xyz(line):
    return np.array([float(line[30:38]), float(line[38:46]), float(line[46:54])])


def read_guanines(pdb_lines):
    """{(chain, resid): {O6, N1, N2, N7: xyz}} for guanines with all four
    beads/atoms (works on CG and atomistic PDBs)."""
    G = {}
    for l in pdb_lines:
        if not l.startswith(("ATOM", "HETATM")):
            continue
        name, res = l[12:16].strip(), l[17:20].strip()
        n = name[:-1] if len(name) == 3 and name.endswith("G") else name   # CG: O6G -> O6
        if res in G_RES and n in HOOG_NAMES:
            G.setdefault((l[21], l[22:27]), {})[n] = _xyz(l)
    return {k: v for k, v in G.items() if len(v) == 4}


def read_cations(pdb_lines):
    """[(element 'K'/'NA', xyz)] of K+/Na+ records (ATOM or HETATM)."""
    out = []
    for l in pdb_lines:
        if not l.startswith(("ATOM", "HETATM")):
            continue
        name, res = l[12:16].strip().upper(), l[17:20].strip().upper()
        if res in K_NAMES or name in K_NAMES:
            out.append(("K", _xyz(l)))
        elif res in NA_NAMES or name in NA_NAMES:
            out.append(("NA", _xyz(l)))
    return out


def tetrads(G):
    keys = list(G)
    adj = {i: {j for j in keys if j != i and np.linalg.norm(G[i]["N1"] - G[j]["O6"]) < 3.4
               and np.linalg.norm(G[i]["N2"] - G[j]["N7"]) < 3.4} for i in keys}
    comp, seen = [], set()
    for k in keys:
        if k in seen or not adj[k]:
            continue
        stack, c = [k], set()
        while stack:
            x = stack.pop()
            if x not in c:
                c.add(x)
                stack += list(adj[x])
        seen |= c
        comp.append(sorted(c))
    out = []
    for c in comp:
        if len(c) != 4:
            continue
        O = np.array([G[k]["O6"] for k in c])
        cen = O.mean(0)
        out.append(dict(res=c, cen=cen, n=np.linalg.svd(O - cen)[2][2]))
    return out


def stacks(T):
    """[(tetrads sorted along the axis, unit axis)]"""
    grp, seen = [], set()
    for i in range(len(T)):
        if i in seen:
            continue
        st, c = [i], set()
        while st:
            x = st.pop()
            if x in c:
                continue
            c.add(x)
            st += [j for j in range(len(T)) if j not in c and np.linalg.norm(T[j]["cen"] - T[x]["cen"]) < 4.5]
        seen |= c
        S = [T[j] for j in c]
        n0 = S[0]["n"]
        ax = np.mean([t["n"] if t["n"] @ n0 > 0 else -t["n"] for t in S], 0)
        ax /= np.linalg.norm(ax)
        o = np.mean([t["cen"] for t in S], 0)
        S.sort(key=lambda t: (t["cen"] - o) @ ax)
        grp.append((S, ax))
    return grp


def _in_channel(x, S, ax, radial=1.5, beyond=3.0):
    z0, z1 = (S[0]["cen"] - S[0]["cen"]) @ ax, (S[-1]["cen"] - S[0]["cen"]) @ ax
    v = x - S[0]["cen"]
    z = v @ ax
    r = np.linalg.norm(v - z * ax)
    return r < radial and z0 - beyond <= z <= z1 + beyond


def channel_cations(cg_lines, source_lines=(), ion="KW4", site="between", tips=False):
    """Decide the channel cations. cg_lines: the CG PDB; source_lines: the
    input (atomistic) PDB, where crystal cations are looked for. Returns
    (list of (resname, xyz, label), report lines); empty if no tetrads."""
    T = tetrads(read_guanines(cg_lines))
    if not T:
        return [], []
    report, out = [], []
    crystal = read_cations(list(cg_lines) + list(source_lines))
    for k, (S, ax) in enumerate(stacks(T)):
        z = [(t["cen"] - S[0]["cen"]) @ ax for t in S]
        report.append(f"G4 stack {k + 1}: {len(S)} tetrads, spacings {np.round(np.diff(z), 2).tolist()} A")
        found, seen = [], []
        for el, x in crystal:
            if _in_channel(x, S, ax) and not any(np.linalg.norm(x - y) < 0.5 for y in seen):
                seen.append(x)
                found.append(("KW4" if el == "K" else "NW4", x, f"input {el}+ ion"))
        if found:
            report.append(f"  {len(found)} channel cations from the input structure: "
                          + ", ".join(r for r, _, _ in found))
            out += found
            continue
        if site == "between":
            sites = [((S[i]["cen"] + S[i + 1]["cen"]) / 2, f"between tetrads {i + 1} and {i + 2}") for i in range(len(S) - 1)]
        else:
            sites = [(t["cen"], f"plane of tetrad {i + 1}") for i, t in enumerate(S)]
        if tips:
            sites += [(S[0]["cen"] - TIP_OFFSET[ion] * ax, "tip (outside tetrad 1)"),
                      (S[-1]["cen"] + TIP_OFFSET[ion] * ax, f"tip (outside tetrad {len(S)})")]
        report.append(f"  no cations in the input channel: {len(sites)} {ion} placed ({site}{' + tips' if tips else ''})")
        out += [(ion, x, lab) for x, lab in sites]
    return out, report


def has_channel_types(cg_pdb):
    """True if the CG PDB already carries KW4/NW4 residues."""
    return any(l.startswith(("ATOM", "HETATM")) and l[17:20].strip() in ("KW4", "NW4") for l in open(cg_pdb))


def append_ions(cg_pdb, ions):
    """Append the channel cations to the CG PDB (one residue each, TER after
    each one), before END. Any other K+/Na+ record (e.g. atomistic crystal
    ions kept in a hand-made CG PDB) is removed: the channel ones are
    re-added as KW4/NW4 and the bulk ones come back as salt."""
    def is_other_cation(l):
        if not l.startswith(("ATOM", "HETATM")):
            return False
        name, res = l[12:16].strip().upper(), l[17:20].strip().upper()
        return (res in K_NAMES | NA_NAMES or name in K_NAMES | NA_NAMES) and res not in ("KW4", "NW4")
    lines = [l for l in open(cg_pdb) if not l.startswith("END") and not is_other_cation(l)]
    atoms = [l for l in lines if l.startswith(("ATOM", "HETATM"))]
    resid = max(int(l[22:26]) for l in atoms)
    n = len(atoms)
    while lines and lines[-1].strip() == "TER":
        lines.pop()
    if lines and not lines[-1].startswith("TER"):
        lines.append("TER\n")
    for k, (name, x, _) in enumerate(ions, 1):
        lines.append(f"ATOM  {n + k:5d} {name:<4s} {name:>3s}  {resid + k:4d}    {x[0]:8.3f}{x[1]:8.3f}{x[2]:8.3f}  1.00  0.00\nTER\n")
    lines.append("END\n")
    open(cg_pdb, "w").writelines(lines)
