"""All-atom PDB (DNA+protein complex) -> combined SIRAH-protein / eta-theta-DNA CG PDB.

The DNA leg reuses convert_dna.py unchanged (this project's own CG-DNA
mapping). The protein leg is NOT reimplemented here -- SIRAH already ships
a mature, validated atomistic-to-CG protein mapping, and it is orchestrated
as two external tools instead:

  1. pdb2pqr (--ff AMBER --titration-state-method propka) assigns
     protonation states (HID/HIE/HIP/GLH/ASH, ...) at the given pH.
  2. SIRAH's own Perl tool, tools/CGCONV/cgconv.pl, maps the protonated
     atomistic protein onto SIRAH CG beads using its bundled sirah_prot.map.

This matches how this project's own DNA+protein benchmark systems (1kx5,
7x7q) were historically built. Requires `pdb2pqr` on PATH (pip install
pdb2pqr) and a local SIRAH installation (see paths.resolve_sirah_dir).
"""
import os
import subprocess

from . import convert_dna

# Standard 20 amino acids (3-letter codes) plus the protonation-state
# variants pdb2pqr's AMBER forcefield output can produce.
PROTEIN_RESNAMES = {
    'ALA', 'ARG', 'ASN', 'ASP', 'CYS', 'GLN', 'GLU', 'GLY', 'HIS', 'ILE',
    'LEU', 'LYS', 'MET', 'PHE', 'PRO', 'SER', 'THR', 'TRP', 'TYR', 'VAL',
    'HID', 'HIE', 'HIP', 'GLH', 'ASH', 'CYX', 'CYM', 'LYN',
}

DNA_RESNAMES = set(convert_dna.CG_ATOMS.keys())  # DA, DC, DG, DT


def split_chains(input_pdb, dna_out, protein_out):
    """Write two all-atom PDBs from one input: DNA-only residues (any
    DA/DC/DG/DT) and protein-only residues (any standard/protonation-
    variant amino acid). Anything else (water, ions, ligands) is dropped
    from both -- neither leg of this pipeline handles them."""
    dna_lines, protein_lines = [], []
    with open(input_pdb) as fh:
        for line in fh:
            if line.startswith(("ATOM", "TER")):
                resname = line[17:20].strip()
                if resname in DNA_RESNAMES:
                    dna_lines.append(line)
                elif resname in PROTEIN_RESNAMES:
                    protein_lines.append(line)

    with open(dna_out, "w") as fh:
        fh.writelines(dna_lines)
        fh.write("END\n")
    with open(protein_out, "w") as fh:
        fh.writelines(protein_lines)
        fh.write("END\n")

    n_dna = sum(1 for l in dna_lines if l.startswith("ATOM"))
    n_prot = sum(1 for l in protein_lines if l.startswith("ATOM"))
    if n_dna == 0:
        raise ValueError(f"No DNA residues found in {input_pdb}")
    if n_prot == 0:
        raise ValueError(f"No protein residues found in {input_pdb}")
    return n_dna, n_prot


def protonate_with_pdb2pqr(protein_pdb, out_pdb, ph=7.0, pdb2pqr_bin="pdb2pqr"):
    """Assign protonation states with PROPKA via pdb2pqr, AMBER-style
    residue/atom naming (HID/HIE/HIP/...). Writes a protonated PDB to
    out_pdb (the .pqr file itself is discarded, only used as pdb2pqr's
    mandatory second positional output)."""
    pqr_scratch = out_pdb + ".pqr"
    result = subprocess.run(
        [
            pdb2pqr_bin,
            "--ff", "AMBER",
            "--titration-state-method", "propka",
            "--with-ph", str(ph),
            "--pdb-output", out_pdb,
            protein_pdb,
            pqr_scratch,
        ],
        capture_output=True, text=True, errors="replace",
    )
    if result.returncode != 0 or not os.path.isfile(out_pdb):
        raise RuntimeError(f"pdb2pqr failed (exit code {result.returncode}):\n{result.stdout}\n{result.stderr}")
    return out_pdb


def convert_protein_to_sirah(protonated_pdb, out_cg_pdb, sirah_dir):
    """Run SIRAH's cgconv.pl with its default sirah_*.map files (the input
    here only contains protein residues, so only sirah_prot.map actually
    matches anything)."""
    cgconv = os.path.join(sirah_dir, "tools", "CGCONV", "cgconv.pl")
    if not os.path.isfile(cgconv):
        raise SystemExit(f"cgconv.pl not found at {cgconv} -- check --sirah-dir")
    result = subprocess.run(
        ["perl", cgconv, "-i", protonated_pdb, "-o", out_cg_pdb],
        capture_output=True, text=True, errors="replace",
    )
    if result.returncode != 0 or not os.path.isfile(out_cg_pdb):
        raise RuntimeError(f"cgconv.pl failed (exit code {result.returncode}):\n{result.stdout}\n{result.stderr}")
    return out_cg_pdb


def merge_cg_pdbs(protein_cg_pdb, dna_cg_pdb, out_pdb):
    """Concatenate two CG PDBs (protein first, then DNA -- matching the
    real 1kx5_all_CG.pdb/7x7q_CG_all.pdb benchmark templates) into one,
    renumbering atom serials sequentially and preserving each file's own
    TER records."""
    def atom_and_ter_lines(path):
        return [l for l in open(path) if l.startswith(("ATOM", "TER"))]

    out_lines = []
    serial = 1
    for path in (protein_cg_pdb, dna_cg_pdb):
        for line in atom_and_ter_lines(path):
            if line.startswith("ATOM"):
                line = f"{line[:6]}{serial:>5d}{line[11:]}"
                serial += 1
            out_lines.append(line.rstrip("\n"))

    with open(out_pdb, "w") as fh:
        fh.write("\n".join(out_lines) + "\nEND\n")
    return out_pdb


def convert(input_pdb, out_prefix, sirah_dir, ph=7.0, pdb2pqr_bin="pdb2pqr", verbose=True):
    """Full DNA+protein leg: split -> convert DNA -> protonate+convert
    protein -> merge. Returns the path to the combined CG PDB."""
    dna_aa = f"{out_prefix}_dna_aa.pdb"
    protein_aa = f"{out_prefix}_protein_aa.pdb"
    n_dna, n_prot = split_chains(input_pdb, dna_aa, protein_aa)
    if verbose:
        print(f"split: {n_dna} DNA atoms -> {dna_aa}, {n_prot} protein atoms -> {protein_aa}")

    dna_cg = f"{out_prefix}_dna_cg.pdb"
    convert_dna.convert(dna_aa, dna_cg)
    if verbose:
        print(f"DNA leg converted: {dna_cg}")

    protein_protonated = f"{out_prefix}_protein_protonated.pdb"
    protonate_with_pdb2pqr(protein_aa, protein_protonated, ph=ph, pdb2pqr_bin=pdb2pqr_bin)
    if verbose:
        print(f"protein protonated (pH {ph}): {protein_protonated}")

    protein_cg = f"{out_prefix}_protein_cg.pdb"
    convert_protein_to_sirah(protein_protonated, protein_cg, sirah_dir)
    if verbose:
        print(f"protein leg converted (SIRAH cgconv.pl): {protein_cg}")

    combined_cg = f"{out_prefix}_cg.pdb"
    merge_cg_pdbs(protein_cg, dna_cg, combined_cg)
    if verbose:
        print(f"merged CG PDB: {combined_cg}")

    return combined_cg
