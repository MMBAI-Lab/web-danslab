#!/usr/bin/env python3
"""Build an AMBER-ready ηθDNA 1.0 + SIRAH-protein CG system from one
all-atom PDB of a DNA-protein complex.

    python build_dna_protein.py input.pdb -o outdir/name --sirah-dir /path/to/sirah

Pipeline: split the input into DNA and protein -> DNA via cg_dna.convert_dna
(this model's mapping) -> protein via pdb2pqr (protonation) + SIRAH's
cgconv.pl -> merged CG PDB -> tleap (`source leaprc.sirah` + this model's
DNA parameters on top; neutralize with NaW and ClW, NaCl 0.15 M by
default) -> the v18 topology chain (DNA residues only; SIRAH's protein
force field is untouched) -> WC end restraint on the DNA + the SIRAH
multi-stage decks (em1, em2, eq1, eq2, md, md2) + run_md.sh.

Requirements beyond build_dna.py's: `pdb2pqr` on PATH (pip install pdb2pqr)
and `perl` on PATH (to run SIRAH's bundled cgconv.pl).
"""
import argparse
import os
import shutil
import sys

from build_dna import add_common_args, common_kwargs
from cg_dna import build as chain, convert_dna, convert_protein, paths


def build(input_pdb, out_prefix, sirah_dir, cg_input=False, ph=7.0, pdb2pqr_bin="pdb2pqr", **kw):
    paths.check_bundled_params()
    sirah_dir = paths.resolve_sirah_dir(sirah_dir)
    out_dir = os.path.dirname(os.path.abspath(out_prefix))
    bdir = os.path.join(out_dir, "build")
    os.makedirs(bdir, exist_ok=True)
    if cg_input:
        cg_pdb, source = input_pdb, None
    else:
        cg_pdb = convert_protein.convert(input_pdb, os.path.join(bdir, os.path.basename(out_prefix)), sirah_dir,
                                         ph=ph, pdb2pqr_bin=pdb2pqr_bin)
        source = input_pdb
    prmtop, inpcrd, summary = chain.build_system(cg_pdb, out_prefix, sirah_dir, protein=True, source_pdb=source, **kw)
    if convert_dna.uses_repeat_variant(cg_pdb):
        shutil.copyfile(paths.REPEAT_LIB, os.path.join(out_dir, "repeat.lib"))
    return prmtop, inpcrd, summary


def make_parser():
    """The command-line options (also rendered in the web app's Command line tab)."""
    ap = argparse.ArgumentParser(prog="build_dna_protein.py", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input_pdb", help="all-atom PDB containing both DNA and protein chains")
    ap.add_argument("--cg-input", action="store_true",
                    help="input_pdb is already a combined CG PDB (SIRAH protein + ηθDNA beads)")
    ap.add_argument("--ph", type=float, default=7.0, help="pH for the PROPKA protonation states (default 7.0)")
    ap.add_argument("--pdb2pqr-bin", default="pdb2pqr", help="pdb2pqr executable (default: pdb2pqr)")
    add_common_args(ap)
    return ap


def main():
    args = make_parser().parse_args()
    if not os.path.isfile(args.input_pdb):
        sys.exit(f"Input PDB not found: {args.input_pdb}")
    build(args.input_pdb, args.out, args.sirah_dir, cg_input=args.cg_input, ph=args.ph, pdb2pqr_bin=args.pdb2pqr_bin,
        **common_kwargs(args))


if __name__ == "__main__":
    main()
