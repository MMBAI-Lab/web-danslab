#!/usr/bin/env python3
"""Build an AMBER-ready ηθDNA 1.0 CG system from an all-atom, DNA-only PDB.

    python build_dna.py input.pdb -o outdir/name --sirah-dir /path/to/sirah

Pipeline: all-atom PDB -> CG PDB (cg_dna.convert_dna: repeated-base
retyping, 5'/3' caps) -> G-quadruplex channel cations if the structure has
tetrads (cg_dna.g4) -> tleap (SIRAH WT4 water, neutralization, NaCl 0.15 M
by default) -> the v18 topology chain (cg_dna.cmap, cg_dna.topology) ->
WC end restraint (DISANG) + AMBER decks + run_md.sh.

One system per output directory: outdir/ receives name.prmtop,
name.inpcrd, the decks (em/eq/md/md2_WT4.in, plus dens_WT4.in at high
salt), disang.rst, run_md.sh and build_summary.json; intermediates go to
outdir/build/. Then:  bash outdir/run_md.sh name

Requirements: tleap on PATH (AmberTools), the parmed and numpy Python
packages, and a local SIRAH installation (http://www.sirahff.com; not
bundled, point --sirah-dir or $SIRAH_HOME at it).
"""
import argparse
import os
import shutil
import sys

from cg_dna import build as chain, convert_dna, model, paths


def parse_bond(spec):
    """'182.C4G:1.PA' -> ('m.182.C4G', 'm.1.PA')"""
    a, b = spec.split(":")
    return f"m.{a}", f"m.{b}"


def add_common_args(ap):
    ap.add_argument("-o", "--out", required=True, metavar="PREFIX",
                    help="output prefix, e.g. out/1bna/1bna (one system per directory)")
    ap.add_argument("--sirah-dir", default=None, help="path to a local SIRAH install (or set $SIRAH_HOME)")
    ap.add_argument("--salt", type=float, default=model.DEFAULT_SALT_M, metavar="M",
                    help="salt concentration on top of neutralization, SIRAH rule (default 0.15; 0 = neutralize only; "
                         "the Z-DNA benchmark used 3.0)")
    ap.add_argument("--cation", default="NaW", choices=["NaW", "KW"],
                    help="bulk cation for neutralization and salt: NaW (NaCl, default) or KW (KCl)")
    ap.add_argument("--no-ztype", action="store_true",
                    help="do not apply the Z typing (Z-DNA G/C detected in the input keep the B parameters)")
    ap.add_argument("--g4-cation", default="KW4", choices=["KW4", "NW4"],
                    help="G4 channel cation placed when the input has none in the channel (default KW4 = K+)")
    ap.add_argument("--g4-site", default="between", choices=["between", "plane"],
                    help="G4 cation sites: between tetrads (K+, default) or in the tetrad planes (Na+, use with NW4)")
    ap.add_argument("--g4-tips", action="store_true", help="also place a cation outside each outer tetrad")
    ap.add_argument("--no-g4-cations", action="store_true",
                    help="stop instead of placing channel cations when tetrads are found")
    ap.add_argument("--ring-bond", action="append", default=[], metavar="RES.ATOM:RES.ATOM",
                    help="extra bond for tleap, e.g. 182.C4G:1.PA to close a circular strand (repeat per strand)")
    ap.add_argument("--no-end-restraint", action="store_true", help="no WC distance restraint on the terminal pairs")
    ap.add_argument("--no-decks", action="store_true", help="only the topology and coordinates, no decks or run_md.sh")
    ap.add_argument("--tleap-bin", default="tleap", help="tleap executable (default: tleap)")


def common_kwargs(args):
    return dict(bonds=[parse_bond(s) for s in args.ring_bond], cation=args.cation, salt=args.salt,
                ztype=not args.no_ztype, g4_ion=args.g4_cation, g4_site=args.g4_site, g4_tips=args.g4_tips,
                g4_place=not args.no_g4_cations, end_restraint=not args.no_end_restraint,
                write_decks=not args.no_decks, tleap_bin=args.tleap_bin)


def build(input_pdb, out_prefix, sirah_dir, cg_input=False, **kw):
    paths.check_bundled_params()
    sirah_dir = paths.resolve_sirah_dir(sirah_dir)
    out_dir = os.path.dirname(os.path.abspath(out_prefix))
    os.makedirs(os.path.join(out_dir, "build"), exist_ok=True)
    if cg_input:
        cg_pdb, source = input_pdb, None
    else:
        cg_pdb = os.path.join(out_dir, "build", f"{os.path.basename(out_prefix)}_cg.pdb")
        convert_dna.convert(input_pdb, cg_pdb)
        source = input_pdb
    prmtop, inpcrd, summary = chain.build_system(cg_pdb, out_prefix, sirah_dir, protein=False, source_pdb=source, **kw)
    if convert_dna.uses_repeat_variant(cg_pdb):
        shutil.copyfile(paths.REPEAT_LIB, os.path.join(out_dir, "repeat.lib"))
    return prmtop, inpcrd, summary


def make_parser():
    """The command-line options (also rendered in the web app's Command line tab)."""
    ap = argparse.ArgumentParser(prog="build_dna.py", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input_pdb", help="all-atom PDB, DNA only (protein chains are skipped -- see build_dna_protein.py)")
    ap.add_argument("--cg-input", action="store_true",
                    help="input_pdb is already a CG PDB (ηθDNA bead names, e.g. from convert_dna.py)")
    add_common_args(ap)
    return ap


def main():
    args = make_parser().parse_args()
    if not os.path.isfile(args.input_pdb):
        sys.exit(f"Input PDB not found: {args.input_pdb}")
    build(args.input_pdb, args.out, args.sirah_dir, cg_input=args.cg_input, **common_kwargs(args))


if __name__ == "__main__":
    main()
