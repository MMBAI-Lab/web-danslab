#!/usr/bin/env python3
"""Recover an all-atom trajectory from a finished ηθDNA CG MD run (model
1.0 or the v17 development model; DNA-only or DNA+protein/SIRAH) -- the
reverse of build_dna.py / build_dna_protein.py.

    python backmap_dna.py cg.prmtop traj_dir -o out/system --n-frames 50
    python backmap_dna.py cg.prmtop --traj md.nc md2.nc -o out/x --n-frames 20

Pipeline, per selected frame: extract the CG frame (cpptraj) ->
geometrically reconstruct heavy atoms (NeRF, cg_backmap.reconstruct) ->
add hydrogens + a short vacuum minimization (tleap + sander, same protocol
SIRAH's own backmapping tool uses). Frames are then combined into one
multi-frame AMBER NetCDF trajectory + shared prmtop.

Each nucleotide's sugar and backbone come from the conformer template
(B, A, syn or Z; params/backmap_dna.json) that best fits its CG beads,
picked per nucleotide and per frame; --no-conformers builds them all
with the B template.

Water and bulk-ion CG beads are dropped (never geometrically backmapped,
matching SIRAH's own documented behavior). G4 channel cations (KW4/NW4)
are kept, as K+/Na+ at the bead position. The output is solute plus
channel cations by default; pass --resolvate to re-solvate the
(topologically identical) frame-0 structure with real explicit water
afterward.

No SIRAH installation needed at runtime (unlike the forward pipeline):
SIRAH's own protein/water NeRF recipe was extracted once and is bundled
in this repo -- only AmberTools (tleap/sander/cpptraj) + parmed + numpy
are required.

Known limitation: protein protonation state (HID/HIE/HIP/etc., set by the
forward pipeline's pdb2pqr step) is not recoverable from SIRAH's CG
protein beads -- SIRAH's own CG mapping is protonation-state-agnostic.
tleap assigns its own default protonation state during hydrogenation.
"""
import argparse
import os
import shutil
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor

import parmed as pmd

from cg_backmap import assemble, frame_select, hydrogenate, paths, recipe, reconstruct, resolvate


def _backmap_one_frame(args):
    (gidx, rst7_path, cg_prmtop, recipes_paths, scratch_dir, allow_unmapped, conformers,
     tleap_bin, sander_bin, maxcyc, ncyc, cutoff) = args

    recipes = recipe.load_recipes(*recipes_paths)
    struct = pmd.load_file(cg_prmtop, xyz=rst7_path)
    coords = struct.coordinates

    try:
        chains = reconstruct.reconstruct_frame(cg_prmtop, coords, recipes, allow_unmapped=allow_unmapped,
                                               conformers=conformers)
    except ValueError as e:
        raise RuntimeError(f"frame {gidx}: reconstruction failed: {e}")

    frame_dir = os.path.join(scratch_dir, f"frame_{gidx:06d}")
    os.makedirs(frame_dir, exist_ok=True)
    heavy_pdb = os.path.join(frame_dir, "heavy.pdb")
    has_protein, has_dna, has_ions = reconstruct.write_heavy_pdb(chains, heavy_pdb)
    templates = Counter(res["conformer"] for chain in chains for res in chain if "conformer" in res)

    out_prefix = os.path.join(frame_dir, "frame")
    prmtop, min_coords = hydrogenate.hydrogenate_and_minimize_frame(
        heavy_pdb, out_prefix, has_protein, has_dna, has_ions,
        tleap_bin=tleap_bin, sander_bin=sander_bin,
        maxcyc=maxcyc, ncyc=ncyc, cutoff=cutoff,
    )
    return gidx, prmtop, min_coords, has_protein, has_dna, templates


def backmap(cg_prmtop, out_prefix, traj_dir=None, traj_files=None, n_frames=50,
            tleap_bin="tleap", sander_bin="sander", cpptraj_bin="cpptraj",
            jobs=1, resolvate_output=False, keep_scratch=False, allow_unmapped=False, conformers=True,
            maxcyc=150, ncyc=100, cutoff=12.0, verbose=True):
    paths.check_bundled_params()
    recipes_paths = (paths.BACKMAP_DNA_JSON, paths.BACKMAP_SIRAH_JSON)
    recipe.load_recipes(*recipes_paths)  # fail fast on a schema problem before doing any real work

    out_dir = os.path.dirname(os.path.abspath(out_prefix)) or "."
    os.makedirs(out_dir, exist_ok=True)
    scratch_dir = f"{out_prefix}_scratch"

    if traj_files:
        chunks = list(traj_files)
        counts = frame_select.chunk_frame_counts(chunks)
    else:
        chunks = frame_select.discover_traj_chunks(traj_dir)
        if not chunks:
            sys.exit(f"No md.nc/md2.nc/... chunks found in {traj_dir}")
        counts = frame_select.chunk_frame_counts(chunks)

    global_idxs = frame_select.select_global_frames(counts, n_frames)
    if verbose:
        print(f"Selected {len(global_idxs)} frames across {len(chunks)} chunk(s) "
              f"({sum(counts)} frames total).")

    extracted = []
    for k, gidx in enumerate(global_idxs):
        chunk_idx, local_idx = frame_select.global_to_chunk_local(counts, gidx)
        rst7 = os.path.join(scratch_dir, "cg_frames", f"frame_{gidx:06d}.rst7")
        frame_select.extract_cg_frame(cg_prmtop, chunks[chunk_idx], local_idx, rst7, cpptraj_bin=cpptraj_bin)
        extracted.append((gidx, rst7))

    job_args = [
        (gidx, rst7, cg_prmtop, recipes_paths, scratch_dir, allow_unmapped, conformers,
         tleap_bin, sander_bin, maxcyc, ncyc, cutoff)
        for gidx, rst7 in extracted
    ]

    if jobs <= 1:
        results = [_backmap_one_frame(a) for a in job_args]
    else:
        with ProcessPoolExecutor(max_workers=jobs) as pool:
            results = list(pool.map(_backmap_one_frame, job_args))

    # keep results in ascending global-frame order regardless of worker
    # completion order (matters when jobs > 1)
    results.sort(key=lambda r: r[0])
    coords_per_frame = [r[2] for r in results]
    any_prmtop = results[0][1]
    has_protein = any(r[3] for r in results)
    has_dna = any(r[4] for r in results)
    natom = coords_per_frame[0].shape[0]

    out_prmtop = f"{out_prefix}.prmtop"
    out_nc = f"{out_prefix}.nc"
    assemble.write_final_prmtop(any_prmtop, out_prmtop)
    assemble.write_multiframe_nc(coords_per_frame, out_nc, natom, title=os.path.basename(out_prefix))
    templates = sum((r[5] for r in results), Counter())
    if verbose:
        if templates:
            total = sum(templates.values())
            print("Nucleotide templates (all frames): " + ", ".join(
                f"{k} {v} ({100 * v / total:.0f}%)" for k, v in templates.most_common()))
        print(f"Wrote {out_prmtop}")
        print(f"Wrote {out_nc} ({len(coords_per_frame)} frames, {natom} atoms)")

    solvated = None
    if resolvate_output:
        # frame 0's already-hydrogenated, minimized structure -> PDB, as
        # resolvate.run_tleap's solute input.
        frame0_struct = pmd.load_file(results[0][1], xyz=coords_per_frame[0])
        solute_pdb = os.path.join(scratch_dir, "solute_for_resolvation.pdb")
        frame0_struct.save(solute_pdb, overwrite=True)
        solv_prmtop, solv_inpcrd = resolvate.run_tleap(
            solute_pdb, f"{out_prefix}_solvated", has_protein, has_dna, tleap_bin=tleap_bin,
        )
        solvated = (solv_prmtop, solv_inpcrd)
        if verbose:
            print(f"Wrote {solv_prmtop}")
            print(f"Wrote {solv_inpcrd}")

    if not keep_scratch:
        shutil.rmtree(scratch_dir, ignore_errors=True)

    return (out_prmtop, out_nc) + (solvated if solvated else ())


def make_parser():
    """The command-line options (also rendered in the web app's Command line tab)."""
    ap = argparse.ArgumentParser(prog="backmap_dna.py", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cg_prmtop", help="the finished CG run's prmtop")
    ap.add_argument("traj_dir", nargs="?", default=None,
                     help="directory containing md.nc, md2.nc, ... chunks (mutually exclusive with --traj)")
    ap.add_argument("--traj", nargs="+", default=None, metavar="NC",
                     help="explicit trajectory chunk file(s), in order, instead of traj_dir")
    ap.add_argument("-o", "--out", required=True, metavar="PREFIX", help="output path prefix, e.g. out/1bna_backmap")
    ap.add_argument("--n-frames", type=int, default=50, help="number of evenly-spaced frames to backmap (default: 50)")
    ap.add_argument("--jobs", type=int, default=1, help="parallel frames (each runs its own tleap+sander); default: 1 (serial)")
    ap.add_argument("--resolvate", action="store_true", help="also re-solvate frame 0's structure with explicit water")
    ap.add_argument("--keep-scratch", action="store_true", help="keep the per-frame scratch directory instead of deleting it")
    ap.add_argument("--allow-unmapped", action="store_true",
                     help="drop (with a warning) any CG residue type with no backmap recipe, instead of failing")
    ap.add_argument("--no-conformers", action="store_true",
                     help="build every nucleotide with the B template (1BNA) instead of picking B/A/syn/Z per nucleotide")
    ap.add_argument("--maxcyc", type=int, default=150, help="sander minimization: total steps (default: 150, matches SIRAH's own default)")
    ap.add_argument("--ncyc", type=int, default=100, help="sander minimization: steepest-descent steps before switching to conjugate-gradient (default: 100)")
    ap.add_argument("--cutoff", type=float, default=12.0, help="sander minimization: electrostatic cutoff in Angstrom (default: 12.0)")
    ap.add_argument("--tleap-bin", default="tleap", help="tleap executable (default: tleap)")
    ap.add_argument("--sander-bin", default="sander", help="sander executable (default: sander)")
    ap.add_argument("--cpptraj-bin", default="cpptraj", help="cpptraj executable (default: cpptraj)")
    return ap


def main():
    ap = make_parser()
    args = ap.parse_args()

    if not args.traj_dir and not args.traj:
        ap.error("give either traj_dir or --traj")
    if not os.path.isfile(args.cg_prmtop):
        sys.exit(f"CG prmtop not found: {args.cg_prmtop}")

    backmap(
        args.cg_prmtop, args.out,
        traj_dir=args.traj_dir, traj_files=args.traj, n_frames=args.n_frames,
        tleap_bin=args.tleap_bin, sander_bin=args.sander_bin, cpptraj_bin=args.cpptraj_bin,
        jobs=args.jobs, resolvate_output=args.resolvate, keep_scratch=args.keep_scratch,
        allow_unmapped=args.allow_unmapped, conformers=not args.no_conformers,
        maxcyc=args.maxcyc, ncyc=args.ncyc, cutoff=args.cutoff,
    )


if __name__ == "__main__":
    main()
