"""v18 build chain: bundled parameters, G4 cation placement, and full builds.

The full builds need tleap on PATH and a SIRAH install in $SIRAH_HOME; they
are skipped otherwise. The expected numbers are those of the v18 benchmark
campaign topologies (see cg_dna/tools/check_against_campaign.py, which
compares every term).
"""
import os
import shutil

import numpy as np
import pytest

from cg_dna import cmap, g4, model, paths

HERE = os.path.dirname(os.path.abspath(__file__))
EXAMPLES = os.path.join(os.path.dirname(HERE), "examples")
SIRAH = os.environ.get("SIRAH_HOME")
needs_tleap = pytest.mark.skipif(not (shutil.which("tleap") and SIRAH and os.path.isfile(os.path.join(SIRAH, "leaprc.sirah"))),
                                 reason="needs tleap on PATH and SIRAH_HOME")


def test_bundled_params_present():
    paths.check_bundled_params()


@pytest.mark.parametrize("key", paths.CMAP_ET_GRIDS)
def test_etatheta_grids(key):
    g = np.array(cmap.load_grid(paths.etatheta_grid_path(key)))
    assert g.shape == (576,) and np.isfinite(g).all()


@pytest.mark.parametrize("base", paths.CMAP_BASES)
def test_chi_grids(base):
    g = np.array(cmap.load_grid(paths.chi_grid_path(base)))
    assert g.shape == (576,) and np.isfinite(g).all()


def test_z_grids_deepen_their_basin():
    """GZ = G with the target of basin Ia set to 0, CZ = C with basin IV set
    to 0: inside that basin the Z grid is ~1 kcal/mol below the plain one."""
    nodes = np.arange(-180, 180, 15) % 360
    E, T = np.meshgrid(nodes, nodes, indexing="ij")
    for z, b, basin in (("GZ", "G", "Ia"), ("CZ", "C", "IV")):
        d = (np.array(cmap.load_grid(paths.etatheta_grid_path(z))) -
             np.array(cmap.load_grid(paths.etatheta_grid_path(b)))).reshape(24, 24)
        e0, e1, t0, t1 = next(x[1:] for x in model.BASINS if x[0] == basin)
        inside = (E >= e0) & (E <= e1) & (T >= t0) & (T <= t1)
        assert d[inside].mean() < -0.9


def test_z_theta0_classes():
    for b, classes in model.Z_CLASSES.items():
        for c in classes:
            assert f"{b} {c}" in model.Z_THETA0


def test_salt_rule():
    from cg_dna.tleap_build import salt_pairs
    assert salt_pairs(1076, 0.15) == 30          # 1bna in the campaign
    assert salt_pairs(1076, 0) == 0


def _pdb_lines(name):
    return open(os.path.join(EXAMPLES, name)).readlines()


def test_no_tetrads_in_a_duplex():
    ions, report = g4.channel_cations(_pdb_lines("4ocb_CG.pdb"))
    assert ions == [] and report == []


@needs_tleap
def test_build_1bna(tmp_path):
    from build_dna import build
    prm, crd, s = build(os.path.join(EXAMPLES, "1bna.pdb"), str(tmp_path / "1bna"), SIRAH)
    assert s["cmap"]["eta_theta"] == 20 and s["cmap"]["phi_chi"] == 22
    t = s["topology"]
    assert t["impropers"] == 20 and t["3pB"] == (44, 44)
    assert not (t["z_G"] or t["z_C"])
    assert s["disang"]["restraints"] == 6
    assert s["restraintmask"] == ":1-24"
    assert s["tleap"]["ion_pairs"] == 30
    for f in ("em_WT4.in", "eq_WT4.in", "md_WT4.in", "md2_WT4.in", "disang.rst", "run_md.sh"):
        assert (tmp_path / f).exists()


@needs_tleap
def test_build_4ocb_z_typing(tmp_path):
    from build_dna import build
    prm, crd, s = build(os.path.join(EXAMPLES, "4ocb_CG.pdb"), str(tmp_path / "4ocb"), SIRAH, cg_input=True, salt=3.0)
    t = s["topology"]
    assert len(t["z_G"]) == 12 and len(t["z_C"]) == 12
    assert t["3pB"][0] == 0                      # every nucleotide is Z-typed
    assert t["etatheta_grids"] == {"GZ": 10, "CZ": 10}
    assert (tmp_path / "dens_WT4.in").exists()   # high salt -> compaction deck


def test_deck_names_cover_both_protocols():
    from cg_dna import decks
    written = set(decks.dna_decks("x", ":1-2", True, True)) | set(decks.protein_decks("x", ":1-2", True))
    assert written == set(decks.DECK_NAMES)


@needs_tleap
def test_rebuild_removes_stale_outputs(tmp_path):
    """Rebuilding into the same directory removes the disang.rst and decks the
    new build does not write: run_md.sh would run the compaction for a stale
    dens_WT4.in and the DNA-protein protocol for a stale em1_WT4.in."""
    from build_dna import build
    pdb, out = os.path.join(EXAMPLES, "1bna.pdb"), str(tmp_path / "1bna")
    build(pdb, out, SIRAH, salt=1.0, verbose=False)
    assert (tmp_path / "dens_WT4.in").exists() and (tmp_path / "disang.rst").exists()
    (tmp_path / "em1_WT4.in").write_text("left by a DNA-protein build\n")
    build(pdb, out, SIRAH, end_restraint=False, verbose=False)
    for f in ("dens_WT4.in", "em1_WT4.in", "disang.rst"):
        assert not (tmp_path / f).exists(), f
    for f in ("em_WT4.in", "eq_WT4.in", "md_WT4.in", "md2_WT4.in", "run_md.sh"):
        assert (tmp_path / f).exists(), f
