"""Frame-selection math, tested against synthetic chunk sizes (no real
trajectory files needed)."""
import pytest

from cg_backmap.frame_select import global_to_chunk_local, select_global_frames


def test_even_spacing_across_full_range():
    counts = [50, 50, 25]  # total 125
    idxs = select_global_frames(counts, 5)
    assert idxs[0] == 0
    assert idxs[-1] == 124
    assert len(idxs) == 5
    # roughly even gaps (not exact since np.linspace rounds to int)
    gaps = [b - a for a, b in zip(idxs, idxs[1:])]
    assert max(gaps) - min(gaps) <= 1


def test_dedup_when_n_frames_close_to_total():
    counts = [3]
    idxs = select_global_frames(counts, 3)
    assert idxs == [0, 1, 2]


def test_n_frames_exceeds_total_falls_back_to_all():
    counts = [5]
    idxs = select_global_frames(counts, 100)
    assert idxs == [0, 1, 2, 3, 4]


@pytest.mark.parametrize("global_idx,expected", [
    (0, (0, 1)),
    (49, (0, 50)),
    (50, (1, 1)),
    (99, (1, 50)),
    (100, (2, 1)),
    (124, (2, 25)),
])
def test_global_to_chunk_local_boundaries(global_idx, expected):
    counts = [50, 50, 25]
    assert global_to_chunk_local(counts, global_idx) == expected


def test_global_to_chunk_local_out_of_range():
    with pytest.raises(IndexError):
        global_to_chunk_local([10, 10], 20)
