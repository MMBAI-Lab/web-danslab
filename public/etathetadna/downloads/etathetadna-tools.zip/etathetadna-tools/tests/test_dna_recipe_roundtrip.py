"""Generalization test for params/backmap_dna.json: reconstruct residues
from examples/1bna.pdb OTHER than the ones derive_dna_constants.py used
for calibration, and compare against the real, original coordinates in
that same file.

Uses reconstruct.reconstruct_residues() directly (the ParmEd-free core)
with a hand-built CG bead dict -- no need to build an actual CG prmtop via
tleap/SIRAH just to exercise the reconstruction math.
"""
import os

import numpy as np
import pytest

from cg_dna.convert_dna import ATOM_NAME_MAP, CG_ATOMS, group_by_residue, load_pdb, RES_CG_MAP
from cg_backmap.recipe import load_recipes
from cg_backmap.reconstruct import reconstruct_residues

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REFERENCE_PDB = os.path.join(REPO_ROOT, "examples", "1bna.pdb")
DNA_JSON = os.path.join(REPO_ROOT, "params", "backmap_dna.json")

# Chain A: 5'-C1 G2 C3 G4 A5 A6 T7 T8 C9 G10 C11 G12-3'. derive_dna_constants.py
# calibrated on internal G2/C3/A5/T7 (+ their local geometry, reused for the
# 5'-term alt steps too). Test generalization on a DIFFERENT internal residue
# of each base, plus the real 5' and 3' termini (never used for calibration).
GENERALIZATION_RESIDUES = [4, 6, 8, 9, 10, 11]  # G, A, T, C, G, C -- internal
TERMINAL_RESIDUES = [1, 12]  # true 5'/3' ends of chain A


def _load_reference():
    atoms = load_pdb(REFERENCE_PDB)
    grouped = group_by_residue(atoms)
    # chain A only, sorted by resid
    chain_a = sorted(
        (k for k in grouped if k[2] == "A"),
        key=lambda k: k[1],
    )
    return grouped, chain_a


def _cg_bead_dict(resname, res_atoms):
    """{CG bead name: coords} for one residue, using this model's own
    ATOM_NAME_MAP -- exactly what a real CG prmtop would contain."""
    name_map = ATOM_NAME_MAP[resname]
    keep = CG_ATOMS[resname]
    out = {}
    for a in res_atoms:
        if a["name"] in keep:
            bead_name = name_map.get(a["name"], a["name"])
            out[bead_name] = np.array([a["x"], a["y"], a["z"]], dtype=float)
    return out


def _cg_resname_for_position(resname, position_suffix):
    key = f"{resname}{position_suffix}" if position_suffix else resname
    return RES_CG_MAP[key]


@pytest.mark.parametrize("resid", GENERALIZATION_RESIDUES)
def test_internal_residue_generalizes(resid):
    grouped, chain_a = _load_reference()
    recipes = load_recipes(DNA_JSON)

    # Every INTERNAL residue's own recipe needs a valid i-1 cross-ref, so a
    # short [resid-1, resid] window isn't enough on its own -- resid-1 would
    # itself fail to resolve ITS i-1. Build the window from the chain's true
    # 5' terminus (residue 1, whose 5'-terminal recipe needs no i-1) up
    # through resid, so every residue in the window can fully resolve.
    window = [k for k in chain_a if k[1] <= resid]
    cg_resnames = []
    cg_atoms_per_res = []
    target_pos = None
    for pos, key in enumerate(window):
        resname, rid, chain, seg = key
        suffix = "_5" if rid == 1 else ("_3" if rid == 12 else "")
        cg_resnames.append(_cg_resname_for_position(resname, suffix))
        cg_atoms_per_res.append(_cg_bead_dict(resname, grouped[key]))
        if rid == resid:
            target_pos = pos

    result = reconstruct_residues(cg_resnames, cg_atoms_per_res, recipes)
    built = result[target_pos]["atoms"]

    real_resname, real_rid, _, _ = window[target_pos]
    real_atoms = {a["name"]: np.array([a["x"], a["y"], a["z"]]) for a in grouped[window[target_pos]]}

    max_err = 0.0
    for atom_name, coords in built.items():
        if atom_name in real_atoms:
            err = np.linalg.norm(coords - real_atoms[atom_name])
            max_err = max(max_err, err)
    # Not an exact match (different residue than the one calibrated on) --
    # real base-pair-to-base-pair geometry (twist/rise/slide/propeller...)
    # varies along a real crystal structure's sequence, so a single fixed
    # idealized reference geometry (deliberately not a per-position preset,
    # see derive_dna_constants.py's own docstring) doesn't reproduce every
    # OTHER residue's exact local geometry -- observed errors here range
    # ~0.5-1.3 A, growing mildly for residues farther from the calibration
    # residue / closer to a chain end (the same "fraying" effect as
    # test_5term_residue_generalizes). This test's job is to catch a gross
    # implementation bug (wrong atom/ref mixup), not to demand exact
    # reproduction of one specific crystal structure's local variation --
    # the downstream tleap+sander minimization is what actually cleans this
    # up on real (backmapped-then-relaxed) output.
    assert max_err < 2.0, f"residue {real_rid} ({real_resname}): max atom error {max_err:.3f} A"


def test_5term_residue_generalizes():
    """Residue 1 (chain A's real 5' terminus, base C) is a genuine
    generalization case: derive_dna_constants.py calibrated CX5's
    constants from residue 3's local geometry (an INTERNAL C, using only
    atoms also available at a 5' end), never from residue 1 itself.

    Looser tolerance than the internal-residue case: real chain termini in
    a crystal structure are more conformationally variable ("fraying")
    than internal base pairs, so the single fixed calibration geometry
    generalizes less tightly here. This is expected and, per
    derive_dna_constants.py's own documented design rationale, exactly the
    kind of local strain the downstream tleap+sander minimization step
    (cg_backmap/hydrogenate.py) is meant to absorb -- this test's job is
    only to catch a gross implementation bug (wrong atom/ref mixup), which
    would show as an error far larger than a few Angstrom.
    """
    grouped, chain_a = _load_reference()
    recipes = load_recipes(DNA_JSON)
    key = next(k for k in chain_a if k[1] == 1)
    resname = key[0]
    cg_resname = _cg_resname_for_position(resname, "_5")
    cg_atoms = _cg_bead_dict(resname, grouped[key])

    result = reconstruct_residues([cg_resname], [cg_atoms], recipes)
    built = result[0]["atoms"]
    real_atoms = {a["name"]: np.array([a["x"], a["y"], a["z"]]) for a in grouped[key]}

    max_err = max(
        np.linalg.norm(coords - real_atoms[name])
        for name, coords in built.items() if name in real_atoms
    )
    assert max_err < 3.0, f"5'-terminal residue: max atom error {max_err:.3f} A"
