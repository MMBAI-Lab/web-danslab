"""Backmap chain discovery: DNA beads are found by name, so ions whose atom
type starts with "K" (the G4 channel cation KW4, SIRAH's bulk KW) are not
taken for nucleotides. The channel cations (KW4/NW4) are kept as K+/Na+;
the bulk ions are dropped.

The full-build test needs tleap on PATH and a SIRAH install in $SIRAH_HOME;
it is skipped otherwise.
"""
import os
import shutil

import numpy as np
import parmed as pmd
import pytest

from cg_backmap import hydrogenate, paths as bpaths, recipe, reconstruct

HERE = os.path.dirname(os.path.abspath(__file__))
EXAMPLES = os.path.join(os.path.dirname(HERE), "examples")
SIRAH = os.environ.get("SIRAH_HOME")
needs_tleap = pytest.mark.skipif(not (shutil.which("tleap") and shutil.which("sander") and SIRAH
                                         and os.path.isfile(os.path.join(SIRAH, "leaprc.sirah"))),
                                 reason="needs tleap and sander on PATH and SIRAH_HOME")


def _strand_and_ions():
    """GX5-CX3 strand (C4G -> PC bond) followed by KW4, KW and NW4 ions."""
    s = pmd.Structure()

    def add(name, atype, resname, resnum):
        a = pmd.Atom(name=name, type=atype)
        s.add_atom(a, resname, resnum)
        return a

    k1 = add("C4G", "KG", "GX5", 1)
    p2 = add("PC", "PC", "CX3", 2)
    k2 = add("C4C", "KC", "CX3", 2)
    s.bonds.append(pmd.Bond(k1, p2))
    s.bonds.append(pmd.Bond(p2, k2))
    add("KW4", "KW4", "KW4", 3)
    add("KW", "KW", "KW", 4)
    add("NW4", "NW4", "NW4", 5)
    return s


def test_dna_chains_ignore_ions():
    assert reconstruct.find_dna_chains(_strand_and_ions()) == [[0, 1]]


def test_channel_cations_found_bulk_ions_not():
    assert reconstruct.find_channel_ions(_strand_and_ions()) == [[2], [4]]   # KW4, NW4; not KW


def test_heavy_pdb_flags_ions_and_leap_sources_their_parameters(tmp_path):
    k = {"output_resname": "K+", "atoms": {"K+": np.zeros(3)}}
    g = {"output_resname": "DG5", "atoms": {"N9": np.ones(3)}}
    assert reconstruct.write_heavy_pdb([[g], [k]], str(tmp_path / "h.pdb")) == (False, True, True)
    text, _, _ = hydrogenate.build_hydrogenation_leap_script("h.pdb", "f", False, True, True)
    assert "source leaprc.water.tip3p" in text
    text, _, _ = hydrogenate.build_hydrogenation_leap_script("h.pdb", "f", False, True)
    assert "tip3p" not in text


@needs_tleap
def test_reconstruct_frame_with_channel_and_bulk_k(tmp_path):
    """1bna with a KW4 channel-type cation and KCl: the two strands and the
    channel K+ are reconstructed, the bulk KW is dropped (before the fix,
    KW4 failed with 'no backmap recipe'); the K+ survives hydrogenation."""
    from build_dna import build
    from cg_dna import convert_dna, g4

    cg = str(tmp_path / "1bna_kw4_cg.pdb")
    convert_dna.convert(os.path.join(EXAMPLES, "1bna.pdb"), cg)
    g4.append_ions(cg, [("KW4", np.array([20.0, 20.0, 20.0]), "test")])
    prm, crd, _ = build(cg, str(tmp_path / "out" / "1bna"), SIRAH, cg_input=True, salt=0, cation="KW",
                        end_restraint=False, write_decks=False)
    p = pmd.load_file(prm, crd)
    assert {"KW4", "KW"} <= {r.name for r in p.residues}

    recipes = recipe.load_recipes(bpaths.BACKMAP_DNA_JSON, bpaths.BACKMAP_SIRAH_JSON)
    chains = reconstruct.reconstruct_frame(prm, np.asarray(p.coordinates), recipes)
    assert [len(c) for c in chains] == [12, 12, 1]
    assert chains[2][0]["output_resname"] == "K+"
    kw4 = next(a for a in p.atoms if a.residue.name == "KW4")
    assert np.allclose(chains[2][0]["atoms"]["K+"], p.coordinates[kw4.idx])

    heavy = str(tmp_path / "heavy.pdb")
    flags = reconstruct.write_heavy_pdb(chains, heavy)
    assert flags == (False, True, True)
    aa_prm, xyz = hydrogenate.hydrogenate_and_minimize_frame(heavy, str(tmp_path / "aa" / "frame"), *flags)
    aa = pmd.load_file(aa_prm)
    assert [r.name for r in aa.residues].count("K+") == 1
