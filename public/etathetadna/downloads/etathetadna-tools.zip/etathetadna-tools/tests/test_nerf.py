"""Round-trip and vectorization checks for cg_backmap.nerf."""
import numpy as np
import pytest

from cg_backmap.nerf import place_nerf, measure_internal_coords


@pytest.mark.parametrize("seed", range(5))
def test_roundtrip(seed):
    rng = np.random.default_rng(seed)
    for _ in range(100):
        at3 = rng.uniform(-5, 5, 3)
        at2 = at3 + rng.uniform(-2, 2, 3)
        at1 = at2 + rng.uniform(-2, 2, 3)
        r = rng.uniform(1.0, 2.0)
        theta = rng.uniform(20, 160)
        phi = rng.uniform(-179, 179)

        at4 = place_nerf(at3[None, :], at2[None, :], at1[None, :], r, theta, phi)[0]
        r2, theta2, phi2 = measure_internal_coords(at3, at2, at1, at4)

        dphi = min(abs(phi - phi2), abs(abs(phi - phi2) - 360))
        assert abs(r - r2) < 1e-6
        assert abs(theta - theta2) < 1e-6
        assert dphi < 1e-6


def test_batched_matches_scalar():
    rng = np.random.default_rng(0)
    n = 10
    at3 = rng.uniform(-5, 5, (n, 3))
    at2 = at3 + rng.uniform(-2, 2, (n, 3))
    at1 = at2 + rng.uniform(-2, 2, (n, 3))

    out_batch = place_nerf(at3, at2, at1, 1.5, 109.0, -120.0)
    for i in range(n):
        out_i = place_nerf(at3[i:i + 1], at2[i:i + 1], at1[i:i + 1], 1.5, 109.0, -120.0)[0]
        assert np.allclose(out_batch[i], out_i, atol=1e-10)
