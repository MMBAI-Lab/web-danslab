"""Schema validation for the bundled recipe tables."""
import os

import pytest

from cg_backmap.recipe import load_recipes

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DNA_JSON = os.path.join(REPO_ROOT, "params", "backmap_dna.json")
SIRAH_JSON = os.path.join(REPO_ROOT, "params", "backmap_sirah.json")

# Heavy-atom counts per internal-residue base, cross-checked against
# standard nucleotide chemistry (see cg_backmap/tools/derive_dna_constants.py).
EXPECTED_INTERNAL_ATOM_COUNT = {"DGX": 22, "DAX": 21, "DTX": 20, "DCX": 19}
EXPECTED_5TERM_ATOM_COUNT = {"GX5": 19, "AX5": 18, "TX5": 17, "CX5": 16}


def test_dna_table_loads():
    recipes = load_recipes(DNA_JSON)
    assert len(recipes) == 18  # 4 internal + 4 5'-term + 4 3'-term + 4 repeat-aliases + KW4/NW4


def test_sirah_table_loads():
    recipes = load_recipes(SIRAH_JSON)
    assert len(recipes) == 169


def test_combined_tables_load_no_conflicts():
    recipes = load_recipes(DNA_JSON, SIRAH_JSON)
    assert len(recipes) == 18 + 169


@pytest.mark.parametrize("cg_resname,expected", EXPECTED_INTERNAL_ATOM_COUNT.items())
def test_internal_atom_counts(cg_resname, expected):
    recipes = load_recipes(DNA_JSON)
    assert len(recipes[cg_resname]["print"]) == expected


@pytest.mark.parametrize("cg_resname,expected", EXPECTED_5TERM_ATOM_COUNT.items())
def test_5term_atom_counts(cg_resname, expected):
    recipes = load_recipes(DNA_JSON)
    assert len(recipes[cg_resname]["print"]) == expected


def test_repeat_variants_alias_internal():
    recipes = load_recipes(DNA_JSON)
    for rep, internal in [("DG1", "DGX"), ("DA1", "DAX"), ("DT1", "DTX"), ("DC1", "DCX")]:
        assert recipes[rep] == recipes[internal]


def test_3term_reuses_internal_instructions():
    recipes = load_recipes(DNA_JSON)
    for term3, internal in [("GX3", "DGX"), ("AX3", "DAX"), ("TX3", "DTX"), ("CX3", "DCX")]:
        assert recipes[term3]["instructions"] == recipes[internal]["instructions"]
        assert recipes[term3]["output_resname"] != recipes[internal]["output_resname"]


def test_sirah_nomap_entries():
    recipes = load_recipes(SIRAH_JSON)
    for name in ("WT4", "WLS", "ClW", "NaW", "KW", "WAT", "SOL", "NA", "CL"):
        assert recipes[name].get("nomap") is True


def test_sirah_position_variants_match_internal():
    recipes = load_recipes(SIRAH_JSON)
    for prefix in "ncam":
        key = f"{prefix}A"
        assert recipes[key] == recipes["sA"]


NUCLEOTIDE_ENTRIES = ["DGX", "DAX", "DTX", "DCX", "GX5", "AX5", "TX5", "CX5", "GX3", "AX3", "TX3", "CX3"]


@pytest.mark.parametrize("cg_resname", NUCLEOTIDE_ENTRIES)
def test_nucleotides_have_conformer_templates(cg_resname):
    entry = load_recipes(DNA_JSON)[cg_resname]
    expected = {"A", "syn", "Z"} if "G" in cg_resname else {"A", "Z"}
    assert set(entry["conformers"]) == expected
    for instructions in entry["conformers"].values():
        assert [i["atom"] for i in instructions] == [i["atom"] for i in entry["instructions"]]
    assert entry["fit"]["C1'"]["refs"][0] in ("N9", "N1")
    assert [b[1] for b in entry["fit"]["bonds"]] == (["P/+"] if cg_resname.endswith("5") else ["P", "P/+"])


def test_channel_cations_are_kept_as_ions():
    recipes = load_recipes(DNA_JSON)
    for cg, ion in (("KW4", "K+"), ("NW4", "Na+")):
        assert recipes[cg]["output_resname"] == ion and recipes[cg]["print"] == [ion]
        assert recipes[cg]["instructions"] == [{"atom": ion, "op": "copy", "source": cg}]
