"""Every command-line option is documented: the web app's Command line tab
renders the help of each one (scripts/web_cli.py), straight from these parsers."""
import argparse

import pytest

import backmap_dna
import build_dna
import build_dna_protein


@pytest.mark.parametrize("module", [build_dna, build_dna_protein, backmap_dna])
def test_every_option_has_help(module):
    parser = module.make_parser()
    undocumented = [a.dest for a in parser._actions if not isinstance(a, argparse._HelpAction) and not (a.help or "").strip()]
    assert not undocumented
    assert module.__doc__.strip()
