"""Conformer templates of the DNA backmap (B, A, syn, Z; params/backmap_dna.json).

Each structure is mapped to CG beads straight from its crystal atoms (the
same beads convert_dna.py keeps), rebuilt with reconstruct_residues(), and
the rebuilt glycosidic angle and sugar pucker are compared with the
crystal: 1BNA (B), 116D (A-DNA), 181D (Z-DNA), 1JPQ (antiparallel G4 with
syn G). No tleap needed.
"""
import os

import numpy as np
import pytest

from cg_backmap.recipe import load_recipes
from cg_backmap.reconstruct import reconstruct_residues
from cg_dna.convert_dna import ATOM_NAME_MAP, CG_ATOMS, RES_CG_MAP, group_by_residue, load_pdb

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXAMPLES = os.path.join(REPO_ROOT, "examples")
DNA_JSON = os.path.join(REPO_ROOT, "params", "backmap_dna.json")


def _dih(a, b, c, d):
    b0, b1, b2 = a - b, c - b, d - c
    b1 = b1 / np.linalg.norm(b1)
    v, w = b0 - np.dot(b0, b1) * b1, b2 - np.dot(b2, b1) * b1
    return np.degrees(np.arctan2(np.dot(np.cross(b1, v), w), np.dot(v, w)))


def _chi(r):
    if "N9" in r:
        return _dih(r["O4'"], r["C1'"], r["N9"], r["C4"])
    return _dih(r["O4'"], r["C1'"], r["N1"], r["C2"])


def _pucker(r):
    """Pseudorotation phase P (Altona-Sundaralingam), degrees in [0, 360)."""
    nu = [_dih(r["C4'"], r["O4'"], r["C1'"], r["C2'"]), _dih(r["O4'"], r["C1'"], r["C2'"], r["C3'"]),
          _dih(r["C1'"], r["C2'"], r["C3'"], r["C4'"]), _dih(r["C2'"], r["C3'"], r["C4'"], r["O4'"]),
          _dih(r["C3'"], r["C4'"], r["O4'"], r["C1'"])]
    s = np.sin(np.radians(36)) + np.sin(np.radians(72))
    return np.degrees(np.arctan2(nu[4] + nu[1] - nu[3] - nu[0], 2 * nu[2] * s)) % 360


def _syn(chi):
    return 0 < chi < 120


def _north(P):
    return P < 54 or P > 342


def _strands(pdb):
    """Runs of bonded, complete nucleotides (O3'-P < 2 A, same chain):
    [(residue key, {atom: xyz}), ...]. Residues that are not DA/DC/DG/DT
    (e.g. 1JPQ's 5-bromouracil, a HETATM) end a run; a 5' end has no P."""
    grouped = group_by_residue(load_pdb(pdb))
    runs, cur = [], []
    for key, atoms in grouped.items():
        xyz = {a["name"]: np.array([a["x"], a["y"], a["z"]]) for a in atoms}
        if key[0] not in ("DA", "DC", "DG", "DT") or not all(a in xyz for a in CG_ATOMS[key[0]] if a != "P"):
            runs.append(cur)
            cur = []
            continue
        if cur:
            pkey, pxyz = cur[-1]
            if pkey[2] != key[2] or "P" not in xyz or np.linalg.norm(pxyz["O3'"] - xyz["P"]) > 2.0:
                runs.append(cur)
                cur = []
        cur.append((key, xyz))
    runs.append(cur)
    return [r for r in runs if len(r) > 1]


def _rebuild(pdb, conformers=True):
    """[(crystal atoms, rebuilt residue dict)] over every strand of pdb."""
    recipes = load_recipes(DNA_JSON)
    out = []
    for run in _strands(pdb):
        names, beads = [], []
        for pos, (key, xyz) in enumerate(run):
            suffix = "_5" if pos == 0 else ("_3" if pos == len(run) - 1 else "")
            names.append(RES_CG_MAP[key[0] + suffix])
            beads.append({ATOM_NAME_MAP[key[0]].get(a, a): x for a, x in xyz.items() if a in CG_ATOMS[key[0]]})
        rebuilt = reconstruct_residues(names, beads, recipes, conformers=conformers)
        out += [(xyz, res) for (_, xyz), res in zip(run, rebuilt)]
    return out


def _dchi(ref, res):
    return abs((_chi(res["atoms"]) - _chi(ref) + 180) % 360 - 180)


@pytest.mark.parametrize("pdb", ["1bna.pdb", "116d.pdb", "181d.pdb", "1jpq.pdb"])
def test_glycosidic_angle_is_kept(pdb):
    """Every rebuilt nucleotide is within 30 deg of the crystal chi (syn
    stays syn): the largest deviation is about 27 deg."""
    pairs = _rebuild(os.path.join(EXAMPLES, pdb))
    assert pairs and max(_dchi(ref, res) for ref, res in pairs) < 30


@pytest.mark.parametrize("pdb", ["1bna.pdb", "1jpq.pdb"])
def test_template_chi_matches_the_base(pdb):
    """The chi gate: the template a nucleotide takes is on the same side
    (syn/anti) as its rebuilt base. Without it, high-anti G's of 1BNA took
    the syn template."""
    recipes = load_recipes(DNA_JSON)
    for ref, res in _rebuild(os.path.join(EXAMPLES, pdb)):
        name = {"DG": "DGX", "DA": "DAX", "DC": "DCX", "DT": "DTX"}[res["output_resname"][:2]]
        own = recipes[name]["fit"]["chi"][res["conformer"]]
        assert abs((_chi(res["atoms"]) - own + 180) % 360 - 180) < 90


def test_a_dna_is_rebuilt_c3_endo():
    pairs = _rebuild(os.path.join(EXAMPLES, "116d.pdb"))
    assert len(pairs) == 12
    assert all(res["conformer"] == "A" and _north(_pucker(res["atoms"])) for _, res in pairs)


def test_z_dna_syn_purines_are_rebuilt_c3_endo():
    pairs = _rebuild(os.path.join(EXAMPLES, "181d.pdb"))
    zsyn = [(ref, res) for ref, res in pairs if _syn(_chi(ref)) and _north(_pucker(ref))]
    assert len(zsyn) == 3                                   # A2, G4, G10 (G6/G12 are 3' ends, C2'-endo)
    assert all(res["conformer"] == "Z" and _north(_pucker(res["atoms"])) for _, res in zsyn)


def test_g4_syn_guanines_use_the_syn_template():
    pairs = _rebuild(os.path.join(EXAMPLES, "1jpq.pdb"))
    syn = [res for ref, res in pairs if _syn(_chi(ref))]
    assert len(syn) == 8
    assert all(res["conformer"] == "syn" and not _north(_pucker(res["atoms"])) for res in syn)


def test_b_dna_internal_residues_use_the_b_template():
    pairs = _rebuild(os.path.join(EXAMPLES, "1bna.pdb"))
    assert sum(res["conformer"] == "B" for _, res in pairs) >= 22


def test_b_template_only_loses_syn():
    """Without the conformers (the backmap before them) the syn
    nucleotides of 1JPQ and 181D come out 40-60 deg off: what the templates
    are there to fix."""
    for pdb in ("1jpq.pdb", "181d.pdb"):
        pairs = _rebuild(os.path.join(EXAMPLES, pdb), conformers=False)
        assert {res["conformer"] for _, res in pairs} == {"B"}
        assert max(_dchi(ref, res) for ref, res in pairs if _syn(_chi(ref))) > 40
